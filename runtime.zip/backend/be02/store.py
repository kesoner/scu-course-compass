"""BE-02 persistence. HTTP transport and academic decisions belong to later tasks."""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import secrets
import sqlite3
import uuid

from .auth import Principal
from .errors import StoreError
from .validation import CONTRACT_ROOT, ContractValidation, canonical, semantic_error, validate_intervals

MIGRATIONS_ROOT = Path(__file__).parent / "migrations"


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def token_digest(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def missing():
    raise StoreError(404, "NOT_FOUND", "找不到資源")


class Repository:
    def __init__(self, path, *, mode="synthetic"):
        if mode not in ("synthetic", "production"):
            raise ValueError("mode must be synthetic or production")
        self.path = Path(path).resolve()
        self.mode = mode
        self._issuer = secrets.token_hex(32)
        self.validation = ContractValidation()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._migrate()

    def _connect(self):
        connection = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA recursive_triggers=ON")
        connection.execute("PRAGMA busy_timeout=10000")
        return connection

    def _migrate(self):
        with self._session(transaction=False) as con:
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
            if tables and "be02_schema_migrations" not in tables:
                raise StoreError(409, "WRONG_DATABASE", "指定資料庫不屬於BE-02；請使用獨立檔案")
            if "be02_metadata" in tables:
                stored = con.execute("SELECT value FROM be02_metadata WHERE key='data_mode'").fetchone()
                if not stored or stored[0] != self.mode:
                    raise StoreError(409, "DATA_MODE_MISMATCH", "資料庫模式與啟動模式不符")
            con.execute("PRAGMA journal_mode=WAL")
            con.execute("CREATE TABLE IF NOT EXISTS be02_schema_migrations (version TEXT PRIMARY KEY, sha256 TEXT NOT NULL, applied_at TEXT NOT NULL)")
            for path in sorted(MIGRATIONS_ROOT.glob("*.sql")):
                sql = path.read_text(encoding="utf-8")
                # Triggers protect every row of an immutable history, including direct SQL writes.
                immutable = ["references", "sources", "catalog_versions", "catalog_sources", "courses", "offerings", "meetings",
                             "rule_versions", "rule_sources", "requirements", "profile_versions", "record_versions", "records",
                             "academic_evidence", "profile_sources", "record_sources", "direction_links", "snapshots", "plan_versions", "artifact_versions", "audit_events", "seed_runs"]
                triggers = "\n".join(
                    f"CREATE TRIGGER be02_{table}_no_{action.lower()} BEFORE {action} ON be02_{table} BEGIN SELECT RAISE(ABORT,'immutable history'); END;"
                    for table in immutable for action in ("UPDATE", "DELETE"))
                if path.name != "001_initial.sql":
                    # Later migrations carry their own new triggers; never recreate old ones.
                    triggers = ""
                checksum = hashlib.sha256((sql + triggers).encode("utf-8")).hexdigest()
                con.execute("BEGIN IMMEDIATE")
                try:
                    previous = con.execute("SELECT sha256 FROM be02_schema_migrations WHERE version=?", (path.name,)).fetchone()
                    if previous:
                        if previous[0] != checksum:
                            raise StoreError(409, "MIGRATION_CHECKSUM_MISMATCH", "已套用的migration內容已改變")
                    else:
                        # execute individual complete statements without executescript's implicit commit.
                        statement = ""
                        for line in (sql + "\n" + triggers).splitlines():
                            statement += line + "\n"
                            if sqlite3.complete_statement(statement):
                                con.execute(statement)
                                statement = ""
                        con.execute("INSERT OR IGNORE INTO be02_metadata VALUES ('data_mode',?)", (self.mode,))
                        con.execute("INSERT INTO be02_schema_migrations VALUES (?,?,?)", (path.name, checksum, now()))
                    con.commit()
                except Exception:
                    con.rollback()
                    raise

    @contextmanager
    def _session(self, *, write=False, transaction=True):
        con = self._connect()
        try:
            if write:
                con.execute("BEGIN IMMEDIATE")
            elif transaction:
                con.execute("BEGIN")
            yield con
            if con.in_transaction:
                con.commit()
        except sqlite3.IntegrityError:
            con.rollback()
            raise StoreError(409, "DATA_CONFLICT", "資料關聯或版本衝突") from None
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    def _authenticate_mock(self, authorization):
        if self.mode != "synthetic":
            raise StoreError(401, "UNAUTHENTICATED", "正式模式不接受Mock身分")
        if not isinstance(authorization, str) or not authorization.startswith("Bearer "):
            raise StoreError(401, "UNAUTHENTICATED", "需要有效登入身分")
        credential = token_digest(authorization[7:])
        with self._session() as con:
            row = self._credential(con, credential)
            return Principal(row["subject"], row["kind"], credential, self._issuer)

    def _credential(self, con, credential):
        row = con.execute("SELECT p.*,t.expires_at,t.revoked_at FROM be02_mock_tokens t JOIN be02_principals p ON p.subject=t.subject WHERE t.token_digest=?", (credential,)).fetchone()
        if not row or not row["active"] or row["revoked_at"] or (row["expires_at"] and datetime.fromisoformat(row["expires_at"]) <= datetime.now(timezone.utc)):
            raise StoreError(401, "UNAUTHENTICATED", "需要有效登入身分")
        return row

    def _authorize(self, con, principal, permission="self:read"):
        if self.mode != "synthetic" or not isinstance(principal, Principal) or principal._issuer != self._issuer:
            raise StoreError(401, "UNAUTHENTICATED", "需要有效登入身分")
        row = self._credential(con, principal._credential_digest)
        if row["subject"] != principal.subject or row["kind"] != principal.kind:
            raise StoreError(401, "UNAUTHENTICATED", "需要有效登入身分")
        if permission and not con.execute("SELECT 1 FROM be02_permissions WHERE subject=? AND permission=?", (principal.subject, permission)).fetchone():
            raise StoreError(403, "FORBIDDEN", "此身分沒有操作權限")
        if permission in ("self:read", "self:write") and principal.kind != "student":
            raise StoreError(403, "FORBIDDEN", "此身分沒有操作權限")
        return principal.subject

    @staticmethod
    def _json(row):
        if row is None:
            missing()
        return json.loads(row["payload"])

    @staticmethod
    def _audit(con, owner, kind, resource_id, revision, actor, action, payload):
        con.execute("INSERT INTO be02_audit_events(student_id,resource_kind,resource_id,revision,actor_id,action,sha256,occurred_at) VALUES (?,?,?,?,?,?,?,?)",
                    (owner, kind, resource_id, str(revision), actor, action, digest(payload), now()))

    @staticmethod
    def _stale(con, owner=None, term=None, rule_set_id=None):
        where, args = ("student_id=?", [owner]) if owner else ("1=1", [])
        if term:
            where += " AND plan_id IN (SELECT plan_id FROM be02_plan_versions WHERE json_extract(payload,'$.term_id')=?)"
            args.append(term)
        if rule_set_id:
            where += " AND plan_id IN (SELECT p.plan_id FROM be02_plan_versions p JOIN be02_plan_heads h ON h.plan_id=p.plan_id AND h.revision=p.revision JOIN be02_rule_versions r ON r.version=json_extract(p.payload,'$.data_versions.rules') WHERE r.rule_set_id=?)"
            args.append(rule_set_id)
        con.execute(f"UPDATE be02_plan_heads SET validation_state='stale',state='draft' WHERE {where}", args)
        con.execute(f"UPDATE be02_artifact_heads SET is_current=0 WHERE (student_id,kind,artifact_id) IN (SELECT student_id,kind,artifact_id FROM be02_artifact_versions WHERE plan_id IN (SELECT plan_id FROM be02_plan_heads WHERE {where}))", args)

    def _source(self, con, source):
        previous = con.execute("SELECT sha256 FROM be02_sources WHERE source_id=? AND version=?", (source["source_id"], source["version"])).fetchone()
        if previous:
            if previous[0] != digest(source):
                raise StoreError(409, "IMMUTABLE_VERSION", "相同來源版本不能覆寫")
        else:
            con.execute("INSERT INTO be02_sources VALUES (?,?,?,?)", (source["source_id"], source["version"], canonical(source), digest(source)))

    def _check_sources(self, con, payload, sources, *, public=False):
        by_id = {s["source_id"]: s for s in sources}
        if len(by_id) != len(sources):
            semantic_error("同一資源不能綁定兩個同名來源")
        for source in sources:
            if public and source["kind"] in ("official_record", "student_report"):
                semantic_error("公開課程與課規不能包含學生紀錄來源")
            if self.mode == "production" and source["kind"] == "synthetic":
                semantic_error("正式模式不能發布合成來源")
        def walk(value):
            if isinstance(value, dict):
                for ref in value.get("source_refs", []):
                    if ref["source_id"] not in by_id:
                        semantic_error("來源參照不存在")
                for child in value.values():
                    walk(child)
            elif isinstance(value, list):
                for child in value:
                    walk(child)
        walk(payload)

    @staticmethod
    def _unique(items, key):
        values = [x[key] for x in items]
        if len(values) != len(set(values)):
            semantic_error("同一版本包含重複識別碼")

    def _catalog(self, con, payload, actor):
        self.validation.validate("CatalogVersionImport", payload)
        validate_intervals(payload)
        self._check_sources(con, payload, payload["sources"], public=True)
        self._unique(payload["courses"], "course_id")
        self._unique(payload["offerings"], "offering_id")
        courses = {c["course_id"] for c in payload["courses"]}
        campuses = {r[0] for r in con.execute("SELECT entity_id FROM be02_references WHERE kind='campus'")}
        if not con.execute("SELECT 1 FROM be02_references WHERE kind='term' AND entity_id=?", (payload["term_id"],)).fetchone():
            semantic_error("學期不存在")
        for offering in payload["offerings"]:
            if offering["course_id"] not in courses or offering["term_id"] != payload["term_id"]:
                semantic_error("開課班別的課程或學期參照錯誤")
            for meeting in offering["meetings"] or []:
                if meeting["campus_id"] is not None and meeting["campus_id"] not in campuses:
                    semantic_error("校區不存在")
        previous = con.execute("SELECT sha256 FROM be02_catalog_versions WHERE version=?", (payload["version"],)).fetchone()
        if previous:
            if previous[0] != digest(payload):
                raise StoreError(409, "IMMUTABLE_VERSION", "課程版本不能覆寫")
            return False
        for source in payload["sources"]:
            self._source(con, source)
        con.execute("INSERT INTO be02_catalog_versions VALUES (?,?,?,?,?,?)", (payload["version"], payload["term_id"], canonical(payload), digest(payload), now(), actor))
        for source in payload["sources"]:
            con.execute("INSERT INTO be02_catalog_sources VALUES (?,?,?)", (payload["version"], source["source_id"], source["version"]))
        for course in payload["courses"]:
            credits = course["credits"]
            con.execute("INSERT INTO be02_courses VALUES (?,?,?,?)", (payload["version"], course["course_id"], None if credits is None else int(Decimal(str(credits))*100), canonical(course)))
        for offering in payload["offerings"]:
            con.execute("INSERT INTO be02_offerings VALUES (?,?,?,?,?)", (payload["version"], offering["offering_id"], offering["course_id"], payload["term_id"], canonical(offering)))
            for index, meeting in enumerate(offering["meetings"] or []):
                con.execute("INSERT INTO be02_meetings VALUES (?,?,?,?,?,?,?,?)", (payload["version"], offering["offering_id"], index, meeting["weekday"], meeting["start_minute"], meeting["end_minute"], meeting["campus_id"], canonical(meeting)))
        con.execute("INSERT INTO be02_catalog_heads VALUES (?,?) ON CONFLICT(term_id) DO UPDATE SET version=excluded.version", (payload["term_id"], payload["version"]))
        self._stale(con, term=payload["term_id"])
        self._audit(con, None, "catalog", payload["term_id"], payload["version"], actor, "published", payload)
        return True

    def publish_catalog(self, principal, payload):
        with self._session(write=True) as con:
            actor = self._authorize(con, principal, "catalog:publish")
            return {"version": payload.get("version"), "created": self._catalog(con, payload, actor)}

    def _rules(self, con, payload, sources, actor):
        self.validation.validate("RuleSet", payload)
        for source in sources:
            self.validation.validate("Source", source)
        self._check_sources(con, payload, sources, public=True)
        self._unique(payload["requirements"], "requirement_id")
        family = con.execute("SELECT payload FROM be02_rule_versions WHERE rule_set_id=? LIMIT 1", (payload["rule_set_id"],)).fetchone()
        if family:
            old = self._json(family)
            if any(old[k] != payload[k] for k in ("institution_id", "entry_year", "program_approval_years")):
                semantic_error("同一課規系列不能改變適用身分；請建立新系列")
        previous = con.execute("SELECT sha256 FROM be02_rule_versions WHERE rule_set_id=? AND version=?", (payload["rule_set_id"], payload["version"])).fetchone()
        if previous:
            if previous[0] != digest({"rule_set": payload, "sources": sources}):
                raise StoreError(409, "IMMUTABLE_VERSION", "課規版本不能覆寫")
            return False
        for source in sources:
            self._source(con, source)
        con.execute("INSERT INTO be02_rule_versions VALUES (?,?,?,?,?,?)", (payload["rule_set_id"], payload["version"], canonical(payload), digest({"rule_set": payload, "sources": sources}), now(), actor))
        for source in sources:
            con.execute("INSERT INTO be02_rule_sources VALUES (?,?,?,?)", (payload["rule_set_id"], payload["version"], source["source_id"], source["version"]))
        for req in payload["requirements"]:
            con.execute("INSERT INTO be02_requirements VALUES (?,?,?,?)", (payload["rule_set_id"], payload["version"], req["requirement_id"], canonical(req)))
        if payload["review_state"] in ("approved", "mock_validated"):
            if self.mode == "production" and payload["review_state"] == "mock_validated":
                semantic_error("正式模式不能採用Mock課規")
            con.execute("INSERT INTO be02_rule_heads VALUES (?,?) ON CONFLICT(rule_set_id) DO UPDATE SET version=excluded.version", (payload["rule_set_id"], payload["version"]))
            # Only plans pinned to this rule family become stale.
            self._stale(con, rule_set_id=payload["rule_set_id"])
        self._audit(con, None, "rules", payload["rule_set_id"], payload["version"], actor, "imported", payload)
        return True

    def publish_rules(self, principal, payload, sources):
        with self._session(write=True) as con:
            actor = self._authorize(con, principal, "rules:publish")
            return {"version": payload.get("version"), "created": self._rules(con, payload, sources, actor)}

    def get_catalog(self, principal, term_id, *, version=None):
        with self._session() as con:
            self._authorize(con, principal, None)
            if version is None:
                head = con.execute("SELECT version FROM be02_catalog_heads WHERE term_id=?", (term_id,)).fetchone()
                if not head:
                    missing()
                version = head[0]
            return self._json(con.execute("SELECT payload FROM be02_catalog_versions WHERE term_id=? AND version=?", (term_id, version)).fetchone())

    def get_rules(self, principal, rule_set_id, *, version=None):
        with self._session() as con:
            self._authorize(con, principal, None)
            if version is None:
                head = con.execute("SELECT version FROM be02_rule_heads WHERE rule_set_id=?", (rule_set_id,)).fetchone()
                if not head:
                    missing()
                version = head[0]
            payload = self._json(con.execute("SELECT payload FROM be02_rule_versions WHERE rule_set_id=? AND version=?", (rule_set_id, version)).fetchone())
            if payload["review_state"] not in ("approved", "mock_validated"):
                self._authorize(con, principal, "rules:publish")
            return payload

    def _profile(self, con, owner, revision=None):
        if revision is None:
            row = con.execute("SELECT profile_revision FROM be02_student_heads WHERE student_id=?", (owner,)).fetchone()
            if not row:
                missing()
            revision = row[0]
        return self._json(con.execute("SELECT payload FROM be02_profile_versions WHERE student_id=? AND revision=?", (owner, revision)).fetchone())

    def get_profile(self, principal, *, revision=None):
        with self._session() as con:
            owner = self._authorize(con, principal)
            return self._profile(con, owner, revision)

    def _academic(self, con, owner, revision=None):
        if revision is None:
            head = con.execute("SELECT records_revision FROM be02_student_heads WHERE student_id=?", (owner,)).fetchone()
            if not head:
                missing()
            revision = head[0]
        row = con.execute("SELECT * FROM be02_record_versions WHERE student_id=? AND revision=?", (owner, revision)).fetchone()
        if not row:
            missing()
        result = {"records_revision": revision, "version": row["version_label"], "record_coverage": row["coverage"]}
        result["records"] = [self._json(r) for r in con.execute("SELECT payload FROM be02_records WHERE student_id=? AND records_revision=? ORDER BY record_id", (owner, revision))]
        for kind, key in (("recognition", "recognition_decisions"), ("non_credit", "non_credit_evidence")):
            result[key] = [self._json(r) for r in con.execute("SELECT payload FROM be02_academic_evidence WHERE student_id=? AND records_revision=? AND kind=? ORDER BY evidence_id", (owner, revision, kind))]
        return result

    def get_academic_bundle(self, principal, *, revision=None):
        with self._session() as con:
            return self._academic(con, self._authorize(con, principal), revision)

    def get_record(self, principal, record_id, *, revision=None):
        bundle = self.get_academic_bundle(principal, revision=revision)
        for record in bundle["records"]:
            if record["record_id"] == record_id:
                return record
        missing()

    def _write_profile(self, con, payload, actor, exploring, reason):
        con.execute("INSERT INTO be02_profile_versions VALUES (?,?,?,?,?,?,?,?,?)", (payload["student_id"], payload["revision"], f"profile-v{payload['revision']}", canonical(payload), digest({"profile": payload, "exploring_program_ids": exploring}), now(), actor, reason, canonical(exploring)))
        self._audit(con, payload["student_id"], "profile", payload["student_id"], payload["revision"], actor, reason, payload)

    def append_self_reported_records(self, principal, request, *, expected_revision):
        """Storage commit for already accepted import rows; preview/HTTP is BE-03 work.

        Student reports never create institutional approvals or verified earned credits.
        No arbitrary owner, source provenance or earned-credit fields are accepted.
        """
        with self._session(write=True) as con:
            owner = self._authorize(con, principal, "self:write")
            self.validation.validate("ImportRequest", request)
            self._unique(request["rows"], "source_record_key")
            previous = self._academic(con, owner)
            self._match(previous["records_revision"], expected_revision)
            by_key = {r["source_record_key"]: r for r in previous["records"]}
            accepted = []
            for row in request["rows"]:
                if row["source_record_key"] in by_key:
                    original = by_key[row["source_record_key"]]
                    if any(original[k] != row[k] for k in ("course_id", "term_id", "state", "grade")):
                        raise StoreError(409, "DATA_CONFLICT", "同一來源紀錄鍵已存在不同內容")
                    continue
                if not con.execute("SELECT 1 FROM be02_courses WHERE course_id=?", (row["course_id"],)).fetchone():
                    semantic_error("匯入課程不存在")
                accepted.append(row)
            if not accepted:
                return {"records_revision": expected_revision, "imported_count": 0, "trust": "student_report"}
            revision = expected_revision + 1
            source_id = "student-report-" + uuid.uuid4().hex
            source = {"source_id": source_id, "kind": "student_report", "uri": None, "version": "v1", "verification": "unverified", "updated_at": now()}
            self._source(con, source)
            records = deepcopy(previous["records"])
            for row in accepted:
                record = {"record_id": "record-" + uuid.uuid4().hex, "student_id": owner, **row,
                          "earned_credits": 0 if row["state"] in ("enrolled", "failed", "withdrawn") else None,
                          "approval": "not_required",
                          "source_refs": [{"source_id": source_id, "locator": row["source_record_key"]}]}
                self.validation.validate("Record", record)
                records.append(record)
            snapshot = {**previous, "records_revision": revision, "version": f"records-v{revision}", "records": records}
            con.execute("INSERT INTO be02_record_versions VALUES (?,?,?,?,?,?,?)", (owner, revision, snapshot["version"], previous["record_coverage"], digest(snapshot), now(), owner))
            for record in records:
                con.execute("INSERT INTO be02_records VALUES (?,?,?,?,?,?)", (owner, revision, record["record_id"], record["course_id"], record["source_record_key"], canonical(record)))
            con.execute("INSERT INTO be02_academic_evidence SELECT student_id,?,kind,evidence_id,payload FROM be02_academic_evidence WHERE student_id=? AND records_revision=?", (revision, owner, expected_revision))
            con.execute("INSERT INTO be02_record_sources SELECT student_id,?,source_id,source_version FROM be02_record_sources WHERE student_id=? AND records_revision=?", (revision, owner, expected_revision))
            con.execute("INSERT INTO be02_record_sources VALUES (?,?,?,?)", (owner, revision, source_id, "v1"))
            con.execute("UPDATE be02_student_heads SET records_revision=? WHERE student_id=?", (revision, owner))
            self._stale(con, owner=owner)
            self._audit(con, owner, "records", owner, revision, owner, "student_report_imported", snapshot)
            return {"records_revision": revision, "imported_count": len(accepted), "trust": "student_report"}

    def update_profile(self, principal, patch, *, expected_revision):
        with self._session(write=True) as con:
            owner = self._authorize(con, principal, "self:write")
            self.validation.validate("ProfilePatch", patch)
            current = self._profile(con, owner)
            self._match(current["revision"], expected_revision)
            head = con.execute("SELECT exploring_program_ids FROM be02_student_heads WHERE student_id=?", (owner,)).fetchone()
            exploring = patch.get("exploring_program_ids", json.loads(head[0]))
            allowed = {r[0] for r in con.execute("SELECT entity_id FROM be02_references WHERE kind='program'")}
            if not set(exploring) <= allowed:
                semantic_error("探索學程不存在")
            updated = deepcopy(current)
            if "target_graduation_term" in patch:
                updated["target_graduation_term"] = patch["target_graduation_term"]
            if current == updated and exploring == json.loads(head[0]):
                return current
            updated["revision"] += 1
            self._write_profile(con, updated, owner, exploring, "student_updated")
            con.execute("INSERT INTO be02_profile_sources SELECT student_id,?,source_id,source_version FROM be02_profile_sources WHERE student_id=? AND profile_revision=?", (updated["revision"], owner, current["revision"]))
            con.execute("UPDATE be02_student_heads SET profile_revision=?,exploring_program_ids=? WHERE student_id=?", (updated["revision"], canonical(exploring), owner))
            self._stale(con, owner=owner)
            return updated

    @staticmethod
    def _match(current, expected):
        if type(expected) is not int or current != expected:
            raise StoreError(409, "REVISION_CONFLICT", "資料已有更新，請重新讀取後再修改", current_revision=current,
                             details=[{"pointer": "/headers/If-Match", "reason_code": "STALE_REVISION", "message": "請使用最新修訂"}])

    def _plan(self, con, owner, plan_id, revision=None):
        head = con.execute("SELECT * FROM be02_plan_heads WHERE student_id=? AND plan_id=?", (owner, plan_id)).fetchone()
        if not head:
            missing()
        payload = self._json(con.execute("SELECT payload FROM be02_plan_versions WHERE student_id=? AND plan_id=? AND revision=?", (owner, plan_id, head["revision"] if revision is None else revision)).fetchone())
        if revision is None:
            payload.update(state=head["state"], validation_state=head["validation_state"])
        return payload

    def get_plan(self, principal, plan_id, *, revision=None):
        with self._session() as con:
            return self._plan(con, self._authorize(con, principal), plan_id, revision)

    def get_snapshot(self, principal, snapshot_id):
        with self._session() as con:
            owner = self._authorize(con, principal)
            return self._json(con.execute("SELECT payload FROM be02_snapshots WHERE student_id=? AND snapshot_id=?", (owner, snapshot_id)).fetchone())

    def get_artifact(self, principal, kind, artifact_id, *, revision=None):
        with self._session() as con:
            owner = self._authorize(con, principal)
            return self._artifact(con, owner, kind, artifact_id, revision)

    def _artifact(self, con, owner, kind, artifact_id, revision=None):
        if revision is None:
            head = con.execute("SELECT revision FROM be02_artifact_heads WHERE student_id=? AND kind=? AND artifact_id=?", (owner, kind, artifact_id)).fetchone()
            if not head:
                missing()
            revision = head[0]
        return self._json(con.execute("SELECT payload FROM be02_artifact_versions WHERE student_id=? AND kind=? AND artifact_id=? AND revision=?", (owner, kind, artifact_id, revision)).fetchone())

    def _snapshot(self, con, plan, extra=None):
        owner, versions = plan["student_id"], plan["data_versions"]
        profile_row = con.execute("SELECT payload,exploring_program_ids FROM be02_profile_versions WHERE student_id=? AND version_label=?", (owner, versions["profile"])).fetchone()
        records = con.execute("SELECT revision FROM be02_record_versions WHERE student_id=? AND version_label=?", (owner, versions["records"])).fetchone()
        if not profile_row or not records:
            semantic_error("方案參照的學生資料版本不存在")
        catalog = self._json(con.execute("SELECT payload FROM be02_catalog_versions WHERE version=? AND term_id=?", (versions["catalog"], plan["term_id"])).fetchone())
        rules = self._json(con.execute("SELECT payload FROM be02_rule_versions WHERE version=?", (versions["rules"],)).fetchone())
        sources = [self._json(r) for r in con.execute("SELECT s.payload FROM be02_sources s JOIN be02_rule_sources r ON s.source_id=r.source_id AND s.version=r.source_version WHERE r.rule_version=? ORDER BY s.source_id", (versions["rules"],))]
        private_sources = {}
        for kind, revision in (("profile", self._json(profile_row)["revision"]), ("record", records[0])):
            column = "profile_revision" if kind == "profile" else "records_revision"
            private_sources[kind] = [self._json(r) for r in con.execute(f"SELECT s.payload FROM be02_sources s JOIN be02_{kind}_sources p ON s.source_id=p.source_id AND s.version=p.source_version WHERE p.student_id=? AND p.{column}=? ORDER BY s.source_id", (owner, revision))]
        return {"plan": deepcopy(plan), "profile": self._json(profile_row), "exploring_program_ids": json.loads(profile_row["exploring_program_ids"]),
                "academic": self._academic(con, owner, records[0]), "academic_sources": private_sources,
                "catalog": catalog, "rule_set": rules, "rule_sources": sources, "private_artifacts": extra or {}}

    def _write_plan(self, con, plan, actor, reason, extra=None):
        self.validation.validate("Plan", plan)
        validate_intervals(plan["preferences"])
        snapshot = self._snapshot(con, plan, extra)
        courses = {c["course_id"] for c in snapshot["catalog"]["courses"]}
        offerings = {o["offering_id"] for o in snapshot["catalog"]["offerings"]}
        if not set(plan["required_course_ids"]) <= courses or any(s["offering_id"] not in offerings for s in plan["selections"]):
            semantic_error("方案包含不存在的課程或班別")
        self._unique(plan["selections"], "offering_id")
        if plan["confirmed_intent_id"] and (not extra or extra.get("intent", {}).get("intent_id") != plan["confirmed_intent_id"]):
            semantic_error("方案的已確認意圖不存在")
        if plan["direction_id"] and (not extra or extra.get("direction", {}).get("direction_id") != plan["direction_id"]):
            semantic_error("方案的職涯方向不存在")
        for block in plan["preferences"]["campus_blocks"]:
            if not con.execute("SELECT 1 FROM be02_references WHERE kind='campus' AND entity_id=?", (block["campus_id"],)).fetchone():
                semantic_error("偏好校區不存在")
        con.execute("INSERT INTO be02_snapshots VALUES (?,?,?,?,?,?,?)", (plan["input_snapshot_id"], plan["student_id"], plan["plan_id"], plan["revision"], canonical(snapshot), digest(snapshot), now()))
        con.execute("INSERT INTO be02_plan_versions VALUES (?,?,?,?,?,?,?,?,?)", (plan["plan_id"], plan["student_id"], plan["revision"], plan["input_snapshot_id"], canonical(plan), digest(plan), now(), actor, reason))
        con.execute("INSERT INTO be02_plan_heads VALUES (?,?,?,?,?) ON CONFLICT(plan_id) DO UPDATE SET revision=excluded.revision,state=excluded.state,validation_state=excluded.validation_state",
                    (plan["plan_id"], plan["student_id"], plan["revision"], plan["state"], plan["validation_state"]))
        self._audit(con, plan["student_id"], "plan", plan["plan_id"], plan["revision"], actor, reason, plan)

    def update_plan(self, principal, plan_id, patch, *, expected_revision):
        with self._session(write=True) as con:
            owner = self._authorize(con, principal, "self:write")
            plan = self._plan(con, owner, plan_id)
            self._match(plan["revision"], expected_revision)
            self.validation.validate("PlanPatch", patch)
            plan.update(deepcopy(patch))
            extra = {}
            if plan["confirmed_intent_id"]:
                intent = self._artifact(con, owner, "intent", plan["confirmed_intent_id"])
                if intent["plan_id"] != plan_id or intent["confirmation"] != "confirmed":
                    semantic_error("意圖尚未確認或不屬於此方案")
                extra["intent"] = intent
            if plan["direction_id"]:
                direction = self._artifact(con, owner, "direction", plan["direction_id"])
                # The owner alone is insufficient: directions must belong to the chosen intent's plan.
                row = con.execute("SELECT plan_id,intent_id FROM be02_direction_links WHERE student_id=? AND direction_id=?", (owner, plan["direction_id"])).fetchone()
                if not extra.get("intent") or not row or row[0] != plan_id or row[1] != plan["confirmed_intent_id"]:
                    semantic_error("職涯方向需要同一方案的已確認意圖")
                extra["direction"] = direction
            head = con.execute("SELECT * FROM be02_student_heads WHERE student_id=?", (owner,)).fetchone()
            catalog = con.execute("SELECT version FROM be02_catalog_heads WHERE term_id=?", (plan["term_id"],)).fetchone()
            rule = con.execute("SELECT h.version FROM be02_rule_heads h JOIN be02_rule_versions r ON r.rule_set_id=h.rule_set_id WHERE r.version=?", (plan["data_versions"]["rules"],)).fetchone()
            if not catalog or not rule:
                semantic_error("方案缺少有效課程或課規版本")
            plan["revision"] += 1
            plan["input_snapshot_id"] = "snap-" + uuid.uuid4().hex
            plan["data_versions"].update(profile=f"profile-v{head['profile_revision']}", records=f"records-v{head['records_revision']}", catalog=catalog[0], rules=rule[0])
            if "preferences" in patch:
                plan["data_versions"]["preferences"] = "preferences-" + uuid.uuid4().hex
            plan.update(state="draft", validation_state="not_evaluated")
            self._write_plan(con, plan, owner, "student_updated", extra)
            con.execute("UPDATE be02_artifact_heads SET is_current=0 WHERE student_id=? AND artifact_id IN (SELECT artifact_id FROM be02_artifact_versions WHERE student_id=? AND plan_id=?)", (owner, owner, plan_id))
            return plan

    def history(self, principal, kind, resource_id=None):
        with self._session() as con:
            owner = self._authorize(con, principal)
            if kind == "plan":
                self._plan(con, owner, resource_id)
                rows = con.execute("SELECT revision,sha256,created_at,actor_id,reason FROM be02_plan_versions WHERE student_id=? AND plan_id=? ORDER BY revision", (owner, resource_id))
            elif kind == "profile":
                rows = con.execute("SELECT revision,sha256,created_at,actor_id,reason,exploring_program_ids FROM be02_profile_versions WHERE student_id=? ORDER BY revision", (owner,))
            elif kind == "records":
                rows = con.execute("SELECT revision,version_label,coverage,sha256,created_at,actor_id FROM be02_record_versions WHERE student_id=? ORDER BY revision", (owner,))
            else:
                missing()
            return [dict(row) for row in rows]

    def audit_history(self, principal):
        with self._session() as con:
            owner = self._authorize(con, principal)
            return [dict(r) for r in con.execute("SELECT * FROM be02_audit_events WHERE student_id=? ORDER BY event_id", (owner,))]

    def seed_mock(self, dataset=None, examples=None, flows=None):
        if self.mode != "synthetic":
            raise StoreError(403, "FORBIDDEN", "正式資料庫禁止匯入Mock資料")
        dataset = deepcopy(dataset) if dataset is not None else json.loads((CONTRACT_ROOT / "mock/dataset.json").read_text(encoding="utf-8"))
        examples = deepcopy(examples) if examples is not None else json.loads((CONTRACT_ROOT / "examples.json").read_text(encoding="utf-8"))
        flows = deepcopy(flows) if flows is not None else json.loads((CONTRACT_ROOT / "mock/flows.json").read_text(encoding="utf-8"))
        self.validation.validate("MockDataset", dataset)
        workflow_hash = digest({"examples": examples, "flows": flows})
        with self._session(write=True) as con:
            prior = con.execute("SELECT * FROM be02_seed_runs WHERE dataset_id=?", (dataset["dataset_id"],)).fetchone()
            if prior:
                if prior["dataset_sha256"] != digest(dataset) or prior["workflow_sha256"] != workflow_hash:
                    raise StoreError(409, "IMMUTABLE_VERSION", "相同Mock識別碼的內容已改變")
                return {"already_imported": True, **json.loads(prior["summary"])}
            if con.execute("SELECT 1 FROM be02_principals LIMIT 1").fetchone():
                raise StoreError(409, "DATA_CONFLICT", "Mock種子僅可匯入空資料庫")
            self._check_sources(con, dataset, dataset["sources"])
            for principal in dataset["mock_principals"]:
                con.execute("INSERT INTO be02_principals(subject,kind) VALUES (?,?)", (principal["subject"], principal["kind"]))
                for permission in principal["permissions"]:
                    con.execute("INSERT INTO be02_permissions VALUES (?,?)", (principal["subject"], permission))
                con.execute("INSERT INTO be02_mock_tokens(token_digest,subject) VALUES (?,?)", (token_digest(principal["token_label"]), principal["subject"]))
            for source in dataset["sources"]:
                self._source(con, source)
            for kind, key, id_key in (("campus", "campuses", "campus_id"), ("program", "program_catalog", "program_id"), ("term", "terms", "term_id")):
                for value in dataset[key]:
                    con.execute("INSERT INTO be02_references VALUES (?,?,?,?)", (kind, value[id_key], canonical(value), digest(value)))
            for profile in dataset["profiles"]:
                if not con.execute("SELECT 1 FROM be02_principals WHERE subject=? AND kind='student'", (profile["student_id"],)).fetchone():
                    semantic_error("學生檔案需要對應學生身分")
                programs = {r[0] for r in con.execute("SELECT entity_id FROM be02_references WHERE kind='program'")}
                if any(p["program_id"] not in programs for p in profile["programs"]):
                    semantic_error("學生學程不存在")
                self._write_profile(con, profile, "mock-seed", [], "mock_imported")
                owner = profile["student_id"]
                records = [r for r in dataset["records"] if r["student_id"] == owner]
                recognitions = [r for r in dataset["recognition_decisions"] if r["student_id"] == owner]
                evidence = [r for r in dataset["non_credit_evidence"] if r["student_id"] == owner]
                coverage = dataset["record_coverage"].get(owner, "unknown")
                con.execute("INSERT INTO be02_record_versions VALUES (?,?,?,?,?,?,?)", (owner, 1, "records-v1", coverage, digest({"records": records, "recognitions": recognitions, "evidence": evidence, "coverage": coverage}), now(), "mock-seed"))
                for record in records:
                    con.execute("INSERT INTO be02_records VALUES (?,?,?,?,?,?)", (owner, 1, record["record_id"], record["course_id"], record["source_record_key"], canonical(record)))
                for kind, items, id_key in (("recognition", recognitions, "decision_id"), ("non_credit", evidence, "evidence_id")):
                    for item in items:
                        con.execute("INSERT INTO be02_academic_evidence VALUES (?,?,?,?,?)", (owner, 1, kind, item[id_key], canonical(item)))
                for kind, values, revision in (("profile", profile, profile["revision"]), ("record", [records, recognitions, evidence], 1)):
                    ids = self._source_ids(values)
                    for source in dataset["sources"]:
                        if source["source_id"] in ids:
                            con.execute(f"INSERT INTO be02_{kind}_sources VALUES (?,?,?,?)", (owner, revision, source["source_id"], source["version"]))
                con.execute("INSERT INTO be02_student_heads VALUES (?,?,?,?)", (owner, profile["revision"], 1, "[]"))
                self._audit(con, owner, "records", owner, 1, "mock-seed", "mock_imported", records)
            owners = {p["student_id"] for p in dataset["profiles"]}
            if any(r["student_id"] not in owners for key in ("records", "recognition_decisions", "non_credit_evidence") for r in dataset[key]):
                semantic_error("學生紀錄沒有對應身分")
            for rule in dataset["rule_sets"]:
                ids = self._source_ids(rule)
                self._rules(con, rule, [s for s in dataset["sources"] if s["source_id"] in ids], "mock-seed")
            for term in dataset["terms"]:
                plans = [p for p in dataset["plans"] if p["term_id"] == term["term_id"]]
                versions = {p["data_versions"]["catalog"] for p in plans}
                if len(versions) != 1:
                    semantic_error("Mock課程版本必須明確")
                offerings = [o for o in dataset["offerings"] if o["term_id"] == term["term_id"]]
                source_ids = self._source_ids([dataset["courses"], offerings])
                self._catalog(con, {"version": versions.pop(), "term_id": term["term_id"], "sources": [s for s in dataset["sources"] if s["source_id"] in source_ids], "courses": dataset["courses"], "offerings": offerings}, "mock-seed")
            artifacts = self._mock_artifacts(dataset, examples, flows)
            for plan in sorted(dataset["plans"], key=lambda p: (p["plan_id"], p["revision"])):
                extra = {kind: value for owner, kind, _, value in artifacts if owner == plan["student_id"] and value.get("plan_id", plan["plan_id"]) == plan["plan_id"] and ((kind == "intent" and value["intent_id"] == plan["confirmed_intent_id"] and value["confirmation"] == "confirmed") or (kind == "direction" and value["direction_id"] == plan["direction_id"]))}
                self._write_plan(con, plan, "mock-seed", "mock_imported", extra)
            direction_links = {}
            example_map = {e["example_id"]: e for e in examples["examples"]}
            for flow in flows["flows"]:
                if "stage2-directions" in flow["example_ids"]:
                    response = example_map["stage2-directions"]["response"]["body"]["data"]
                    intent = next(a[3] for a in artifacts if a[0] == flow["student_id"] and a[1] == "intent" and a[2] == response["intent_id"])
                    for direction in response["options"]:
                        direction_links[(flow["student_id"], direction["direction_id"])] = (intent["intent_id"], intent["plan_id"])
            for owner, kind, artifact_id, value in artifacts:
                if kind == "eligibility":
                    plan_id = example_map[artifact_id]["request"]["body"]["plan_id"]
                else:
                    plan_id = value.get("plan_id") or direction_links[(owner, artifact_id)][1]
                previous = con.execute("SELECT revision FROM be02_artifact_heads WHERE student_id=? AND kind=? AND artifact_id=?", (owner, kind, artifact_id)).fetchone()
                revision = previous[0]+1 if previous else 1
                con.execute("INSERT INTO be02_artifact_versions VALUES (?,?,?,?,?,?,?,?)", (owner, kind, artifact_id, revision, plan_id, canonical(value), digest(value), now()))
                con.execute("INSERT INTO be02_artifact_heads VALUES (?,?,?,?,0) ON CONFLICT(student_id,kind,artifact_id) DO UPDATE SET revision=excluded.revision", (owner, kind, artifact_id, revision))
                if kind == "direction":
                    con.execute("INSERT INTO be02_direction_links VALUES (?,?,?,?)", (owner, artifact_id, direction_links[(owner, artifact_id)][0], plan_id))
            summary = {"dataset_id": dataset["dataset_id"], "students": len(dataset["profiles"]), "records": len(dataset["records"]), "courses": len(dataset["courses"]), "offerings": len(dataset["offerings"]), "plan_revisions": len(dataset["plans"]), "artifacts": len(artifacts)}
            con.execute("INSERT INTO be02_seed_runs VALUES (?,?,?,?,?)", (dataset["dataset_id"], digest(dataset), workflow_hash, now(), canonical(summary)))
            return {"already_imported": False, **summary}

    @staticmethod
    def _source_ids(value):
        result = set()
        def walk(child):
            if isinstance(child, dict):
                result.update(r["source_id"] for r in child.get("source_refs", []))
                for nested in child.values():
                    walk(nested)
            elif isinstance(child, list):
                for nested in child:
                    walk(nested)
        walk(value)
        return result

    def _mock_artifacts(self, dataset, examples, flows):
        by_example = {e["example_id"]: e for e in examples["examples"]}
        plan_owners = {p["plan_id"]: p["student_id"] for p in dataset["plans"]}
        result = []
        mapping = {"stage2-intent": ("intent", "intent_id", "Intent"), "stage2-intent-confirm": ("intent", "intent_id", "Intent"),
                   "stage4-validate": ("validation", "validation_id", "Validation"), "stage4-confirm": ("confirmation", "confirmation_id", "Confirmation"),
                   "stage4-export": ("export", "export_id", "Export"), "stage4-report": ("registration", "report_id", "RegistrationResult")}
        for flow in flows["flows"]:
            owner = flow["student_id"]
            for example_id in flow["example_ids"]:
                if example_id not in by_example:
                    semantic_error("Mock流程參照不存在")
                if example_id in mapping:
                    kind, id_key, schema = mapping[example_id]
                    value = by_example[example_id]["response"]["body"]["data"]
                    self.validation.validate(schema, value)
                    if plan_owners.get(value["plan_id"]) != owner:
                        semantic_error("Mock私有資料與方案擁有者不符")
                    result.append((owner, kind, value[id_key], value))
                elif example_id == "stage2-directions":
                    data = by_example[example_id]["response"]["body"]["data"]
                    intent = next((a[3] for a in reversed(result) if a[0] == owner and a[1] == "intent" and a[2] == data["intent_id"]), None)
                    if not intent:
                        semantic_error("職涯方向缺少對應意圖")
                    for value in data["options"]:
                        self.validation.validate("Direction", value)
                        # Preserve exact BE-01 payload; ownership is relational metadata.
                        result.append((owner, "direction", value["direction_id"], value))
        # Independent cases remain private historical outputs, outside the happy path.
        principals = {"Bearer " + p["token_label"]: p["subject"] for p in dataset["mock_principals"]}
        for example_id in ("stage2-eligibility-pass", "stage2-eligibility-fail", "stage2-eligibility-review"):
            example = by_example[example_id]
            request = example["request"]
            owner = plan_owners.get(request["body"]["plan_id"])
            if not owner or principals.get(request["headers"]["Authorization"]) != owner:
                semantic_error("資格測例的身分與方案不符")
            value = example["response"]["body"]["data"]
            self.validation.validate("EligibilityList", value)
            result.append((owner, "eligibility", example_id, value))
        imported_directions = [item[3] for item in result if item[1] == "direction"]
        if sorted(map(canonical, imported_directions)) != sorted(map(canonical, dataset["directions"])):
            semantic_error("Mock方向資料與主流程選項不一致")
        return result
