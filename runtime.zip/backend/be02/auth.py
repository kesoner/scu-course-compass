from dataclasses import dataclass, field


@dataclass(frozen=True)
class Principal:
    """Server-issued identity. Repository rechecks its credential on every call."""
    subject: str
    kind: str
    _credential_digest: str = field(repr=False)
    _issuer: str = field(repr=False)


class MockAuthenticator:
    """Explicit synthetic-only adapter; never a production authentication method."""

    def __init__(self, repository):
        self.repository = repository

    def authenticate(self, authorization):
        return self.repository._authenticate_mock(authorization)
