"""Loopback MVP with isolated synthetic planning and local personal progress."""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import io
import json
import mimetypes
import os
import re
import secrets
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from . import domain
from .gemini_client import GeminiClient
from backend.be02.errors import StoreError
from backend.public_catalog import PublicCatalogAPI, PREFIX as PUBLIC_CATALOG_PREFIX
from backend.public_reference import DEFAULT_REFERENCE

ROOT = Path(__file__).resolve().parents[1]
APP_ROOT = Path(__file__).resolve().parent
DEMO_CLOCK = '2026-11-02T10:00:00+08:00'
PROFILES = [
    {'id': 'phi-demo', 'name': '林予安', 'department': '哲學系', 'year': 2,
     'scenario_id': 'PERSONA-PHI-001', 'description': '從活動開始，慢慢探索職涯方向', 'synthetic': True},
    {'id': 'pol-demo', 'name': '小明', 'department': '政治系', 'year': 2,
     'scenario_id': 'SYN-MVP-001', 'description': '以合成學分與排課資料體驗選課規劃', 'synthetic': True},
]


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def load_env(path=None):
    """Read only the project's optional .env without printing or exposing values."""
    source = Path(path) if path else APP_ROOT / '.env'
    if source.is_file():
        for line in source.read_text(encoding='utf-8-sig').splitlines():
            line = line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            name, value = line.split('=', 1)
            if name.strip() in {'GEMINI_API_KEY', 'GEMINI_PRIMARY_MODEL', 'GEMINI_FALLBACK_MODEL'}:
                os.environ.setdefault(name.strip(), value.strip().strip('\"\''))


class APIError(Exception):
    def __init__(self, status, code, message):
        super().__init__(message)
        self.status, self.code, self.message = status, code, message


class DemoApp:
    def __init__(self, data_dir=None, client=None, public_catalog_path=None, public_reference_path=DEFAULT_REFERENCE):
        self.data_dir = Path(data_dir) if data_dir else APP_ROOT / 'data/runtime'
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.export_dir = self.data_dir / 'exports'
        self.export_dir.mkdir(exist_ok=True)
        self.db_path = self.data_dir / 'demo.sqlite3'
        self.lock = threading.RLock()
        self.sessions = {}
        self.client = client or GeminiClient()
        self.four_stage = None
        self._personal_store = None
        self.public_catalog = PublicCatalogAPI(public_catalog_path, reference_path=public_reference_path)
        self.be02_path = self.data_dir / 'be02.sqlite3' if data_dir else ROOT / 'backend/data/runtime/be02.sqlite3'
        with self.connection() as conn:
            conn.execute('CREATE TABLE IF NOT EXISTS demo_state (profile_id TEXT PRIMARY KEY, payload TEXT NOT NULL)')

    @contextmanager
    def connection(self):
        conn = sqlite3.connect(self.db_path, timeout=5)
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def four_stage_api(self):
        with self.lock:
            if self.four_stage is None:
                from backend.be02.runtime import FourStageAPI
                self.four_stage = FourStageAPI(self.be02_path, client=self.client, public_catalog=self.public_catalog)
        return self.four_stage

    def personal_store(self):
        with self.lock:
            if self._personal_store is None:
                from backend.personal_store import PersonalStore
                self._personal_store = PersonalStore(self.data_dir/'personal/progress.sqlite3')
        return self._personal_store

    def profile(self, profile_id):
        for profile in PROFILES:
            if profile['id'] == profile_id:
                return copy.deepcopy(profile)
        raise APIError(400, 'unknown_profile', '請選擇一個合成示範身分。')

    def claims(self, profile_id):
        profile = self.profile(profile_id)
        return {'iss': 'demo://synthetic-sso', 'sub': profile_id, 'name': profile['name'],
                'department': profile['department'], 'year': profile['year'], 'synthetic': True,
                'auth_mode': 'synthetic_sso_demo', 'real_sso_connected': False}

    def default_state(self, profile_id):
        return {'profile_id': profile_id, 'revision': 1, 'variant': 'baseline', 'prefer_no_friday': True,
                'input_snapshot_id': 'snap-' + secrets.token_hex(12),
                'preferences': {'interests': ['文字表達', '社會議題', '工作日常'], 'budget': 0,
                                'formats': ['線上', '校內'],
                                'notification': {'enabled': False, 'weekly_limit': 1, 'max_items': 3,
                                                 'quiet_start': '22:00', 'quiet_end': '08:00'}},
                'feedback': {}, 'digest_history': [], 'confirmation': None, 'exports': []}

    def read_state(self, profile_id):
        with self.connection() as conn:
            row = conn.execute('SELECT payload FROM demo_state WHERE profile_id=?', (profile_id,)).fetchone()
        return json.loads(row[0]) if row else self.default_state(profile_id)

    def save_state(self, state):
        with self.connection() as conn:
            conn.execute('INSERT INTO demo_state VALUES (?,?) ON CONFLICT(profile_id) DO UPDATE SET payload=excluded.payload',
                         (state['profile_id'], json.dumps(state, ensure_ascii=False)))

    def login(self, profile_id):
        profile = self.profile(profile_id)
        with self.lock:
            token = secrets.token_urlsafe(32)
            self.sessions[token] = profile_id
            self.save_state(self.read_state(profile_id))
        return {'token': token, 'profile': profile, 'claims': self.claims(profile_id), 'synthetic': True}

    def authorize(self, authorization):
        token = authorization[7:] if authorization.startswith('Bearer ') else ''
        with self.lock:
            profile_id = self.sessions.get(token)
        if not profile_id:
            raise APIError(401, 'demo_session_required', '示範工作階段已結束，請重新選擇合成身分。')
        return profile_id

    def fixture_for(self, state):
        fixture = domain.load_fixture()
        variant = state['variant']
        if variant == 'missing_record':
            fixture['completed_attempts'] = [a for a in fixture['completed_attempts'] if a['course_id'] != 'CS101']
        elif variant == 'no_solution':
            fixture['offerings'] = [o for o in fixture['offerings'] if o['id'] != 'DS201-B']
        fixture['scope']['data_version'] += ':' + variant
        return fixture

    def view(self, state):
        profile = self.profile(state['profile_id'])
        prefs = copy.deepcopy(state['preferences'])
        candidates = domain.recommend_activities(prefs, DEMO_CLOCK)
        for item in candidates:
            item['feedback'] = copy.deepcopy(state['feedback'].get(item['id'], {}))
        academic = profile['scenario_id'] == 'SYN-MVP-001'
        fixture = self.fixture_for(state) if academic else None
        plans = domain.search_plans(fixture, 0 if state['variant'] == 'search_timeout' else 500,
                                    state['prefer_no_friday']) if academic else {'status': 'not_applicable', 'plans': []}
        return {'profile': profile, 'claims': self.claims(state['profile_id']), 'preferences': prefs,
                'feedback': state['feedback'], 'activities': candidates,
                'digest_history': state['digest_history'], 'academic_available': academic,
                'fixture': fixture, 'credits': domain.analyze_credits(fixture) if academic else None,
                'plans': plans, 'input_snapshot_id': state['input_snapshot_id'], 'revision': state['revision'],
                'variant': state['variant'], 'prefer_no_friday': state['prefer_no_friday'],
                'confirmation': state['confirmation'], 'exports': state['exports'],
                'model': self.client.status(), 'demo_clock': DEMO_CLOCK,
                'synthetic': True, 'csrf_enabled': False}

    def invalidate(self, state):
        state['revision'] += 1
        state['input_snapshot_id'] = 'snap-' + secrets.token_hex(12)
        state['confirmation'] = None

    def preferences(self, state, payload):
        prefs = copy.deepcopy(state['preferences'])
        for key in ('interests', 'formats'):
            if key in payload:
                value = payload[key]
                if not isinstance(value, list) or len(value) > 20 or any(not isinstance(x, str) or len(x) > 40 for x in value):
                    raise APIError(400, 'invalid_preferences', '興趣與活動形式需為有效清單。')
                prefs[key] = list(dict.fromkeys(value))
        if 'budget' in payload:
            value = payload['budget']
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 <= value <= 10000:
                raise APIError(400, 'invalid_budget', '預算需介於0至10000。')
            prefs['budget'] = value
        if 'notification' in payload:
            notification = payload['notification']
            if not isinstance(notification, dict):
                raise APIError(400, 'invalid_notification', '通知設定格式有誤。')
            for key in ('enabled', 'quiet_start', 'quiet_end', 'max_items'):
                if key not in notification:
                    continue
                value = notification[key]
                if key == 'enabled' and not isinstance(value, bool):
                    raise APIError(400, 'invalid_notification', '通知啟用需為是或否。')
                if key in ('quiet_start', 'quiet_end') and (not isinstance(value, str) or not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d', value)):
                    raise APIError(400, 'invalid_quiet_time', '安靜時段請使用24小時制時間。')
                if key == 'max_items' and (isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 3):
                    raise APIError(400, 'invalid_limit', '每份摘要最多1至3則。')
                prefs['notification'][key] = value
        if prefs != state['preferences']:
            state['preferences'] = prefs
            self.invalidate(state)
        return state

    def academic_required(self, state):
        if state['profile_id'] != 'pol-demo':
            raise APIError(409, 'academic_scenario_required', '此人物沒有學分測例，請切換政治系合成情境。')

    def plan(self, state, plan_id):
        self.academic_required(state)
        result = self.view(state)['plans']
        plan = next((p for p in result.get('plans', []) if p['id'] == plan_id), None)
        if not plan or plan.get('status') not in ('feasible', None):
            raise APIError(409, 'plan_unavailable', '此版本沒有可確認的指定方案，請重新計算。')
        return plan

    def chat_context(self, state, message):
        view = self.view(state)
        paths = [
            ('KB-SOLUTIONS', 'knowledge-base/04-解決方案.md', '產品範圍與採計界線'),
            ('PERSONA-PHI-001', 'knowledge-base/personas/哲學系迷茫學生-活動探索使用者地圖.md', '活動探索人物情境'),
        ]
        sources, knowledge = [], []
        for source_id, path, label in paths:
            file = ROOT / path
            if file.exists():
                sources.append({'id': source_id, 'path': path, 'label': label})
                knowledge.append({'source_id': source_id, 'text': file.read_text(encoding='utf-8-sig')[:7000]})
        return {'scenario_id': view['profile']['scenario_id'], 'profile': view['profile'],
                'credits': view['credits'], 'plans': view['plans'],
                'activities': [a for a in view['activities'] if a.get('eligible') and not a.get('feedback', {}).get('dismissed')][:4],
                'sources': sources, 'knowledge': knowledge,
                'app_scope': '本地合成MVP；SSO為合成身分；摘要僅預覽；學分由確定性規則計算。'}

    def handle(self, method, path, payload, authorization=''):
        if method == 'GET' and path == '/api/health':
            return {'status': 'ok', 'app_id': 'career-course-mvp', 'synthetic': True, 'csrf_enabled': False}
        if method == 'GET' and path == '/api/bootstrap':
            return {'profiles': PROFILES, 'model': self.client.status(), 'demo_clock': DEMO_CLOCK,
                    'synthetic': True, 'sso_mode': 'synthetic_sso_demo', 'csrf_enabled': False}
        if method == 'POST' and path == '/api/demo/login':
            return self.login(payload.get('profile_id'))
        profile_id = self.authorize(authorization)
        if method == 'POST' and path == '/api/demo/logout':
            with self.lock:
                self.sessions.pop(authorization[7:], None)
            return {'logged_out': True}
        if method == 'POST' and path == '/api/chat':
            message = payload.get('message', '')
            if not isinstance(message, str) or not message.strip() or len(message) > 4000:
                raise APIError(400, 'invalid_message', '請輸入1至4000字的問題。')
            with self.lock:
                context = self.chat_context(self.read_state(profile_id), message)
            result = self.client.chat(message.strip(), context, payload.get('history', []))
            result['sources'] = context['sources']
            return result
        with self.lock:
            state = self.read_state(profile_id)
            if method == 'GET' and path == '/api/state':
                return self.view(state)
            if method == 'GET' and path == '/api/activities':
                return {'activities': self.view(state)['activities']}
            if method == 'POST' and path in ('/api/credits/analyze', '/api/plans/search'):
                self.academic_required(state)
                if payload.get('input_snapshot_id', state['input_snapshot_id']) != state['input_snapshot_id']:
                    raise APIError(409, 'stale_snapshot', '輸入版本已變更，請重新計算。')
                view = self.view(state)
                return view['credits'] if path.endswith('/analyze') else view['plans']
            if method == 'PUT' and path == '/api/preferences':
                self.preferences(state, payload)
            elif method == 'POST' and path == '/api/snapshots':
                self.academic_required(state)
                variant = payload.get('variant', 'baseline')
                if variant not in ('baseline', 'missing_record', 'no_solution', 'search_timeout'):
                    raise APIError(400, 'invalid_variant', '不支援這個示範資料變體。')
                preference = payload.get('prefer_no_friday', True)
                if not isinstance(preference, bool):
                    raise APIError(400, 'invalid_preference', '時間偏好需為是或否。')
                state.update(variant=variant, prefer_no_friday=preference)
                self.invalidate(state)
            elif method == 'POST' and path == '/api/digests/preview':
                now = payload.get('now', DEMO_CLOCK)
                try:
                    parsed = datetime.fromisoformat(now)
                    if parsed.tzinfo is None:
                        raise ValueError('timezone required')
                except (ValueError, TypeError):
                    raise APIError(400, 'invalid_demo_time', '示範時鐘需為含時區的ISO日期時間。')
                prior = [x['dedupe_key'] for x in state['digest_history'] if x.get('status') == 'ready']
                excluded_ids = [activity_id for activity_id, feedback in state['feedback'].items() if feedback.get('dismissed')]
                digest = domain.build_digest({**state['preferences'], 'id': profile_id,
                                              'excluded_activity_ids': excluded_ids}, now, prior)
                digest['delivery_mode'], digest['sent'] = 'preview', False
                state['digest_history'] = (state['digest_history'] + [digest])[-30:]
                self.save_state(state)
                return digest
            elif method == 'POST' and path == '/api/activity-feedback':
                activity_id, action = payload.get('activity_id'), payload.get('action')
                ids = {a['id'] for a in self.view(state)['activities']}
                if activity_id not in ids or action not in ('saved', 'dismissed', 'registered_self_report', 'participated_self_report', 'reflection'):
                    raise APIError(400, 'invalid_feedback', '活動或回顧操作不正確。')
                feedback = state['feedback'].setdefault(activity_id, {})
                if action == 'reflection':
                    text = payload.get('text', '')
                    if not isinstance(text, str) or len(text) > 1500:
                        raise APIError(400, 'invalid_reflection', '回顧需在1500字以內。')
                    feedback['reflection'] = text
                else:
                    feedback[action] = not feedback.get(action, False)
                feedback['updated_at'] = utc_now()
            elif method == 'POST' and path == '/api/plans/check':
                self.academic_required(state)
                ids = payload.get('offering_ids')
                if not isinstance(ids, list) or len(ids) > 30 or any(not isinstance(x, str) for x in ids):
                    raise APIError(400, 'invalid_offerings', '請提供班別清單。')
                fixture = self.fixture_for(state)
                if set(ids) - {o['id'] for o in fixture['offerings']}:
                    raise APIError(400, 'unknown_offering', '目前版本不存在指定班別。')
                return domain.check_plan(fixture, ids)
            elif method == 'POST' and re.fullmatch(r'/api/plans/[^/]+/confirm', path):
                if payload.get('input_snapshot_id') != state['input_snapshot_id']:
                    raise APIError(409, 'stale_snapshot', '輸入版本已變更，請重新確認目前方案。')
                plan_id = path.split('/')[3]
                plan = self.plan(state, plan_id)
                confirmation_id = 'confirm-' + secrets.token_hex(12)
                state['confirmation'] = {'id': confirmation_id, 'confirmation_id': confirmation_id,
                                         'plan_id': plan_id, 'input_snapshot_id': state['input_snapshot_id'],
                                         'offering_ids': plan['offering_ids'], 'confirmed_at': utc_now()}
                self.save_state(state)
                return {'confirmation': state['confirmation'], **state['confirmation']}
            elif method == 'POST' and path == '/api/exports':
                self.academic_required(state)
                confirmation = state['confirmation']
                if not confirmation or payload.get('confirmation_id') != confirmation['id'] or confirmation['input_snapshot_id'] != state['input_snapshot_id']:
                    raise APIError(409, 'confirmation_required', '請先確認目前版本的方案，再產生選課清單。')
                if payload.get('simulate_failure') is True:
                    raise APIError(503, 'demo_export_failure', '已模擬匯出失敗；方案與確認已保留，可再次匯出。')
                fixture = self.fixture_for(state)
                export_id = 'export-' + secrets.token_hex(12)
                metadata = {'scenario_id': 'SYN-MVP-001', 'plan_id': confirmation['plan_id'],
                            'input_snapshot_id': state['input_snapshot_id'], 'export_id': export_id,
                            'generated_at': utc_now(), 'data_version': fixture['scope']['data_version'],
                            'rule_version': fixture['scope']['rule_version'], 'synthetic': True}
                rows = domain.rows_for_export(fixture, confirmation['offering_ids'], metadata)
                stream = io.StringIO(newline='')
                writer = csv.DictWriter(stream, fieldnames=fixture['export_design']['columns'], extrasaction='ignore')
                writer.writeheader()
                writer.writerows(rows)
                data = stream.getvalue().encode('utf-8-sig')
                file_name = f'DEMO-SYN-MVP-001-{confirmation["plan_id"]}-{export_id}.csv'
                file = self.export_dir / file_name
                file.write_bytes(data)
                record = {**metadata, 'id': export_id, 'file_name': file_name, 'filename': file_name,
                          'confirmation_id': confirmation['id'], 'download_url': '/api/exports/' + export_id,
                          'sha256': hashlib.sha256(data).hexdigest(), 'row_count': len(rows)}
                state['exports'].append(record)
                self.save_state(state)
                return record
            elif method == 'GET' and re.fullmatch(r'/api/exports/export-[a-f0-9]+', path):
                export_id = path.rsplit('/', 1)[-1]
                record = next((e for e in state['exports'] if e['export_id'] == export_id), None)
                if not record or not (self.export_dir / record['file_name']).is_file():
                    raise APIError(404, 'export_not_found', '找不到此工作階段的匯出檔案。')
                return ('file', self.export_dir / record['file_name'], record['file_name'])
            elif method == 'POST' and path == '/api/demo/reset':
                state = self.default_state(profile_id)
            else:
                raise APIError(404, 'not_found', '找不到此操作。')
            self.save_state(state)
            return self.view(state)


def create_server(app, port=8765):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.dispatch('GET')

        def do_POST(self):
            self.dispatch('POST')

        def do_PUT(self):
            self.dispatch('PUT')

        def do_PATCH(self):
            self.dispatch('PATCH')

        def do_DELETE(self):
            self.dispatch('DELETE')

        def log_message(self, fmt, *args):
            # Do not log request bodies, headers, API keys or student reflections.
            return

        def json_response(self, status, value):
            data = json.dumps(value, ensure_ascii=False).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            if getattr(self, '_resource_etag', None):
                self.send_header('ETag', self._resource_etag)
                self._resource_etag = None
            self.end_headers()
            self.wfile.write(data)

        def dispatch(self, method):
            try:
                path = urlparse(self.path).path
                if path == '/personal/connect' or path.startswith('/api/personal/'):
                    from backend.personal_store import COOKIE
                    host = urlparse('http://'+self.headers.get('Host', '')).hostname
                    origin = self.headers.get('Origin')
                    if host not in ('127.0.0.1', 'localhost') or origin and (urlparse(origin).hostname != host or urlparse(origin).port != self.server.server_port):
                        raise APIError(403, 'personal_origin_rejected', '個人資料僅供本機同來源使用。')
                    if method != 'GET':
                        raise APIError(405, 'personal_read_only', '個人資料由本機匯入工具建立版本，網頁僅供查閱。')
                    store = app.personal_store()
                    query = parse_qs(urlparse(self.path).query)
                    if path == '/personal/connect':
                        token = store.connect_ticket(query.get('ticket', [''])[0])
                        self.send_response(303)
                        self.send_header('Set-Cookie', COOKIE+'='+token+'; HttpOnly; SameSite=Strict; Path=/api/personal; Max-Age=604800')
                        self.send_header('Location', '/four-stage')
                        self.send_header('Referrer-Policy', 'no-referrer')
                        self.send_header('Cache-Control', 'no-store')
                        self.send_header('Content-Length', '0')
                        self.end_headers()
                        return
                    if self.headers.get('X-Personal-Request') != 'progress-ui':
                        raise APIError(403, 'personal_request_rejected', '請從本機修課進度介面查閱。')
                    try:
                        owner = store.authorize(self.headers)
                    except StoreError:
                        if path != '/api/personal/status':
                            raise
                        self.json_response(200, {'data': {'connected': False}})
                        return
                    if path == '/api/personal/status':
                        data = {'connected': True}
                    elif path == '/api/personal/versions':
                        data = {'items': store.history(owner)}
                    elif path == '/api/personal/progress':
                        value = query.get('revision', [None])[0]
                        if value is not None and not re.fullmatch(r'[1-9]\d*', value):
                            raise APIError(400, 'invalid_revision', '版本號格式不正確。')
                        data = store.read(owner, int(value) if value else None)
                    else:
                        raise APIError(404, 'not_found', '找不到此個人資料操作。')
                    self.json_response(200, {'meta': {'data_mode': 'personal_local', 'contract_version': 'personal-progress-1'}, 'data': data})
                    return
                if path == PUBLIC_CATALOG_PREFIX or path.startswith(PUBLIC_CATALOG_PREFIX + '/'):
                    # Drain a bounded body before rejecting writes, so a close with unread bytes
                    # cannot reset the connection before the client receives the 405 response.
                    if method != 'GET':
                        try:
                            public_size = int(self.headers.get('Content-Length', '0'))
                        except ValueError:
                            public_size = -1
                        if public_size < 0 or public_size > 65536:
                            error = StoreError(413, 'PUBLIC_CATALOG_REQUEST_TOO_LARGE', '要求內容過大或格式有誤。')
                            self.json_response(error.status, {'meta': PublicCatalogAPI.meta(), 'error': error.as_error()})
                            return
                        if public_size:
                            self.rfile.read(public_size)
                    status, result = app.public_catalog.handle(method, self.path)
                    self.json_response(status, result)
                    return
                if not path.startswith('/api/'):
                    mapping = {'/': 'index.html', '/index.html': 'index.html', '/app.js': 'app.js', '/styles.css': 'styles.css',
                               '/brand.css': 'brand.css', '/brand-logo.png': 'brand-logo.png',
                               '/four-stage': 'four-stage.html', '/four-stage.html': 'four-stage.html',
                               '/course-explorer': 'course-explorer.html', '/course-explorer.js': 'course-explorer.js',
                               '/public-course-catalog.js': 'public-course-catalog.js', '/public-course-catalog.css': 'public-course-catalog.css',
                               '/four-stage.js': 'four-stage.js', '/four-stage.css': 'four-stage.css', '/personal-progress.js': 'personal-progress.js',
                               '/learning-support.js': 'learning-support.js', '/service-info': 'service-info.html'}
                    if method != 'GET' or path not in mapping:
                        raise APIError(404, 'not_found', '找不到頁面。')
                    file = APP_ROOT / 'static' / mapping[path]
                    if not file.is_file():
                        raise APIError(503, 'frontend_pending', '介面尚未就緒。')
                    data = file.read_bytes()
                    self.send_response(200)
                    self.send_header('Content-Type', (mimetypes.guess_type(str(file))[0] or 'application/octet-stream') + '; charset=utf-8')
                    self.send_header('Content-Length', str(len(data)))
                    self.send_header('Cache-Control', 'no-store')
                    self.end_headers()
                    self.wfile.write(data)
                    return
                payload = {}
                if method in ('POST', 'PUT', 'PATCH'):
                    if self.headers.get('Content-Type', '').split(';', 1)[0].lower() != 'application/json':
                        raise APIError(415, 'json_required', '請使用JSON格式。')
                    try:
                        size = int(self.headers.get('Content-Length', '0'))
                    except ValueError:
                        raise APIError(400, 'invalid_size', '要求格式有誤。')
                    if size < 0 or size > 65536:
                        raise APIError(413, 'request_too_large', '要求內容過大。')
                    try:
                        payload = json.loads(self.rfile.read(size))
                    except (ValueError, UnicodeError):
                        raise APIError(400, 'invalid_json', 'JSON內容有誤。')
                    if not isinstance(payload, dict):
                        raise APIError(400, 'object_required', 'JSON需為物件。')
                if path.startswith('/api/v1/'):
                    status, result = app.four_stage_api().handle(method, self.path, payload, self.headers)
                    if isinstance(result, dict) and 'bytes' in result:
                        data = result['bytes']
                        self.send_response(status)
                        self.send_header('Content-Type', result['mime_type'])
                        self.send_header('Content-Disposition', 'attachment; filename="' + result['file_name'] + '"')
                        self.send_header('Content-Length', str(len(data)))
                        self.send_header('Cache-Control', 'no-store')
                        self.send_header('X-Content-Type-Options', 'nosniff')
                        self.end_headers()
                        self.wfile.write(data)
                    else:
                        if isinstance(result.get('data'), dict) and 'revision' in result['data']:
                            self._resource_etag = '"' + str(result['data']['revision']) + '"'
                        self.json_response(status, result)
                    return
                result = app.handle(method, path, payload, self.headers.get('Authorization', ''))
                if isinstance(result, tuple) and result[0] == 'file':
                    data = result[1].read_bytes()
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/csv; charset=utf-8')
                    self.send_header('Content-Disposition', 'attachment; filename="' + result[2] + '"')
                    self.send_header('Content-Length', str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                else:
                    self.json_response(200, result)
            except StoreError as exc:
                from backend.be02.runtime import FourStageAPI
                self.json_response(exc.status, {'meta': FourStageAPI.meta(), 'error': exc.as_error()})
            except APIError as exc:
                if path.startswith('/api/v1/'):
                    from backend.be02.runtime import FourStageAPI
                    self.json_response(exc.status, {'meta': FourStageAPI.meta(), 'error': StoreError(exc.status, exc.code.upper(), exc.message).as_error()})
                else:
                    self.json_response(exc.status, {'error': {'code': exc.code, 'message': exc.message}})
            except (BrokenPipeError, ConnectionResetError):
                return
            except Exception:
                if path.startswith('/api/v1/'):
                    from backend.be02.runtime import FourStageAPI
                    self.json_response(500, {'meta': FourStageAPI.meta(), 'error': StoreError(500, 'INTERNAL_ERROR', '本機服務未完成操作，請重試。').as_error()})
                else:
                    self.json_response(500, {'error': {'code': 'internal_error', 'message': '本機服務未完成操作，請重試。'}})

    server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    server.daemon_threads = True
    return server


def main():
    parser = argparse.ArgumentParser(description='Local synthetic career course MVP')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--data-dir', type=Path)
    parser.add_argument('--public-catalog-db', type=Path)
    args = parser.parse_args()
    load_env()
    app = DemoApp(args.data_dir, public_catalog_path=args.public_catalog_db)
    server = create_server(app, args.port)
    print(f'Local: http://127.0.0.1:{server.server_port}', flush=True)
    print('Synthetic SSO and data. CSRF disabled for this local demo. Gemini key configured: ' + str(app.client.status()['configured']), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
