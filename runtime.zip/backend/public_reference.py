"""Versioned, evidence-backed reference overlay. Original catalog stays immutable."""
from copy import deepcopy
import hashlib
import html
import json
from pathlib import Path
import re
import unicodedata

DEFAULT_REFERENCE = Path(__file__).resolve().parents[1]/'contracts/scu-course-catalog/references/scu-schedule-20261026.json'


class PublicScheduleReference:
    def __init__(self, path=DEFAULT_REFERENCE):
        self.data = None
        self.state = 'disabled' if path is None else 'unavailable'
        if path is None:
            return
        try:
            path = Path(path)
            raw = path.read_bytes()
            data = json.loads(raw)
            evidence = path.parent/data['source']['evidence_file']
            if evidence.resolve().parent != path.parent.resolve():
                raise ValueError('evidence outside reference folder')
            evidence_raw = evidence.read_bytes()
            if hashlib.sha256(evidence_raw).hexdigest() != data['source']['sha256']:
                raise ValueError('evidence checksum mismatch')
            if data['schema_version'] != 1 or data['source']['url'] != 'https://web-ch.scu.edu.tw/regcurr/web_page/16474':
                raise ValueError('unsupported reference')
            for code, pair in data['sessions'].items():
                if code not in set('1234E5678ABCD') or not self.valid_minutes(pair):
                    raise ValueError('invalid session rule')
            for rule in data['session_9_contexts']:
                if not self.valid_minutes(rule['minutes']) or rule['sequence'] not in (['7','8','9'],['9','A','B']):
                    raise ValueError('invalid contextual rule')
            if any(campus not in ('CITY','SHUANGXI') for campus, _ in data['buildings'].values()):
                raise ValueError('invalid campus')
            self.verify_projection(data, evidence_raw.decode('utf-8'))
            self.data = data
            self.version = data['reference_id']+'-'+hashlib.sha256(raw).hexdigest()[:16]
            self.state = 'available'
        except (OSError, ValueError, KeyError, TypeError, IndexError, AttributeError):
            self.data = None

    @staticmethod
    def valid_minutes(pair):
        return isinstance(pair,list) and len(pair)==2 and all(type(n) is int for n in pair) and 0 <= pair[0] < pair[1] <= 1440

    @staticmethod
    def verify_projection(data, evidence):
        def plain(value):
            return re.sub(r'\s+', '', unicodedata.normalize('NFKC', html.unescape(re.sub(r'<[^>]+>', '', value))))
        def clock(n):
            return str(n//60)+':'+str(n%60).zfill(2)
        cells = [plain(c) for c in re.findall(r'<td\b[^>]*>(.*?)</td>', evidence, re.S|re.I)]
        for code, (start,end) in data['sessions'].items():
            if not any(c==code and cells[n+1]==clock(start)+'-'+clock(end) for n,c in enumerate(cells[:-1])):
                raise ValueError('session does not match source table')
        text = plain(evidence)
        for rule in data['session_9_contexts']:
            token = ''.join(rule['sequence'])+'節之('+clock(rule['minutes'][0])+'-'+clock(rule['minutes'][1])+')'
            if token not in text:
                raise ValueError('context does not match source note')
        shuangxi = text.split('→外雙溪校區',1)[1].split('→城中校區',1)[0]
        city = text.split('→城中校區',1)[1].split('→其他',1)[0]
        for prefix,(campus,building) in data['buildings'].items():
            if plain(prefix+':'+building) not in (city if campus=='CITY' else shuangxi):
                raise ValueError('building does not match source campus section')
        if '數字0XXX:表虛擬教室代號' not in text:
            raise ValueError('virtual-room note missing')

    def context(self, term_id=None):
        if self.data is None:
            return {'state':self.state,'version':None}
        if term_id and term_id not in self.data['term_ids']:
            return {'state':'out_of_scope','version':None}
        return {'state':'document_mapped','version':self.version,'term_ids':self.data['term_ids'],
                'validity_kind':self.data['validity_kind'],'note':self.data['note'],
                'source':self.source()}

    def source(self):
        s = self.data['source']
        return {'source_id':self.data['reference_id'],'capture_id':'reference-'+s['sha256'][:20],
                'title':s['title'],'url':s['url'],'observed_at':s['observed_at'],
                'timezone':'UTC','time_precision':'second','content_sha256':s['sha256'],
                'query_parameters':{},'role':'節次與校區公告（觀察版本）'}

    def apply(self, item):
        item = deepcopy(item)
        context = self.context(item['term_id'])
        item['reference_context'] = context
        if context['state'] != 'document_mapped':
            return item
        for meeting in item['meetings']:
            codes = meeting['session_codes']
            for session in meeting['sessions']:
                if session['resolution_state'] == 'resolved':
                    continue
                pair = self.data['sessions'].get(session['code'])
                if session['code'] == '9':
                    matches = [r['minutes'] for r in self.data['session_9_contexts']
                               if any(codes[n:n+3] == r['sequence'] for n in range(len(codes)-2))]
                    pair = matches[0] if len(matches)==1 else None
                if pair:
                    session.update(start_minute=pair[0],end_minute=pair[1],resolution_state='resolved',
                                   rule_id=self.version+':'+session['code'],reference_version=self.version)
            sessions = meeting['sessions']
            complete = bool(sessions) and all(s['resolution_state']=='resolved' and s['start_minute'] is not None and s['end_minute'] is not None for s in sessions)
            meeting.update(start_minute=min(s['start_minute'] for s in sessions) if complete else None,
                           end_minute=max(s['end_minute'] for s in sessions) if complete else None)
            room = (meeting['room'] or '').strip()
            if re.fullmatch(r'0[0-9]{3}', room):
                # Virtual room is not a physical campus and does not prove online modality.
                meeting.update(room_kind='virtual',campus_id=None,campus_name=None,campus_resolution='unresolved')
            elif not meeting['campus_id'] and re.fullmatch(r'[A-Z1-6][0-9]{3,4}', room) and room[0] in self.data['buildings']:
                campus, building = self.data['buildings'][room[0]]
                meeting.update(campus_id=campus,campus_name={'CITY':'城中校區','SHUANGXI':'雙溪校區'}[campus],
                               building_name=building,campus_resolution='document_mapped',room_kind='physical')
            meeting['reference_version'] = self.version
        return item
