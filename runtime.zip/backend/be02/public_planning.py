"""Pin real public courses to private plan snapshots without granting academic credit."""
from copy import deepcopy
import csv
import io
import re

from .errors import StoreError
from .validation import semantic_error
from .store import digest, now
from . import evaluation as ev
from . import public_trials


def read(repo, principal, plan):
    items = deepcopy(repo.get_snapshot(principal, plan["input_snapshot_id"]).get("public_course_selections", []))
    credits = [item["detail"]["item"]["credits"] for item in items]
    trial_credits = [item['detail']['item']['credits'] for item in items if item['placement']==public_trials.TRIAL]
    return {"plan_id": plan["plan_id"], "plan_revision": plan["revision"], "items": items,
            "summary": {"count": len(items), "status": "needs_review" if items else "pass",
                        "listed_credits": float(sum(ev.number(c) for c in credits)) if all(c is not None for c in credits) else None,
                        "trial_count":len(trial_credits),
                        "trial_listed_credits":float(sum(ev.number(c) for c in trial_credits)) if all(c is not None for c in trial_credits) else None,
                        "counted_credits": 0, "official_registration": False}}


def dispatch(api, con, p, method, plan_id, query, body, headers, *, export=False):
    repo = api.repo
    plan = api._plan(con, p, plan_id)
    if method == "GET":
        if set(query) - {"revision"} or any(len(v) != 1 for v in query.values()):
            semantic_error("只支援單一課表修訂號")
        if "revision" in query:
            revision = query["revision"][0]
            if not re.fullmatch(r"[1-9][0-9]*", revision):
                semantic_error("修訂號格式錯誤")
            plan = repo.get_plan(p, plan_id, revision=int(revision))
        data = read(repo, p, plan)
        if export:
            content = io.StringIO(newline="")
            writer = csv.writer(content)
            writer.writerow(["plan_id", "revision", "offering_id", "course", "listed_credits", "status", "placement", "counted_credits", "offering_revision", "syllabus_revision", "reference_version", "source_kind", "official_registration"])
            def safe(value):
                text = str(value) if value is not None else ""
                return "'"+text if text.startswith(("=", "+", "-", "@", "\t", "\r", "\n")) else text
            for entry in data["items"]:
                item = entry["detail"]["item"]
                writer.writerow([safe(v) for v in (plan_id, plan["revision"], item["offering_id"], item["title"], item["credits"], "needs_review", entry['placement'], 0, item["revision_id"], item["syllabus_revision_id"], item.get('reference_context',{}).get('version'), "public_samples", False)])
            return 200, {"bytes": ("\ufeff"+content.getvalue()).encode("utf-8"), "mime_type": "text/csv; charset=utf-8", "file_name": "public-courses-review-r"+str(plan["revision"])+".csv"}, "__download__", plan
        return 200, data, None, plan
    if export:
        raise StoreError(405, "METHOD_NOT_ALLOWED", "待確認課程清單僅提供讀取匯出")
    if query:
        semantic_error("修改清單時不可附帶查詢條件")
    if method != "PATCH":
        raise StoreError(405, "METHOD_NOT_ALLOWED", "請使用查詢或修改課程清單")
    repo._authorize(con, p, "self:write")
    repo._match(plan["revision"], api.revision(headers))
    action = body.get("action")
    allowed = {"action", "offering_id", "revision_id", "syllabus_revision_id"} if action in ("add", "refresh") else {"action", "offering_id"}
    optional = {'reference_version'} if action in ('add','refresh') else set()
    if action not in ("add", "remove", "refresh", "place", "unplace") or not allowed <= set(body) or set(body)-allowed-optional:
        semantic_error("請提供這項課程操作所需的欄位，不能自行設定資格或學分")
    oid = body["offering_id"]
    if not isinstance(oid, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", oid):
        semantic_error("公開課程識別碼格式錯誤")
    current = read(repo, p, plan)
    items = current["items"]
    exists = any(i["detail"]["item"]["offering_id"] == oid for i in items)
    if (action == "add" and exists) or (action == "remove" and not exists):
        return 200, current, None, plan
    if action in ('place','unplace'):
        if action=='place':
            api._plan(con,p,plan_id,fresh=True)
        items, changed = public_trials.change(repo.get_snapshot(p,plan['input_snapshot_id']),items,oid,action)
        if not changed:
            return 200,current,None,plan
    elif action in ("add", "refresh"):
        if action=='refresh' and not exists:
            raise StoreError(404, 'PUBLIC_SELECTION_NOT_FOUND', '找不到這門已保存的課程')
        if action=='add' and len(items) >= 30:
            semantic_error("待確認清單最多保存30個課程項目")
        with api.public_catalog.connection() as public_con:
            detail = api.public_catalog.detail(public_con, oid)
        item = detail["item"]
        if item["term_id"] != re.sub(r"^MOCK-", "SCU-", plan["term_id"]):
            raise StoreError(422, "PUBLIC_COURSE_TERM_MISMATCH", "課程與這份課表的學期不同")
        if body["revision_id"] != item["revision_id"] or body["syllabus_revision_id"] != item["syllabus_revision_id"]:
            raise StoreError(409, "PUBLIC_COURSE_CHANGED", "公開課程或課綱已更新，請重新查看後再加入", current_revision=plan["revision"])
        if body.get('reference_version') != item.get('reference_context',{}).get('version'):
            raise StoreError(409, 'PUBLIC_REFERENCE_CHANGED', '節次與校區參考資料已更新，請重新查閱後再儲存', current_revision=plan['revision'])
        if action=='add' and item["selection_number"] and any(
            (saved["detail"]["item"]["term_id"], saved["detail"]["item"]["course_code"], saved["detail"]["item"]["selection_number"])
            == (item["term_id"], item["course_code"], item["selection_number"]) for saved in items
        ):
            return 200, current, None, plan
        if action=='refresh' and any(e['detail']['item']['offering_id']==oid and e['content_sha256']==digest(detail) for e in items):
            return 200, current, None, plan
        new_entry = {"detail": detail, "source_kind": "public_samples", "placement": "review_queue",
                      "status": "needs_review", "saved_at": now(), "content_sha256": digest(detail),
                      "eligibility": "needs_review", "schedule": "needs_review", "recognition": "needs_review"}
        if action=='add':
            items.append(new_entry)
        else:
            items = [new_entry if e['detail']['item']['offering_id']==oid else e for e in items]
    else:
        items = [i for i in items if i["detail"]["item"]["offering_id"] != oid]
    token = repo._public_selection_override.set(items)
    try:
        # Existing plan writes atomically create immutable snapshots, invalidate
        # old checks/confirmations and retain the established revision contract.
        plan = repo.update_plan(p, plan_id, {"required_course_ids": plan["required_course_ids"]}, expected_revision=plan["revision"])
    finally:
        repo._public_selection_override.reset(token)
    repo._audit(con, p.subject, "plan", plan_id, plan["revision"], p.subject, "public_course_"+action, {"offering_id": oid})
    return 200, read(repo, p, plan), None, plan


def extend_validation(value, selections, rules, fits=None, trial_fits=None):
    if not selections["items"]:
        return
    count = len(selections["items"])
    for dimension, code, message in (
        ("eligibility", "PREREQUISITES_UNKNOWN", "公開課程的個人修課資格尚未與正式學籍及先修規定核對。"),
        ("schedule", "MEETINGS_UNKNOWN", "公開課程仍有週次、校區或正式排課資料待核對；試排僅表示預留時間，尚未計入正式學分負擔。"),
        ("recognition", "RECOGNITION_APPROVAL_PENDING", "公開課程列示學分尚未計入畢業或已得學分，需確認認列用途。"),
    ):
        check = {"check_id": "public-courses-"+dimension, "dimension": dimension, "status": "needs_review",
                 "reason_codes": [code], "missing_fields": ["official_public_course_mapping"],
                 "rule_version": rules["version"], "source_refs": [], "message": f"{count} 個待確認公開課程：{message}"}
        value[dimension] = ev.evaluation(value[dimension]["checks"] + [check])
    for index, entry in enumerate(selections['items']):
        item = entry['detail']['item']
        is_trial=entry['placement']==public_trials.TRIAL
        comparison = ((trial_fits or {}) if is_trial else (fits or {})).get(item['offering_id'])
        for n, detail in enumerate(comparison['schedule']['checks'] if comparison else []):
            if detail['code'] not in ('TIME_OVERLAP', 'UNAVAILABLE_TIME', 'RAW_SESSION_OVERLAP', 'TRAVEL_GAP_TOO_SHORT'):
                continue
            value['schedule']['checks'].append({
                'check_id': f'public-schedule-{index}-{n}', 'dimension': 'schedule', 'status': detail['status'] if is_trial else 'needs_review',
                'reason_codes': ['MEETINGS_UNKNOWN' if detail['code'] == 'RAW_SESSION_OVERLAP' else detail['code']],
                'missing_fields': [], 'rule_version': rules['version'], 'source_refs': [],
                'message': ('公開試排：' if is_trial else '候選交叉比對：')+item['title']+'：'+detail['message']})
    value['schedule'] = ev.evaluation(value['schedule']['checks'])
    value["pending_task_ids"].append("public-course-review")
    value["can_confirm_preselection"] = False
