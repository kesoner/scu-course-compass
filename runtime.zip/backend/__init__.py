"""Versioned backend foundations; independent of the legacy mvp package."""
