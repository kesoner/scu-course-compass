class StoreError(Exception):
    """Transport-neutral error using BE-01 codes; no private payload in errors."""

    def __init__(self, status, code, message, *, current_revision=None, details=None, retryable=False):
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.current_revision = current_revision
        self.details = details or []
        self.retryable = retryable

    def as_error(self):
        return {"code": self.code, "message": self.message, "retryable": self.retryable,
                "details": self.details, "current_revision": self.current_revision, "checks": []}
