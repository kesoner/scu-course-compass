CREATE TABLE be02_metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE be02_principals (
  subject TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('student','operator')),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1))
);
CREATE TABLE be02_permissions (
  subject TEXT NOT NULL REFERENCES be02_principals(subject), permission TEXT NOT NULL,
  PRIMARY KEY(subject,permission)
);
CREATE TABLE be02_mock_tokens (
  token_digest TEXT PRIMARY KEY, subject TEXT NOT NULL REFERENCES be02_principals(subject),
  expires_at TEXT, revoked_at TEXT
);
CREATE TABLE be02_references (
  kind TEXT NOT NULL CHECK(kind IN ('campus','program','term')), entity_id TEXT NOT NULL,
  payload TEXT NOT NULL CHECK(json_valid(payload)), sha256 TEXT NOT NULL,
  PRIMARY KEY(kind,entity_id)
);
CREATE TABLE be02_sources (
  source_id TEXT NOT NULL, version TEXT NOT NULL,
  payload TEXT NOT NULL CHECK(json_valid(payload)), sha256 TEXT NOT NULL,
  PRIMARY KEY(source_id,version)
);
CREATE TABLE be02_catalog_versions (
  version TEXT PRIMARY KEY, term_id TEXT NOT NULL, payload TEXT NOT NULL CHECK(json_valid(payload)),
  sha256 TEXT NOT NULL, created_at TEXT NOT NULL, actor_id TEXT NOT NULL
);
CREATE TABLE be02_catalog_heads (
  term_id TEXT PRIMARY KEY, version TEXT NOT NULL REFERENCES be02_catalog_versions(version)
);
CREATE TABLE be02_catalog_sources (
  catalog_version TEXT NOT NULL REFERENCES be02_catalog_versions(version),
  source_id TEXT NOT NULL, source_version TEXT NOT NULL,
  PRIMARY KEY(catalog_version,source_id), FOREIGN KEY(source_id,source_version) REFERENCES be02_sources(source_id,version)
);
CREATE TABLE be02_courses (
  catalog_version TEXT NOT NULL REFERENCES be02_catalog_versions(version), course_id TEXT NOT NULL,
  credit_hundredths INTEGER, payload TEXT NOT NULL CHECK(json_valid(payload)),
  PRIMARY KEY(catalog_version,course_id)
);
CREATE TABLE be02_offerings (
  catalog_version TEXT NOT NULL, offering_id TEXT NOT NULL, course_id TEXT NOT NULL, term_id TEXT NOT NULL,
  payload TEXT NOT NULL CHECK(json_valid(payload)), PRIMARY KEY(catalog_version,offering_id),
  FOREIGN KEY(catalog_version,course_id) REFERENCES be02_courses(catalog_version,course_id)
);
CREATE TABLE be02_meetings (
  catalog_version TEXT NOT NULL, offering_id TEXT NOT NULL, meeting_index INTEGER NOT NULL,
  weekday INTEGER NOT NULL CHECK(weekday BETWEEN 1 AND 7), start_minute INTEGER NOT NULL,
  end_minute INTEGER NOT NULL CHECK(end_minute>start_minute), campus_id TEXT, payload TEXT NOT NULL CHECK(json_valid(payload)),
  PRIMARY KEY(catalog_version,offering_id,meeting_index),
  FOREIGN KEY(catalog_version,offering_id) REFERENCES be02_offerings(catalog_version,offering_id)
);
CREATE TABLE be02_rule_versions (
  rule_set_id TEXT NOT NULL, version TEXT NOT NULL, payload TEXT NOT NULL CHECK(json_valid(payload)),
  sha256 TEXT NOT NULL, created_at TEXT NOT NULL, actor_id TEXT NOT NULL,
  PRIMARY KEY(rule_set_id,version), UNIQUE(version)
);
CREATE TABLE be02_rule_heads (
  rule_set_id TEXT PRIMARY KEY, version TEXT NOT NULL,
  FOREIGN KEY(rule_set_id,version) REFERENCES be02_rule_versions(rule_set_id,version)
);
CREATE TABLE be02_rule_sources (
  rule_set_id TEXT NOT NULL, rule_version TEXT NOT NULL, source_id TEXT NOT NULL, source_version TEXT NOT NULL,
  PRIMARY KEY(rule_set_id,rule_version,source_id),
  FOREIGN KEY(rule_set_id,rule_version) REFERENCES be02_rule_versions(rule_set_id,version),
  FOREIGN KEY(source_id,source_version) REFERENCES be02_sources(source_id,version)
);
CREATE TABLE be02_requirements (
  rule_set_id TEXT NOT NULL, rule_version TEXT NOT NULL, requirement_id TEXT NOT NULL,
  payload TEXT NOT NULL CHECK(json_valid(payload)), PRIMARY KEY(rule_set_id,rule_version,requirement_id),
  FOREIGN KEY(rule_set_id,rule_version) REFERENCES be02_rule_versions(rule_set_id,version)
);
CREATE TABLE be02_profile_versions (
  student_id TEXT NOT NULL REFERENCES be02_principals(subject), revision INTEGER NOT NULL CHECK(revision>0),
  version_label TEXT NOT NULL, payload TEXT NOT NULL CHECK(json_valid(payload)), sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL, actor_id TEXT NOT NULL, reason TEXT NOT NULL,
  exploring_program_ids TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(exploring_program_ids)),
  PRIMARY KEY(student_id,revision), UNIQUE(student_id,version_label),
  CHECK(json_extract(payload,'$.student_id')=student_id), CHECK(json_extract(payload,'$.revision')=revision)
);
CREATE TABLE be02_record_versions (
  student_id TEXT NOT NULL REFERENCES be02_principals(subject), revision INTEGER NOT NULL CHECK(revision>0),
  version_label TEXT NOT NULL, coverage TEXT NOT NULL CHECK(coverage IN ('complete','partial','unknown')),
  sha256 TEXT NOT NULL, created_at TEXT NOT NULL, actor_id TEXT NOT NULL,
  PRIMARY KEY(student_id,revision), UNIQUE(student_id,version_label)
);
CREATE TABLE be02_profile_sources (
  student_id TEXT NOT NULL, profile_revision INTEGER NOT NULL, source_id TEXT NOT NULL, source_version TEXT NOT NULL,
  PRIMARY KEY(student_id,profile_revision,source_id),
  FOREIGN KEY(student_id,profile_revision) REFERENCES be02_profile_versions(student_id,revision),
  FOREIGN KEY(source_id,source_version) REFERENCES be02_sources(source_id,version)
);
CREATE TABLE be02_record_sources (
  student_id TEXT NOT NULL, records_revision INTEGER NOT NULL, source_id TEXT NOT NULL, source_version TEXT NOT NULL,
  PRIMARY KEY(student_id,records_revision,source_id),
  FOREIGN KEY(student_id,records_revision) REFERENCES be02_record_versions(student_id,revision),
  FOREIGN KEY(source_id,source_version) REFERENCES be02_sources(source_id,version)
);
CREATE TABLE be02_records (
  student_id TEXT NOT NULL, records_revision INTEGER NOT NULL, record_id TEXT NOT NULL, course_id TEXT NOT NULL,
  source_record_key TEXT NOT NULL, payload TEXT NOT NULL CHECK(json_valid(payload)),
  PRIMARY KEY(student_id,records_revision,record_id), UNIQUE(student_id,records_revision,source_record_key),
  FOREIGN KEY(student_id,records_revision) REFERENCES be02_record_versions(student_id,revision),
  CHECK(json_extract(payload,'$.student_id')=student_id), CHECK(json_extract(payload,'$.record_id')=record_id)
);
CREATE TABLE be02_academic_evidence (
  student_id TEXT NOT NULL, records_revision INTEGER NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('recognition','non_credit')),
  evidence_id TEXT NOT NULL, payload TEXT NOT NULL CHECK(json_valid(payload)),
  PRIMARY KEY(student_id,records_revision,kind,evidence_id),
  FOREIGN KEY(student_id,records_revision) REFERENCES be02_record_versions(student_id,revision),
  CHECK(json_extract(payload,'$.student_id')=student_id)
);
CREATE TABLE be02_student_heads (
  student_id TEXT PRIMARY KEY REFERENCES be02_principals(subject), profile_revision INTEGER NOT NULL,
  records_revision INTEGER NOT NULL, exploring_program_ids TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(exploring_program_ids)),
  FOREIGN KEY(student_id,profile_revision) REFERENCES be02_profile_versions(student_id,revision),
  FOREIGN KEY(student_id,records_revision) REFERENCES be02_record_versions(student_id,revision)
);
CREATE TABLE be02_plan_heads (
  plan_id TEXT PRIMARY KEY, student_id TEXT NOT NULL REFERENCES be02_principals(subject), revision INTEGER NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('draft','confirmed')),
  validation_state TEXT NOT NULL CHECK(validation_state IN ('not_evaluated','current','stale')),
  UNIQUE(plan_id,student_id),
  FOREIGN KEY(plan_id,student_id,revision) REFERENCES be02_plan_versions(plan_id,student_id,revision) DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE be02_snapshots (
  snapshot_id TEXT PRIMARY KEY, student_id TEXT NOT NULL, plan_id TEXT NOT NULL, plan_revision INTEGER NOT NULL,
  payload TEXT NOT NULL CHECK(json_valid(payload)), sha256 TEXT NOT NULL, created_at TEXT NOT NULL,
  UNIQUE(snapshot_id,student_id), UNIQUE(plan_id,plan_revision),
  FOREIGN KEY(plan_id,student_id) REFERENCES be02_plan_heads(plan_id,student_id) DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE be02_plan_versions (
  plan_id TEXT NOT NULL, student_id TEXT NOT NULL REFERENCES be02_principals(subject), revision INTEGER NOT NULL CHECK(revision>0),
  snapshot_id TEXT NOT NULL, payload TEXT NOT NULL CHECK(json_valid(payload)), sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL, actor_id TEXT NOT NULL, reason TEXT NOT NULL,
  PRIMARY KEY(plan_id,student_id,revision), UNIQUE(plan_id,revision),
  FOREIGN KEY(snapshot_id,student_id) REFERENCES be02_snapshots(snapshot_id,student_id),
  CHECK(json_extract(payload,'$.student_id')=student_id), CHECK(json_extract(payload,'$.plan_id')=plan_id),
  CHECK(json_extract(payload,'$.revision')=revision), CHECK(json_extract(payload,'$.input_snapshot_id')=snapshot_id)
);
CREATE TABLE be02_artifact_versions (
  student_id TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('intent','direction','eligibility','validation','confirmation','export','registration')),
  artifact_id TEXT NOT NULL, revision INTEGER NOT NULL CHECK(revision>0), plan_id TEXT NOT NULL,
  payload TEXT NOT NULL CHECK(json_valid(payload)), sha256 TEXT NOT NULL, created_at TEXT NOT NULL,
  PRIMARY KEY(student_id,kind,artifact_id,revision),
  FOREIGN KEY(plan_id,student_id) REFERENCES be02_plan_heads(plan_id,student_id)
);
CREATE TABLE be02_artifact_heads (
  student_id TEXT NOT NULL, kind TEXT NOT NULL, artifact_id TEXT NOT NULL, revision INTEGER NOT NULL,
  is_current INTEGER NOT NULL DEFAULT 0 CHECK(is_current IN (0,1)),
  PRIMARY KEY(student_id,kind,artifact_id),
  FOREIGN KEY(student_id,kind,artifact_id,revision) REFERENCES be02_artifact_versions(student_id,kind,artifact_id,revision)
);
CREATE TABLE be02_direction_links (
  student_id TEXT NOT NULL, direction_id TEXT NOT NULL, intent_id TEXT NOT NULL, plan_id TEXT NOT NULL,
  PRIMARY KEY(student_id,direction_id),
  FOREIGN KEY(plan_id,student_id) REFERENCES be02_plan_heads(plan_id,student_id)
);
CREATE TABLE be02_audit_events (
  event_id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT, resource_kind TEXT NOT NULL,
  resource_id TEXT NOT NULL, revision TEXT NOT NULL, actor_id TEXT NOT NULL, action TEXT NOT NULL,
  sha256 TEXT NOT NULL, occurred_at TEXT NOT NULL
);
CREATE TABLE be02_seed_runs (
  dataset_id TEXT PRIMARY KEY, dataset_sha256 TEXT NOT NULL, workflow_sha256 TEXT NOT NULL,
  imported_at TEXT NOT NULL, summary TEXT NOT NULL CHECK(json_valid(summary))
);
CREATE INDEX be02_plan_owner ON be02_plan_heads(student_id,plan_id);
CREATE INDEX be02_artifact_owner ON be02_artifact_versions(student_id,kind,artifact_id);
CREATE INDEX be02_event_owner ON be02_audit_events(student_id,event_id);
