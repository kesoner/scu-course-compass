"""Read-only A4 planning documents from an owner's immutable input snapshot.

These documents are not the university's official registration/check form.
No live catalog, personal record, AI call, or credit recognition is consulted.
"""
from datetime import datetime
from io import BytesIO
import os
from pathlib import Path
from threading import Lock
from xml.sax.saxutils import escape

from .errors import StoreError

FONT_LOCK = Lock()
SOURCE_URL = 'https://web-ch.scu.edu.tw/regcurr/web_page/16474'
FORM_SOURCE = 'https://www.gbp.scu.edu.tw/sites/default/files/2025-05/Information%20You%20Need%20to%20Know.pdf'
PERIODS = [
    ('1',490,540),('2',550,600),('3',610,660),('4',670,720),
    ('E',730,780),('5',790,840),('6',850,900),('7',910,960),('8',970,1020),
    ('9*',1030,1100),('A',1105,1155),('B',1160,1210),('C',1220,1270),('D',1275,1325),
]
DAYS = ('','一','二','三','四','五','六','日')
CAMPUS = {'CITY':'城中','SHUANGXI':'雙溪'}


def clock(n):
    return f'{n//60:02d}:{n%60:02d}'


def fonts():
    try:
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
    except ImportError as exc:
        raise StoreError(503, 'PDF_UNAVAILABLE', '尚未安裝 PDF 套件，請安裝 backend/requirements.txt。') from exc
    with FONT_LOCK:
        if 'SCUText' in pdfmetrics.getRegisteredFontNames():
            return
        path = Path(os.environ.get('SCU_PDF_FONT', str(Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts/msjh.ttc')))
        if not path.is_file():
            raise StoreError(503, 'PDF_FONT_UNAVAILABLE', '缺少繁體中文字型，請設定 SCU_PDF_FONT。')
        pdfmetrics.registerFont(TTFont('SCUText', str(path)))


def course_rows(plan, snapshot):
    catalog = snapshot['catalog']
    courses = {c['course_id']:c for c in catalog['courses']}
    offerings = {o['offering_id']:o for o in catalog['offerings']}
    rows = []
    for selection in plan['selections']:
        offering = offerings[selection['offering_id']]
        course = courses[offering['course_id']]
        rows.append(dict(id=offering['offering_id'],name=course['name'],credits=course['credits'],
                         section=offering.get('section_name') or '班別待確認',
                         teacher=offering.get('instructor') or '教師待確認',
                         state='示範規劃' if selection['placement']=='scheduled' else '示範候選',
                         plotted=selection['placement']=='scheduled',public=False,
                         meetings=offering.get('meetings') or []))
    for entry in snapshot.get('public_course_selections',[]):
        item = entry['detail']['item']
        teachers = item.get('teachers',[])
        groups = item.get('classes',[])
        meetings = []
        for m in item.get('meetings',[]):
            sessions = m.get('sessions') or []
            resolved = bool(sessions) and all(s.get('resolution_state')=='resolved' and s.get('start_minute') is not None and s.get('end_minute') is not None for s in sessions)
            meetings.append(dict(weekday=m.get('weekday'),start_minute=min(s['start_minute'] for s in sessions) if resolved else None,
                                 end_minute=max(s['end_minute'] for s in sessions) if resolved else None,
                                 campus_id=m.get('campus_id'),room=m.get('room_raw') or m.get('room'),
                                 session_codes=m.get('session_codes',[]),
                                 segments=[{'start_minute':s['start_minute'],'end_minute':s['end_minute']} for s in sessions] if resolved else []))
        rows.append(dict(id=(item.get('course_code') or item['offering_id'])+'\n選課序號 '+str(item.get('selection_number') or '待確認'),name=item['title'],credits=item.get('credits'),
                         section='、'.join(g.get('name','') if isinstance(g,dict) else str(g) for g in groups) or '班別待確認',
                         teacher='、'.join(t.get('name','') if isinstance(t,dict) else str(t) for t in teachers) or '教師待確認',
                         state='公開試排・待核對' if entry['placement']=='trial_scheduled' else '想修清單・未排入',
                         plotted=entry['placement']=='trial_scheduled',public=True,meetings=meetings))
    return rows


def meeting_text(m):
    day=m.get('weekday')
    weekday='週'+DAYS[day] if isinstance(day,int) and 1<=day<=7 else '星期待確認'
    timing=clock(m['start_minute'])+'-'+clock(m['end_minute']) if m.get('start_minute') is not None and m.get('end_minute') is not None else '時間待確認'
    codes=''.join(m.get('session_codes') or [])
    return ' · '.join(filter(None,[weekday,timing,('節次 '+codes) if codes else None,CAMPUS.get(m.get('campus_id'),'校區待確認'),m.get('room') or '教室待確認']))


def render(plan, snapshot, kind):
    fonts()
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
    buffer=BytesIO()
    pagesize=landscape(A4) if kind=='timetable' else A4
    doc=SimpleDocTemplate(buffer,pagesize=pagesize,leftMargin=30,rightMargin=30,topMargin=28,bottomMargin=40,
                          title='每週課表' if kind=='timetable' else '選課查對清單（規劃參考版）',author='職涯導航')
    wine=colors.HexColor('#aa1730'); pale=colors.HexColor('#fff3f5'); line=colors.HexColor('#e4dcde')
    styles={name:ParagraphStyle(name,fontName='SCUText',fontSize=size,leading=leading,textColor=colors.HexColor('#28323c'),spaceAfter=5,wordWrap='CJK')
            for name,size,leading in [('title',21,29),('body',9,14),('small',7,10),('cell',8,11),('tiny',6.8,9)]}
    styles['title'].textColor=wine
    styles['head']=ParagraphStyle('head',parent=styles['cell'],textColor=wine)
    styles['center']=ParagraphStyle('center',parent=styles['tiny'],alignment=TA_CENTER)
    def p(value,style='body'):
        return Paragraph(escape(str(value)).replace('\n','<br/>'),styles[style])
    rows=course_rows(plan,snapshot)
    generated=datetime.now().astimezone().isoformat(timespec='seconds')
    story=[p(doc.title,'title'),p('規劃參考 · 示範學籍；不是校方選課結果，不能代替正式選課或畢業認列。','small'),
           p(f"學期 {plan['term_id']}  |  課表第 {plan['revision']} 版  |  產生 {generated}",'small')]
    def table(data,widths,header=True):
        t=Table(data,colWidths=widths,repeatRows=1 if header else 0,hAlign='LEFT')
        t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,0),pale),
                               ('GRID',(0,0),(-1,-1),.35,line),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),
                               ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
        return t
    if kind=='timetable':
        data=[[p('節次／時間','center')]+[p('星期'+d,'center') for d in DAYS[1:]]]
        for code,start,end in PERIODS:
            cells=[p(code+'\n'+clock(start)+'-'+clock(end),'center')]
            for day in range(1,8):
                names=[]
                for r in rows:
                    if r['plotted'] and any(m.get('weekday')==day and any(s.get('start_minute') is not None and s.get('end_minute') is not None and s['start_minute']<end and s['end_minute']>start for s in m.get('segments',[m])) for m in r['meetings']):
                        names.append(('試排・' if r['public'] else '')+r['name'])
                marks=[]
                for key,field in [('time_blocks','kind'),('campus_blocks','campus_id')]:
                    for block in plan['preferences'][key]:
                        if block['weekday']==day and block['start_minute']<end and block['end_minute']>start:
                            marks.append({'unavailable':'不方便上課','prefer_free':'希望留空',**CAMPUS}.get(block[field],block[field]))
                cells.append(p('\n'.join(names+list(dict.fromkeys(marks))),'tiny'))
            data.append(cells)
        grid=table(data,[66]+[(doc.width-66)/7]*7)
        grid.setStyle(TableStyle([('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]))
        story += [Spacer(1,5),grid,Spacer(1,7),
                  p('9* 為兩種時段的聯集：789 的第 9 節為 17:10-18:00，9AB 為 17:30-18:20。D 節至 22:05；精確課程與標記範圍見附表。','small'),
                  p('一格有多門課時全部保留，不代表已通過衝堂或資格檢查。試排與候選均不增加已取得學分。','small'),PageBreak()]
    else:
        story += [p('依校方查對選課結果的用途整理；尚未取得校方完整表單版型，本清單是本系統設計的規劃參考版。','small'),
                  p('學籍：示範資料；個人修課進度尚未接入這份課表，不列入已取得或畢業學分。','small'),Spacer(1,7)]
    # An unbounded course list flows across pages; no course is hidden to fit A4.
    listing=[[p(v,'head') for v in ['科目／班別','教師／列示學分','時間／校區／教室','目前狀態']]]
    for r in rows:
        credits='待確認' if r['credits'] is None else str(r['credits'])
        listing.append([p(r['name']+'\n'+r['id']+'\n'+r['section'],'cell'),p(r['teacher']+'\n'+credits+' 學分','cell'),
                        p('\n'.join(meeting_text(m) for m in r['meetings']) or '上課時間、校區與教室待確認','cell'),p(r['state'],'cell')])
    if not rows:
        listing.append([p('尚未加入課程','cell'),p('-','cell'),p('-','cell'),p('空白規劃','cell')])
    story += [p('課程查對明細'),table(listing,[doc.width*.27,doc.width*.18,doc.width*.39,doc.width*.16]),Spacer(1,10),
              p('核對提醒：所有學分均為課程列示值；公開試排與想修清單尚未確認資格及認列，不增加已取得學分。正式選上、通過與核定抵免是不同紀錄。','small')]
    if kind=='timetable':
        marks=[]
        for key in ('time_blocks','campus_blocks'):
            for b in plan['preferences'][key]:
                label=CAMPUS.get(b.get('campus_id')) if key=='campus_blocks' else {'unavailable':'不方便上課','prefer_free':'希望留空'}[b['kind']]
                marks.append(f"週{DAYS[b['weekday']]} {clock(b['start_minute'])}-{clock(b['end_minute'])} {label}")
        if marks:
            story += [p('時間與校區標記（精確範圍）'),p('；'.join(marks),'small')]
    if kind=='selection-check':
        story += [p('待核對：正式選課結果、修課資格、學分用途與特殊時段；本表不含校方核章或核准狀態。','small')]
    story += [p('資料版本：'+ ' / '.join(k+'='+str(v) for k,v in plan['data_versions'].items()),'tiny'),
              p('課表識別：'+plan['plan_id']+'  |  輸入快照：'+plan['input_snapshot_id'],'tiny'),
              Paragraph('參考來源：<link href="'+SOURCE_URL+'" color="#aa1730">校方節次公告</link> · <link href="'+FORM_SOURCE+'" color="#aa1730">校方選課查對表下載說明（第 26 頁）</link>',styles['small'])]
    def footer(canvas,document):
        canvas.setFont('SCUText',7);canvas.setFillColor(colors.HexColor('#706b70'))
        canvas.drawString(30,22,'職涯導航 · 規劃參考版 · 非正式選課證明')
        canvas.drawRightString(pagesize[0]-30,22,str(document.page))
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    return buffer.getvalue()
