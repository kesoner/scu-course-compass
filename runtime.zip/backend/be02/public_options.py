"""Authenticated public-course discovery bound to an exact private plan revision."""
import re
from urllib.parse import urlencode

from .errors import StoreError
from .validation import semantic_error
from .public_schedule import ENGINE_VERSION, evaluate, peers_from_snapshot, same_offering

PUBLIC_FILTERS = {'q', 'teacher', 'class_group', 'weekday', 'session', 'term_id'}
OPTION_FILTERS = {'plan_revision', 'window_weekday', 'start_minute', 'end_minute', 'campus', 'fit'}


def discover(api, con, p, plan_id, query):
    plan = api._plan(con, p, plan_id, fresh=True)
    if set(query) - PUBLIC_FILTERS - OPTION_FILTERS or any(len(v) != 1 for v in query.values()):
        semantic_error('請使用已支援且不重複的查詢條件')
    values = {k: v[0] for k, v in query.items()}
    revision = values.get('plan_revision', '')
    if not re.fullmatch(r'[1-9][0-9]{0,9}', revision):
        semantic_error('請提供目前課表修訂號')
    api.repo._match(plan['revision'], int(revision))
    filters = api.public_catalog.query('/?'+urlencode({k: v for k, v in values.items() if k in PUBLIC_FILTERS}), PUBLIC_FILTERS)
    term_id = re.sub(r'^MOCK-', 'SCU-', plan['term_id'])
    if filters.get('term_id', term_id) != term_id:
        raise StoreError(422, 'PUBLIC_COURSE_TERM_MISMATCH', '課程查詢需使用與這份課表相同的學期')
    filters['term_id'] = term_id
    window_fields = {'window_weekday', 'start_minute', 'end_minute'} & values.keys()
    window = None
    if window_fields:
        if len(window_fields) != 3 or any(not re.fullmatch(r'[0-9]{1,4}', values[k]) for k in window_fields):
            semantic_error('空堂需包含星期、開始與結束時間')
        day, start, end = (int(values[k]) for k in ('window_weekday', 'start_minute', 'end_minute'))
        if not 1 <= day <= 7 or not 0 <= start < end <= 1440:
            semantic_error('空堂時間範圍有誤')
        window = {'weekday': day, 'start_minute': start, 'end_minute': end}
    campus = values.get('campus') or None
    if campus not in (None, 'CITY', 'SHUANGXI'):
        semantic_error('請選擇城中、雙溪或不限校區')
    fit_filter = values.get('fit', 'all')
    if fit_filter not in ('all', 'no_conflict', 'pass', 'needs_review', 'fail'):
        semantic_error('時間比對條件有誤')
    snapshot = api.repo.get_snapshot(p, plan['input_snapshot_id'])
    entries = snapshot.get('public_course_selections', [])
    peers = peers_from_snapshot(snapshot, [entry for entry in entries if entry['placement']=='trial_scheduled'])
    gap = snapshot['rule_set']['cross_campus_policy']['minimum_gap_minutes']
    forbid_back_to_back = snapshot['rule_set']['cross_campus_policy']['forbid_back_to_back']
    with api.public_catalog.connection() as public_con:
        items = api.public_catalog.items(public_con, filters)
        total = api.public_catalog.total(public_con, term_id)
    evaluated = []
    counts = {'pass': 0, 'needs_review': 0, 'fail': 0}
    for item in items:
        comparison = evaluate(item, plan['preferences'], peers, window, campus, gap, forbid_back_to_back)
        status = comparison['fit']['status']
        counts[status] += 1
        if fit_filter == 'no_conflict' and status == 'fail' or fit_filter not in ('all', 'no_conflict') and status != fit_filter:
            continue
        evaluated.append({'item': item, 'comparison': comparison, 'saved': any(same_offering(item, e['detail']['item']) for e in entries)})
    rank = {'pass': 0, 'needs_review': 1, 'fail': 2}
    evaluated.sort(key=lambda o: (rank[o['comparison']['fit']['status']], sum(s['minutes'] for s in o['comparison']['soft_mismatches']), o['item']['course_code'], o['item']['offering_id']))
    data = {'plan_id': plan_id, 'plan_revision': plan['revision'], 'input_snapshot_id': plan['input_snapshot_id'],
            'engine_version': ENGINE_VERSION, 'options': evaluated, 'total_items': total,
            'matched_items': len(evaluated), 'before_fit_filter': len(items), 'counts': counts,
            'filters': {**filters, 'window': window, 'campus': campus, 'fit': fit_filter},
            'comparison_scope': {'scheduled_demo_courses': True, 'saved_public_courses': False, 'trial_scheduled_public_courses':True,
                                 'travel_gap_minutes': gap, 'forbid_cross_campus_back_to_back': forbid_back_to_back, 'travel_policy_source': 'synthetic_planning_rules'},
            'limitations': ['時間比對通過只代表已知安排符合，不代表個人修課資格或學分認列通過。',
                            '節次鐘點、校區及週次不足時保留待確認，不以教室代碼或課綱文字猜測。',
                            '跨校區緩衝採本機示範規劃值，並非校方交通時間保證。']}
    return 200, data, None, plan
