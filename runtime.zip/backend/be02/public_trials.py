"""Tentative public timetable placement, independent of academic eligibility/credit."""
from copy import deepcopy

from .errors import StoreError
from .store import now
from .public_schedule import evaluate, intervals, peers_from_snapshot, same_offering

TRIAL = 'trial_scheduled'


def trial_fits(snapshot, entries):
    peers = peers_from_snapshot(snapshot, [e for e in entries if e['placement']==TRIAL])
    policy = snapshot['rule_set']['cross_campus_policy']
    return {e['detail']['item']['offering_id']: evaluate(e['detail']['item'], snapshot['plan']['preferences'], peers,
            travel_gap=policy['minimum_gap_minutes'], forbid_back_to_back=policy['forbid_back_to_back']) for e in entries}


def change(snapshot, entries, offering_id, action):
    entries = deepcopy(entries)
    entry = next((e for e in entries if e['detail']['item']['offering_id']==offering_id),None)
    if entry is None:
        raise StoreError(404,'PUBLIC_SELECTION_NOT_FOUND','請先把這門課保存到想修清單')
    if action=='unplace':
        if entry['placement']!=TRIAL:
            return entries, False
        entry['placement']='review_queue'
        entry.pop('trial_scheduled_at',None)
    else:
        if entry['placement']==TRIAL:
            return entries, False
        item=entry['detail']['item']
        if (not item.get('meetings') or any(type(m.get('weekday')) is not int or not 1<=m['weekday']<=7 or intervals(m)[1] for m in item['meetings'])):
            raise StoreError(422,'PUBLIC_TRIAL_TIME_UNKNOWN','上課星期或鐘點尚未完整，請先查看最新資料；目前可先保留在想修清單')
        if any(e['placement']==TRIAL and same_offering(item,e['detail']['item']) for e in entries):
            raise StoreError(409,'PUBLIC_TRIAL_DUPLICATE','這個班別已經試排在課表上')
        fit=trial_fits(snapshot,entries)[offering_id]
        failures=[c for c in fit['schedule']['checks'] if c['status']=='fail']
        if failures:
            raise StoreError(409,'PUBLIC_TRIAL_CONFLICT','目前無法試排：'+' '.join(c['message'] for c in failures[:3]))
        entry['placement']=TRIAL
        entry['trial_scheduled_at']=now()
    entry['placement_updated_at']=now()
    # No academic field, raw public content or source hash is changed here.
    return entries, True
