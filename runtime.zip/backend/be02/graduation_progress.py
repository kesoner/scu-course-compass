"""Student-facing degree progress projection. Uses existing rules; never invents school thresholds."""
from . import evaluation as ev

SECTIONS = [
    ('major_required','系必修與主修門檻'), ('major_elective','系選修'),
    ('common','校訂共同必修'), ('general','通識學分'), ('physical','體育科次'),
    ('other','其他／外系學分'), ('additional_program','輔系／雙主修'), ('milestones','畢業標準'),
]


def category(requirement, profile):
    # This presentation mapping is deliberately narrow: the demo does not carry
    # official cohort-specific general-education, PE or external-credit caps.
    if requirement['kind']=='total_credits':
        return None
    if requirement['kind']=='non_credit':
        return 'milestones'
    if requirement['requirement_id']=='COMMON-ENG':
        return 'common'
    if any(p['program_id']==requirement['program_id'] and p['kind'] in ('minor','double_major','certificate') for p in profile['programs']):
        return 'additional_program'
    if requirement['kind']=='required_courses' and any(p['program_id']==requirement['program_id'] and p['kind']=='major' for p in profile['programs']):
        return 'major_required'
    return 'other'


def build(context, academic, catalog, rules, plan, teaching=None, records_updated_at=None):
    profile, audit = context['profile'], context['audit']
    courses = {c['course_id']:c for c in catalog['courses']}
    teaching = teaching or {'courses':{}}
    current = {c['check_id'].removeprefix('requirement-').removesuffix('-current'):c for c in audit['current_requirements']['checks']}
    allocations = audit['allocations']
    sections = {key:{'section_id':key,'title':title,'status':'needs_review','requirements':[], 'missing_mapping':True} for key,title in SECTIONS}
    missing_courses=[]
    for requirement in rules['requirements']:
        key=category(requirement,profile)
        if key is None:
            continue
        rid=requirement['requirement_id']
        evaluation=current.get(rid,{'status':'needs_review','message':'尚未取得這項門檻的核對結果。'})
        rows=[]
        for cid in requirement['course_ids']:
            course=courses.get(cid,{})
            records=[r for r in academic['records'] if r['course_id']==cid]
            earned=[a for a in allocations if a['course_id']==cid and a['state']=='earned' and rid in a['requirement_ids']]
            earned_credits=float(sum(ev.number(a['earned_credits']) for a in earned))
            waiver=any(r['state']=='waiver' and r['approval']=='approved' for r in records) and requirement['waiver_satisfies_course']
            pending=any(r['approval']=='pending' or r['earned_credits'] is None and r['state'] in ('completed','transfer') for r in records)
            enrolled=any(r['state']=='enrolled' for r in records)
            state='earned' if earned else 'waived' if waiver else 'pending_recognition' if pending else 'in_progress' if enrolled else 'missing' if academic['record_coverage']=='complete' else 'needs_review'
            row_credits=earned_credits if earned or waiver or state in ('missing','in_progress') else None
            row={'course_id':cid,'name':course.get('name',cid),'year_level':teaching.get('courses',{}).get(cid,{}).get('year_level'),
                 'semester_scope':None,'listed_credits':course.get('credits'),'earned_credits':row_credits,
                 'state':state,'record_ids':[r['record_id'] for r in records],
                 'status':'pass' if state in ('earned','waived') else 'needs_review' if state in ('pending_recognition','needs_review') else 'fail'}
            rows.append(row)
            if requirement['kind']=='required_courses' and state not in ('earned','waived'):
                missing_courses.append({**row,'section_id':key,'requirement_id':rid})
        credit_values=[r['listed_credits'] for r in rows]
        required = requirement['minimum_credits']
        if required is None and requirement['kind']=='required_courses':
            required=float(sum(ev.number(n) for n in credit_values)) if all(n is not None for n in credit_values) else None
        # A credit allocation can satisfy multiple requirements; do not sum
        # requirement totals into an invented additive category/graduation total.
        credited = float(sum(ev.number(a['earned_credits']) for a in allocations if a['state']=='earned' and rid in a['requirement_ids']))
        credited = credited if audit['credits_complete'] else None
        item={'requirement_id':rid,'kind':requirement['kind'],'status':evaluation['status'],'message':evaluation['message'],
              'required_credits':required,'earned_credits':credited,
              'remaining_credits':0 if evaluation['status']=='pass' else max(0,float(ev.number(required)-ev.number(credited))) if required is not None and credited is not None else None,
              'courses':rows,'minimum_additional_credits':requirement['minimum_additional_credits'],
              'maximum_shared_credits':requirement['maximum_shared_credits'],'source_refs':requirement['source_refs']}
        if requirement['kind']=='non_credit':
            item['required_units']=requirement['minimum_evidence_units']
            item['completed_units']=sum(e['completed_units'] for e in academic['non_credit_evidence'] if e['requirement_id']==rid and e['evidence_type']==requirement['evidence_type'] and e['state']=='approved')
        sections[key]['requirements'].append(item)
        sections[key]['missing_mapping']=False
    for section in sections.values():
        if section['requirements']:
            states={r['status'] for r in section['requirements']}
            section['status']='fail' if 'fail' in states else 'needs_review' if 'needs_review' in states else 'pass'
        section['note']='尚未接入你的適用年度要求或認列對照，請先向學校核對。' if section['missing_mapping'] else '各門檻可能共用學分，不可將各欄相加當成畢業總學分。'
    enrolled=[{'record_id':r['record_id'],'course_id':r['course_id'],'name':courses.get(r['course_id'],{}).get('name',r['course_id']),
               'term_id':r['term_id'],'listed_credits':courses.get(r['course_id'],{}).get('credits'),'grade_state':'pending','earned_credits':0} for r in academic['records'] if r['state']=='enrolled']
    pending_records=[{'record_id':r['record_id'],'course_id':r['course_id'],'name':courses.get(r['course_id'],{}).get('name',r['course_id']),
                      'reason':'免修、抵免或學分用途需要確認。'} for r in academic['records'] if r['approval']=='pending' or r['earned_credits'] is None and r['state'] in ('completed','transfer')]
    known=academic['record_coverage']=='complete' and audit['earned_credits'] is not None
    percent=min(100,round(audit['earned_credits']/audit['minimum_total_credits']*100,1)) if known and audit['minimum_total_credits'] else None
    return {'view_version':'graduation-progress-1','data_mode':'synthetic','reference_layout':'scu-graduation-credit-report',
            'reference_url':'https://web.sys.scu.edu.tw/chkCredit/sCreditList.asp','personal_school_data_imported':False,
            'entry_year':profile['entry_year'],'applicable_rule_entry_year':rules['entry_year'],'records_revision':academic['records_revision'],
            'rule_version':rules['version'],'records_updated_at':records_updated_at,'school_generated_at':None,
            'summary':{'earned_credits':audit['earned_credits'],'minimum_total_credits':audit['minimum_total_credits'],
                       'remaining_credits':audit['remaining_earned_credits'],'in_progress_credits':audit['in_progress_credits'],
                       'planned_credits':audit['planned_credits'],'completion_percent':percent,
                       'requirements_completed':sum(c['status']=='pass' for c in audit['current_requirements']['checks']),
                       'requirements_count':len(audit['current_requirements']['checks']),
                       'all_known_requirements_met':audit['current_requirements']['status']=='pass',
                       'official_graduation_eligible':None},
            'sections':list(sections.values()),'missing_required_courses':missing_courses,'in_progress_courses':enrolled,'pending_records':pending_records,
            'recognition_notes':['已修讀或列示學分不代表已採計為畢業學分。','全學年課程須有整組通過及採計依據；目前未接入全學年對照，不能只憑單學期成績判定。',
                                 '同名課程不自動當作必修替代；免修、抵免與外系上限依適用年度及核定資料核對。',
                                 '修習中、規劃與公開課程試排不會增加已得學分。']}
