"""Conservative evaluator for BE-01's synthetic curriculum, never official SCU advice."""
from copy import deepcopy
from decimal import Decimal
import uuid


def number(value):
    return Decimal(str(value))


def amount(value):
    return float(value)


def check(rules, dimension, status, message, code=None, suffix="", missing=None):
    return {"check_id": dimension + "-" + (suffix or uuid.uuid4().hex[:10]), "dimension": dimension,
            "status": status, "reason_codes": [code] if code else [], "missing_fields": missing or [],
            "rule_version": rules["version"], "source_refs": rules["source_refs"], "message": message}


def evaluation(checks):
    statuses = {c["status"] for c in checks}
    status = "fail" if "fail" in statuses else "needs_review" if "needs_review" in statuses else "pass"
    return {"status": status, "checks": checks, "conditional": status == "needs_review"}


def passed(record):
    return record["state"] == "completed" and record["earned_credits"] is not None and record["earned_credits"] > 0


def eligibility(course, profile, academic, rules):
    conditions = course["conditions"]
    if conditions is None:
        return evaluation([check(rules, "eligibility", "needs_review", "先修條件未知，請向開課單位核對。", "PREREQUISITES_UNKNOWN")])
    checks = []
    for condition in conditions:
        target = condition["target_id"]
        if condition["kind"] == "approved_program":
            ok = any(p["program_id"] == target and p["state"] == "approved" for p in profile["programs"])
            checks.append(check(rules, "eligibility", "pass" if ok else "fail", "學程資格已核定。" if ok else "需要正式核定的學程身分；探索意願不等於核准。", None if ok else "PROGRAM_NOT_APPROVED"))
        else:
            records = [r for r in academic["records"] if r["course_id"] == target and passed(r)]
            minimum = condition["minimum_grade"]
            good = any(minimum is None or (r["grade"] is not None and r["grade"] >= minimum) for r in records)
            unknown = academic["record_coverage"] != "complete" or any(r["course_id"] == target and (r["earned_credits"] is None or (minimum is not None and r["grade"] is None)) for r in academic["records"])
            status = "pass" if good else "needs_review" if unknown else "fail"
            checks.append(check(rules, "eligibility", status, f"先修 {target}：" + {"pass": "已通過。", "fail": "尚未通過。", "needs_review": "紀錄不足，待核對。"}[status], None if good else "RECORD_COVERAGE_INCOMPLETE" if unknown else "PREREQUISITE_NOT_MET"))
    if not checks:
        checks = [check(rules, "eligibility", "pass", "已知無額外先修限制。")]
    if course["condition_mode"] == "any" and any(c["status"] == "pass" for c in checks):
        return evaluation([check(rules, "eligibility", "pass", "任一先修條件已滿足。")])
    if course["condition_mode"] == "any" and any(c["status"] == "needs_review" for c in checks):
        return evaluation([check(rules, "eligibility", "needs_review", "任一先修條件仍有紀錄待核對，無法判定全數不符。", "RECORD_COVERAGE_INCOMPLETE")])
    return evaluation(checks)


def overlap(a, b):
    return a["weekday"] == b["weekday"] and max(a["start_minute"], b["start_minute"]) < min(a["end_minute"], b["end_minute"])


def schedule(offerings, preferences, rules):
    checks, meetings = [], []
    for offering in offerings:
        if offering["meetings"] is None:
            checks.append(check(rules, "schedule", "needs_review", f"{offering['offering_id']} 上課時間未知。", "MEETINGS_UNKNOWN"))
        for meeting in offering["meetings"] or []:
            meetings.append((offering["offering_id"], meeting))
            if meeting["teaching_weeks"] is None:
                checks.append(check(rules, "schedule", "needs_review", "上課週次未知。", "WEEKS_UNKNOWN"))
            if meeting["modality"] == "onsite" and meeting["campus_id"] is None:
                checks.append(check(rules, "schedule", "needs_review", "實體授課校區未知。", "CAMPUS_UNKNOWN"))
            for block in preferences["time_blocks"]:
                if block["kind"] == "unavailable" and overlap(meeting, block):
                    checks.append(check(rules, "schedule", "fail", f"{offering['offering_id']} 落在不可排課時間。", "UNAVAILABLE_TIME"))
    for index, (aid, a) in enumerate(meetings):
        for bid, b in meetings[index+1:]:
            if a["weekday"] != b["weekday"]:
                continue
            if a["teaching_weeks"] is not None and b["teaching_weeks"] is not None and not set(a["teaching_weeks"]) & set(b["teaching_weeks"]):
                continue
            unknown_weeks = a["teaching_weeks"] is None or b["teaching_weeks"] is None
            if overlap(a, b):
                checks.append(check(rules, "schedule", "needs_review" if unknown_weeks else "fail", f"{aid} 與 {bid} 時間重疊。", "WEEKS_UNKNOWN" if unknown_weeks else "TIME_OVERLAP"))
                continue
            if a["modality"] == b["modality"] == "onsite" and a["campus_id"] and b["campus_id"] and a["campus_id"] != b["campus_id"]:
                gap = max(a["start_minute"], b["start_minute"]) - min(a["end_minute"], b["end_minute"])
                policy = rules["cross_campus_policy"]
                if (gap == 0 and policy["forbid_back_to_back"]) or gap < policy["minimum_gap_minutes"]:
                    checks.append(check(rules, "schedule", "needs_review" if unknown_weeks else "fail", f"{aid} 與 {bid} 跨校區緩衝不足（{gap} 分鐘）。", "CROSS_CAMPUS_BACK_TO_BACK" if gap == 0 else "TRAVEL_GAP_TOO_SHORT"))
    return evaluation(checks or [check(rules, "schedule", "pass", "已核對全部已知時段、週次及跨校區緩衝。")])


def soft_mismatches(offering, preferences):
    free, campus = 0, 0
    for meeting in offering["meetings"] or []:
        for block in preferences["time_blocks"]:
            if block["kind"] == "prefer_free" and overlap(meeting, block):
                free += min(meeting["end_minute"], block["end_minute"]) - max(meeting["start_minute"], block["start_minute"])
        for block in preferences["campus_blocks"]:
            if overlap(meeting, block) and meeting["campus_id"] != block["campus_id"]:
                campus += min(meeting["end_minute"], block["end_minute"]) - max(meeting["start_minute"], block["start_minute"])
    return ([{"code": "PREFER_FREE", "minutes": free, "message": "占用希望留白時間。"}] if free else []) + ([{"code": "CAMPUS_PREFERENCE_MISMATCH", "minutes": campus, "message": "與希望校區不同；仍可自行選擇。"}] if campus else [])


def audit(profile, academic, catalog, rules, plan):
    courses = {c["course_id"]: c for c in catalog["courses"]}
    offerings = {o["offering_id"]: o for o in catalog["offerings"]}
    requirements = rules["requirements"]
    allocations, taken_groups, earned_courses, waived, enrolled, planned = [], set(), {}, set(), {}, {}
    complete = academic["record_coverage"] == "complete"
    earned = Decimal(0)
    def group(cid):
        return courses.get(cid, {}).get("credit_equivalence_group_id") or cid
    def req_ids(cid):
        return [r["requirement_id"] for r in requirements if r["kind"] == "total_credits" or cid in r["course_ids"]]
    # Prefer the largest valid earned attempt; count one equivalence group once.
    for record in sorted(academic["records"], key=lambda r: r["earned_credits"] or 0, reverse=True):
        cid = record["course_id"]
        if record["state"] == "waiver":
            if record["approval"] == "approved":
                waived.add(cid)
                allocations.append({"course_id": cid, "record_id": record["record_id"], "offering_id": None, "requirement_ids": [r["requirement_id"] for r in requirements if cid in r["course_ids"] and r["waiver_satisfies_course"]], "state": "waiver", "earned_credits": 0, "projected_credits": 0, "recognition": "approved", "source_refs": record["source_refs"]})
            continue
        if record["state"] == "enrolled":
            enrolled[cid] = courses.get(cid, {}).get("credits")
            continue
        if record["state"] not in ("completed", "transfer") or (record["state"] == "transfer" and record["approval"] != "approved"):
            continue
        if record["earned_credits"] is None:
            complete = False
            continue
        if record["earned_credits"] <= 0 or group(cid) in taken_groups:
            continue
        taken_groups.add(group(cid))
        earned_courses[cid] = number(record["earned_credits"])
        earned += earned_courses[cid]
        allocations.append({"course_id": cid, "record_id": record["record_id"], "offering_id": None, "requirement_ids": req_ids(cid), "state": "earned", "earned_credits": record["earned_credits"], "projected_credits": record["earned_credits"], "recognition": "approved", "source_refs": record["source_refs"]})
    for selection in plan["selections"]:
        if selection["placement"] != "scheduled":
            continue
        offering = offerings[selection["offering_id"]]
        cid = offering["course_id"]
        if group(cid) in taken_groups or cid in enrolled or cid in planned:
            continue
        planned[cid] = courses[cid]["credits"]
        allocations.append({"course_id": cid, "record_id": None, "offering_id": offering["offering_id"], "requirement_ids": req_ids(cid), "state": "planned", "earned_credits": 0, "projected_credits": courses[cid]["credits"], "recognition": "projected", "source_refs": offering["source_refs"]})
    enrolled_groups = set(taken_groups)
    in_progress = Decimal(0)
    for cid, credit in enrolled.items():
        if group(cid) not in enrolled_groups:
            if credit is None:
                complete = False
            else:
                in_progress += number(credit)
            enrolled_groups.add(group(cid))
    plan_groups = set(enrolled_groups)
    plan_credits = Decimal(0)
    for cid, credit in planned.items():
        if group(cid) not in plan_groups:
            if credit is None:
                complete = False
            else:
                plan_credits += number(credit)
            plan_groups.add(group(cid))
    minimum = next((r["minimum_credits"] for r in requirements if r["kind"] == "total_credits"), None)
    def requirement_checks(projected):
        checks = []
        available = {**earned_courses}
        if projected:
            available.update({cid: number(c) for cid, c in {**enrolled, **planned}.items() if c is not None and group(cid) not in taken_groups})
        for req in requirements:
            rid, kind = req["requirement_id"], req["kind"]
            status, code, message = "pass", None, "已滿足。"
            if kind == "total_credits":
                total = earned + (in_progress + plan_credits if projected else 0)
                if not complete:
                    status, code, message = "needs_review", "RECORD_COVERAGE_INCOMPLETE", "學分紀錄不完整，不能判定達標。"
                elif total < number(req["minimum_credits"]):
                    status, code, message = "fail", "CREDIT_DEFICIT", "尚缺總學分。"
            elif kind == "required_courses":
                missing = set(req["course_ids"]) - set(available) - (waived if req["waiver_satisfies_course"] else set())
                if missing:
                    status, code, message = ("fail", "REQUIRED_COURSE_MISSING", "缺少：" + "、".join(sorted(missing))) if complete else ("needs_review", "RECORD_COVERAGE_INCOMPLETE", "科目紀錄待核對。")
            elif kind == "group_credits":
                total = sum((available.get(cid, Decimal(0)) for cid in req["course_ids"]), Decimal(0))
                outside = set().union(*(set(other["course_ids"]) for other in requirements if other["requirement_id"] in req["additional_outside_requirement_ids"]))
                additional = sum((available.get(cid, Decimal(0)) for cid in req["course_ids"] if cid not in outside), Decimal(0))
                shared = sum((available.get(cid, Decimal(0)) for cid in req["course_ids"] if cid in outside), Decimal(0))
                if not complete:
                    status, code, message = "needs_review", "RECORD_COVERAGE_INCOMPLETE", "群組學分待核對。"
                elif total < number(req["minimum_credits"] or 0):
                    status, code, message = "fail", "CREDIT_DEFICIT", "學程群組學分不足。"
                elif req["maximum_shared_credits"] is not None and shared > number(req["maximum_shared_credits"]):
                    status, code, message = "fail", "SHARING_LIMIT_EXCEEDED", "共用學分超過上限。"
                elif req["minimum_additional_credits"] is not None and additional < number(req["minimum_additional_credits"]):
                    status, code, message = "fail", "ADDITIONAL_CREDIT_DEFICIT", "額外學分不足。"
            elif kind == "non_credit":
                units = sum(e["completed_units"] for e in academic["non_credit_evidence"] if e["requirement_id"] == rid and e["evidence_type"] == req["evidence_type"] and e["state"] == "approved")
                if units < (req["minimum_evidence_units"] or 0):
                    status, code, message = "needs_review", "RECOGNITION_APPROVAL_PENDING", "缺少非學分核定證據。"
            else:
                status, code, message = "needs_review", "RECOGNITION_APPROVAL_PENDING", "此類門檻需要人工覆核。"
            checks.append(check(rules, "requirement", status, f"{rid}：{message}" + ("（規劃全數通過後預估）" if projected else ""), code, rid + ("-projected" if projected else "-current")))
        return evaluation(checks)
    projected_total = earned + in_progress + plan_credits
    return {"audit_id": "audit-" + uuid.uuid4().hex, "credits_complete": complete,
            "earned_credits": amount(earned) if complete else None, "in_progress_credits": amount(in_progress) if complete else None,
            "planned_credits": amount(plan_credits) if complete else None, "minimum_total_credits": minimum,
            "remaining_earned_credits": amount(max(Decimal(0), number(minimum)-earned)) if complete and minimum is not None else None,
            "projected_total_credits": amount(projected_total) if complete else None,
            "projected_remaining_credits": amount(max(Decimal(0), number(minimum)-projected_total)) if complete and minimum is not None else None,
            "current_requirements": requirement_checks(False), "projected_requirements": requirement_checks(True), "allocations": allocations}


def validate_plan(profile, academic, catalog, rules, plan):
    courses = {c["course_id"]: c for c in catalog["courses"]}
    by_id = {o["offering_id"]: o for o in catalog["offerings"]}
    selected = [by_id[s["offering_id"]] for s in plan["selections"] if s["placement"] == "scheduled"]
    elig = [c for o in selected for c in eligibility(courses[o["course_id"]], profile, academic, rules)["checks"]]
    elig = evaluation(elig or [check(rules, "eligibility", "pass", "目前沒有已排入班別。")])
    sched = schedule(selected, plan["preferences"], rules)
    course_ids = [o["course_id"] for o in selected]
    if len(course_ids) != len(set(course_ids)):
        sched["checks"].append(check(rules, "schedule", "fail", "同一科目不能選兩個班別。", "INVALID_VALUE"))
    missing = set(plan["required_course_ids"]) - set(course_ids)
    if missing:
        sched["checks"].append(check(rules, "schedule", "fail", "必排科目尚未加入：" + "、".join(sorted(missing)), "REQUIRED_COURSE_MISSING"))
    credits = [courses[cid]["credits"] for cid in course_ids]
    if any(c is None for c in credits):
        sched["checks"].append(check(rules, "schedule", "needs_review", "本學期選課學分未知。", "RECORD_COVERAGE_INCOMPLETE"))
    else:
        total = sum(map(number, credits), Decimal(0))
        upper = min(c for c in [rules["max_term_credits"], plan["preferences"]["max_credits"]] if c is not None)
        if total > number(upper) or total < number(plan["preferences"]["min_credits"]):
            sched["checks"].append(check(rules, "schedule", "fail", "本學期學分不在允許範圍。", "TERM_CREDIT_LIMIT"))
    sched = evaluation(sched["checks"])
    review = any(s["placement"] == "review_queue" for s in plan["selections"])
    recognition = evaluation([check(rules, "recognition", "needs_review" if review else "pass", "待核對佇列需人工處理。" if review else "僅提供已知合成課規的預估採計；不構成校方核定。", "RECOGNITION_APPROVAL_PENDING" if review else None)])
    result = {"validation_id": "validation-" + uuid.uuid4().hex, "plan_id": plan["plan_id"], "plan_revision": plan["revision"],
              "eligibility": elig, "schedule": sched, "recognition": recognition, "audit": audit(profile, academic, catalog, rules, plan),
              "pending_task_ids": ["review-queue"] if review else [], "can_confirm_preselection": elig["status"] == sched["status"] == "pass" and bool(selected)}
    return result
