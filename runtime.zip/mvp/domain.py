"""Deterministic rules for the two synthetic demonstration data packs.

No career suitability or official school decisions are made here. Candidate
validation is distinct from an exhaustive search proving the model infeasible.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timedelta, timezone
from itertools import combinations, product
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
TAIPEI = timezone(timedelta(hours=8))
VIRTUAL_NOW = "2026-11-02T10:00:00+08:00"


def load_fixture():
    fixture = json.loads((ROOT / "knowledge-base/data/mvp-synthetic-scenario.json").read_text(encoding="utf-8-sig"))
    fixture["expected_attempt_course_ids"] = sorted({a["course_id"] for a in fixture["completed_attempts"]})
    return fixture


def load_activities():
    return json.loads((Path(__file__).parent / "data/activities.json").read_text(encoding="utf-8-sig"))


def _record_states(fixture):
    states = {}
    current_term = fixture.get("scope", {}).get("term_id")
    for attempt in fixture.get("completed_attempts", []):
        course_id = attempt.get("course_id")
        if not course_id:
            continue
        state = attempt.get("result")
        if state == "passed" and attempt.get("term_id") == current_term:
            state = "in_progress"
        if states.get(course_id) == "passed":
            continue
        if state == "passed" or course_id not in states or states[course_id] in (None, "missing", "unknown"):
            states[course_id] = state
    for course_id in fixture.get("expected_attempt_course_ids", []):
        states.setdefault(course_id, "missing")
    return states


def _missing_attempts(fixture, states):
    return sorted(course_id for course_id, state in states.items() if state in (None, "missing", "unknown", "unconfirmed"))


def analyze_credits(fixture, offering_ids=None):
    courses = {c["id"]: c for c in fixture.get("courses", [])}
    offerings = {o["id"]: o for o in fixture.get("offerings", [])}
    states = _record_states(fixture)
    missing = _missing_attempts(fixture, states)
    planned_ids = {offerings[oid]["course_id"] for oid in (offering_ids or []) if oid in offerings}
    qualification = fixture.get("qualification", {})
    categories = qualification.get("required_categories", [])
    result = {"scenario_id": fixture.get("scenario_id"), "synthetic": True, "missing_inputs": [], "citations": [qualification.get("rule_source_id", "SYN-RULESET-001")]}
    allocated = set()
    totals = dict(needed=0, confirmed=0, in_progress=0, planned=0)
    total_unknown = False
    for category in categories:
        needed = category.get("required_credits")
        category_ids = [cid for cid in category.get("course_ids", []) if cid not in allocated]
        allocated.update(category_ids)
        unknown = needed is None
        confirmed = progress = planned = 0
        for course_id in category_ids:
            course = courses.get(course_id)
            if not course or course.get("credits") is None:
                unknown = True
                result["missing_inputs"].append(f"{course_id} 的課程學分")
                continue
            credits = course["credits"]
            state = states.get(course_id, "not_taken")
            if course_id in missing:
                unknown = True
                result["missing_inputs"].append(f"{course_id} 的修課結果")
            if state == "passed":
                confirmed += credits
            elif state in ("in_progress", "enrolled"):
                progress += credits
            if course_id in planned_ids and state != "passed":
                planned += credits
        if needed is not None:
            confirmed = min(confirmed, needed)
            progress = min(progress, max(needed - confirmed, 0))
            planned = min(planned, max(needed - confirmed - progress, 0))
        status = "unknown" if unknown else ("satisfied" if confirmed >= needed else "unsatisfied")
        row = dict(needed=needed, confirmed=confirmed, in_progress=progress, planned=planned,
                   gap=None if unknown else max(needed - confirmed, 0),
                   projected_gap_if_all_passed=None if unknown else max(needed - confirmed - progress - planned, 0),
                   requirement_status=status)
        row["uncompleted_course_ids"] = [cid for cid in category_ids if states.get(cid) != "passed"]
        result[category["id"]] = row
        for key in totals:
            if row[key] is not None:
                totals[key] += row[key]
        total_unknown |= unknown
    if not categories or qualification.get("required_total_credits") is None:
        total_unknown = True
        result["missing_inputs"].append("資格需求與採計規則")
    elif totals["needed"] != qualification["required_total_credits"]:
        total_unknown = True
        result["missing_inputs"].append("分類學分與總需求不一致，需覆核規則")
    totals["requirement_status"] = "unknown" if total_unknown else ("satisfied" if totals["confirmed"] >= totals["needed"] else "unsatisfied")
    totals["gap"] = None if total_unknown else max(totals["needed"] - totals["confirmed"], 0)
    totals["projected_gap_if_all_passed"] = None if total_unknown else max(totals["needed"] - totals["confirmed"] - totals["in_progress"] - totals["planned"], 0)
    result["total"] = totals
    result["requirement_status"] = totals["requirement_status"]
    result["qualification_completed"] = totals["requirement_status"] == "satisfied"
    result["condition"] = "規劃與在修不算已取得；只有全數選上、修畢通過且規則不變，才成立預估。"
    return result


def _minutes(value):
    hour, minute = map(int, str(value).split(":"))
    if not (0 <= hour < 24 and 0 <= minute < 60):
        raise ValueError("時間無效")
    return hour * 60 + minute


def _meetings(fixture, offering):
    constraints = fixture.get("planning_constraints", {})
    rows = offering.get("meetings", [offering])
    normalized = []
    for row in rows:
        start, end = _minutes(row["start"]), _minutes(row["end"])
        if start >= end or not row.get("day"):
            raise ValueError("時間範圍或星期無效")
        weeks = row.get("weeks")
        if weeks is None:
            weeks = range(int(row.get("week_start", constraints.get("meeting_week_start", 1))), int(row.get("week_end", constraints.get("meeting_week_end", 18))) + 1)
        weeks = set(weeks)
        if not weeks:
            raise ValueError("上課週次缺失")
        normalized.append(dict(day=row["day"], start=start, end=end, weeks=weeks))
    return normalized


def check_plan(fixture, offering_ids):
    courses = {c["id"]: c for c in fixture.get("courses", [])}
    offerings = {o["id"]: o for o in fixture.get("offerings", [])}
    constraints = fixture.get("planning_constraints", {})
    states = _record_states(fixture)
    issues = []
    missing = []
    selected = []
    selected_ids = list(dict.fromkeys(offering_ids))
    def issue(code, message, ids=None):
        issues.append(dict(code=code, message=message, offering_ids=ids or []))
    if len(selected_ids) != len(offering_ids):
        issue("duplicate_offering", "同一班別不可重複加入。")
    for offering_id in selected_ids:
        if offering_id not in offerings:
            missing.append(f"{offering_id} 的開課資料")
            issue("missing_offering", f"找不到 {offering_id} 開課資料。", [offering_id])
        else:
            selected.append(offerings[offering_id])
    for offering_id in constraints.get("fixed_offering_ids", []):
        if offering_id not in selected_ids:
            issue("fixed_course_missing", f"必須保留固定課 {offering_id}。", [offering_id])
    course_ids = [o["course_id"] for o in selected]
    for course_id in constraints.get("mandatory_planned_course_ids", []):
        if course_id not in course_ids:
            issue("mandatory_course_missing", f"本次展示任務必須規劃 {course_id}。")
    for course_id in set(course_ids):
        same = [o["id"] for o in selected if o["course_id"] == course_id]
        if len(same) > 1 and not constraints.get("same_course_multiple_offerings_allowed", False):
            issue("duplicate_course", f"{course_id} 不可同時選兩個班別。", same)
    semester_credits = 0
    all_meetings = []
    for offering in selected:
        course = courses.get(offering["course_id"])
        if not course or course.get("credits") is None:
            missing.append(f"{offering['course_id']} 的科目學分資料")
            continue
        semester_credits += course["credits"]
        for prerequisite in course.get("prerequisites", []):
            state = states.get(prerequisite, "not_taken")
            if state in (None, "missing", "unknown", "unconfirmed"):
                missing.append(f"{prerequisite} 的先前學期修課結果")
                issue("prerequisite_unknown", f"{course['id']} 的先修 {prerequisite} 通過狀態待確認。", [offering["id"]])
            elif state != "passed":
                issue("prerequisite", f"{course['id']} 需在先前學期通過 {prerequisite}；同學期排入不能解除擋修。", [offering["id"]])
        try:
            all_meetings.extend((offering["id"], meeting) for meeting in _meetings(fixture, offering))
        except (KeyError, ValueError, TypeError):
            missing.append(f"{offering['id']} 的時段或週次")
            issue("meeting_unknown", f"{offering['id']} 時段或週次不完整。", [offering["id"]])
    elective_count = len({cid for cid in course_ids if courses.get(cid, {}).get("category") == "elective"})
    if "elective_courses_to_plan" in constraints and elective_count != constraints["elective_courses_to_plan"]:
        issue("elective_count", f"本次展示任務需規劃 {constraints['elective_courses_to_plan']} 門選修。")
    limit = constraints.get("max_semester_credits")
    if limit is None:
        missing.append("本學期學分上限")
    elif semester_credits > limit:
        issue("credit_limit", f"本學期 {semester_credits} 學分，超過上限 {limit}。")
    for (left_id, left), (right_id, right) in combinations(all_meetings, 2):
        if left_id == right_id:
            continue
        if left["day"] == right["day"] and left["weeks"] & right["weeks"] and max(left["start"], right["start"]) < min(left["end"], right["end"]):
            issue("time_conflict", f"{left_id} 與 {right_id} 在相同週次及星期有重疊時段。", [left_id, right_id])
    days = {meeting["day"] for _, meeting in all_meetings}
    idle_minutes = 0
    for day in days:
        intervals = sorted(set((m["start"], m["end"]) for _, m in all_meetings if m["day"] == day))
        last_end = None
        for start, end in intervals:
            if last_end is not None:
                idle_minutes += max(start - last_end, 0)
            last_end = max(last_end or end, end)
    analysis = analyze_credits(fixture, selected_ids)
    missing.extend(analysis["missing_inputs"])
    status = "insufficient_data" if missing else ("blocked" if issues else "feasible")
    return dict(status=status, scheduling_status=status if status != "blocked" else None,
                check_scope="candidate", issues=issues, missing_inputs=sorted(set(missing)),
                offering_ids=selected_ids, semester_credits=semester_credits,
                planned_target_credits=analysis["total"]["planned"], teaching_days=len(days),
                has_friday=bool(days & {"Fri", "Friday", "週五", "星期五"}), idle_minutes=idle_minutes,
                requirement_status=analysis["requirement_status"], synthetic=True,
                citations=[fixture.get("qualification", {}).get("rule_source_id", "SYN-RULESET-001")])


def search_plans(fixture, search_budget=500, prefer_no_friday=True):
    constraints = fixture.get("planning_constraints", {})
    courses = {c["id"]: c for c in fixture.get("courses", [])}
    by_course = {}
    for offering in fixture.get("offerings", []):
        by_course.setdefault(offering["course_id"], []).append(offering["id"])
    states = _record_states(fixture)
    mandatory = constraints.get("mandatory_planned_course_ids", [])
    electives = sorted(cid for cid, c in courses.items() if c.get("category") == "elective" and cid in by_course and states.get(cid) != "passed")
    count = constraints.get("elective_courses_to_plan", 1)
    elective_groups = list(combinations(electives, count))
    candidates = []
    for elective_group in elective_groups:
        options = [by_course.get(cid, []) for cid in list(mandatory) + list(elective_group)]
        for selection in product(*options):
            candidates.append(list(dict.fromkeys(constraints.get("fixed_offering_ids", []) + list(selection))))
    aliases = {frozenset(p["offering_ids"]): p["id"] for p in fixture.get("comparison_plans", [])}
    plans, diagnostics, missing = [], [], []
    processed = 0
    for offering_ids in candidates:
        if processed >= max(0, int(search_budget)):
            break
        checked = check_plan(fixture, offering_ids)
        processed += 1
        if checked["status"] == "feasible":
            checked["id"] = aliases.get(frozenset(offering_ids), "")
            checked["plan_id"] = checked["id"]
            plans.append(checked)
        elif checked["status"] == "insufficient_data":
            missing.extend(checked["missing_inputs"])
        diagnostics.extend(checked["issues"])
    search_complete = processed == len(candidates) and int(search_budget) > 0
    baseline = analyze_credits(fixture)
    missing.extend(baseline["missing_inputs"])
    if missing:
        status = "insufficient_data"
    elif not search_complete:
        status = "search_incomplete"
    else:
        status = "feasible" if plans else "infeasible"
    plans.sort(key=lambda plan: (plan["teaching_days"], plan["has_friday"] if prefer_no_friday else False, plan["idle_minutes"], tuple(plan["offering_ids"])))
    numbered = 1
    for plan in plans:
        if not plan["id"]:
            plan["id"] = plan["plan_id"] = f"P{numbered}"
            numbered += 1
    unique_issues = []
    seen = set()
    for row in diagnostics:
        key = (row["code"], row["message"], tuple(row["offering_ids"]))
        if key not in seen:
            unique_issues.append(row)
            seen.add(key)
    return dict(status=status, scheduling_status=status, plans=plans, search_complete=search_complete,
                processed_candidates=processed, candidate_count=len(candidates), issues=unique_issues,
                missing_inputs=sorted(set(missing)), synthetic=True,
                comparison_disclosure="A/B/C 是原文件的展示子集；本次候選依當前合成模型枚舉，僅對已建模限制成立，不代表全部真實課表或職涯最佳解。")


def rows_for_export(fixture, offering_ids, metadata):
    checked = check_plan(fixture, offering_ids)
    if checked["status"] != "feasible":
        raise ValueError("僅可匯出通過已建模硬限制的候選方案。")
    courses = {c["id"]: c for c in fixture["courses"]}
    offerings = {o["id"]: o for o in fixture["offerings"]}
    states = _record_states(fixture)
    rows = []
    remaining = {c["id"]: analyze_credits(fixture)[c["id"]]["gap"] for c in fixture["qualification"]["required_categories"]}
    counted_courses = set()
    for offering_id in offering_ids:
        offering = offerings[offering_id]
        course = courses[offering["course_id"]]
        category = course.get("category", "outside_target")
        counted = 0
        if category in remaining and course["id"] not in counted_courses and states.get(course["id"]) != "passed":
            counted = min(course["credits"], remaining[category])
            remaining[category] -= counted
        counted_courses.add(course["id"])
        row = dict(scenario_id=fixture["scenario_id"], plan_id=metadata.get("plan_id", ""),
                   input_snapshot_id=metadata.get("input_snapshot_id", ""), export_id=metadata.get("export_id", ""),
                   generated_at=metadata.get("generated_at", ""), offering_id=offering_id, course_id=course["id"],
                   course_name=course["name"], credits=course["credits"], requirement_category=category,
                   counted_target_credits=counted, day=offering["day"], start_time=offering["start"],
                   end_time=offering["end"], prerequisite_status="passed", scheduling_status="feasible",
                   data_version=fixture["scope"]["data_version"], rule_version=fixture["scope"]["rule_version"], synthetic=True)
        rows.append({key: row[key] for key in fixture["export_design"]["columns"]})
    return rows


def _datetime(value=None):
    if isinstance(value, datetime):
        parsed = value
    else:
        parsed = datetime.fromisoformat(value or VIRTUAL_NOW)
    return parsed.replace(tzinfo=TAIPEI) if parsed.tzinfo is None else parsed.astimezone(TAIPEI)


def _normalize(value):
    aliases = {"writing": "文字表達", "寫作": "文字表達", "social_issues": "社會議題", "work_life": "工作日常", "alumni": "校友對談", "online": "線上", "campus": "校內"}
    value = str(value).strip()
    return aliases.get(value, value)


def recommend_activities(profile, now=None):
    data = load_activities()
    now = _datetime(now)
    interests = {_normalize(v) for v in profile.get("interests", [])}
    formats = {_normalize(v) for v in profile.get("formats", [])}
    try:
        budget = float(profile.get("budget", 0))
    except (TypeError, ValueError):
        budget = 0
    output = []
    for source_activity in data["activities"]:
        activity = deepcopy(source_activity)
        exclusions, reasons = [], []
        source = activity.get("source")
        if not source or not source.get("id"):
            exclusions.append("主辦來源待確認")
        dates = {}
        for key in ("starts_at", "ends_at", "registration_deadline"):
            try:
                if not activity.get(key):
                    raise ValueError()
                dates[key] = _datetime(activity[key])
            except (ValueError, TypeError):
                exclusions.append("活動日期、時段或截止時間待確認")
                break
        if dates.get("ends_at") and dates["ends_at"] <= now:
            exclusions.append("活動已結束")
        if dates.get("registration_deadline") and dates["registration_deadline"] <= now:
            exclusions.append("報名已截止")
        if len(dates) == 3 and dates["starts_at"] >= dates["ends_at"]:
            exclusions.append("活動開始與結束時間不一致")
        if activity.get("status") == "cancelled":
            exclusions.append("活動已取消")
        if activity.get("status") == "full":
            exclusions.append("活動額滿")
        if activity.get("status") not in ("open", "cancelled", "full"):
            exclusions.append("活動開放狀態待確認")
        if activity.get("cost") is None:
            exclusions.append("費用待確認")
        elif activity["cost"] > budget:
            exclusions.append("超出自選預算")
        if formats and _normalize(activity.get("format")) not in formats:
            exclusions.append("不符合自選形式")
        tags = {_normalize(v) for v in activity.get("tags", [])}
        matched = sorted(tags & interests)
        if interests and not matched:
            exclusions.append("與本次自選主題不符")
        if matched:
            reasons.append("符合你選擇的" + "、".join(matched))
        elif not interests:
            reasons.append("尚未設定興趣，先提供低門檻活動供探索")
        if activity.get("cost") == 0:
            reasons.append("免費，符合目前預算")
        if activity.get("beginner_friendly"):
            reasons.append("無需相關經驗，可先試一次")
        activity.update(match_reasons=reasons, eligible=not exclusions, exclusion_reasons=list(dict.fromkeys(exclusions)),
                        match_score=len(matched), scenario_id=data["scenario_id"], synthetic=True)
        output.append(activity)
    output.sort(key=lambda item: (not item["eligible"], -item["match_score"], item.get("starts_at") or "9999", item["id"]))
    return output


def build_digest(profile, now=None, prior_keys=None):
    clock = _datetime(now)
    notification = profile.get("notification", {})
    iso = clock.isocalendar()
    profile_id = profile.get("id", profile.get("sub", profile.get("profile_id", "synthetic-student")))
    key = f"SYN-ACT-001:{profile_id}:{iso.year}-W{iso.week:02d}:in_app"
    result = dict(delivery_mode="preview", sent=False, status="empty", items=[], dedupe_key=key,
                  virtual_now=clock.isoformat(), scenario_id="SYN-ACT-001", synthetic=True,
                  next_action="合格活動不足時不補湊，可調整興趣或稍後再看。")
    if not notification.get("enabled", False):
        result.update(status="disabled", next_action="摘要尚未自主啟用；仍可瀏覽、搜尋與收藏。")
        return result
    try:
        start = _minutes(notification.get("quiet_start", "22:00"))
        end = _minutes(notification.get("quiet_end", "08:00"))
    except (TypeError, ValueError):
        raise ValueError("安靜時段格式需為 HH:MM。")
    minute = clock.hour * 60 + clock.minute
    quiet = (start <= minute < end) if start < end else (minute >= start or minute < end) if start > end else False
    if quiet:
        result.update(status="deferred", next_action="目前為安靜時段；僅模擬延後，不安排背景投遞。")
        return result
    keys = {row.get("dedupe_key") if isinstance(row, dict) else row for row in (prior_keys or [])}
    if key in keys:
        result.update(status="duplicate", next_action="本週摘要已預覽；不重複建立同期間的模擬摘要。")
        return result
    try:
        limit = min(3, max(0, int(notification.get("max_items", 3))))
    except (TypeError, ValueError):
        limit = 3
    excluded_ids = set(profile.get("excluded_activity_ids", []))
    eligible = [item for item in recommend_activities(profile, clock) if item["eligible"] and item["id"] not in excluded_ids]
    result["items"] = eligible[:limit]
    if result["items"]:
        result.update(status="ready", next_action="可查看及收藏活動；此為人造活動摘要預覽，不提供真實報名。")
    return result
