"""Read-only HTTP adapter for the independently imported public course catalog."""
from contextlib import contextmanager
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import sqlite3
import unicodedata
from urllib.parse import parse_qs, unquote, urlparse, urlsplit
import uuid

from .be02.errors import StoreError
from .public_reference import PublicScheduleReference, DEFAULT_REFERENCE


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATABASE = ROOT / 'output/scu-course-database-20261026/scu_public_courses.sqlite3'
PREFIX = '/api/v1/public-courses'
APPLICATION_ID = 0x53435543
NOTICE = '包含尚未提供選課編號的課表安排；正式開課與選課資訊請向學校確認。'
DAY_NAMES = ['', '一', '二', '三', '四', '五', '六', '日']
SESSION_CODES = {'1', '2', '3', '4', 'E', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'F1', 'F2', 'F3', 'F4', 'F'}


def normalized(value):
    return unicodedata.normalize('NFKC', value or '').strip()


def public_url(value):
    if not value:
        return None
    parsed = urlsplit(value)
    if parsed.scheme.lower() not in {'http', 'https'} or not parsed.netloc or parsed.username or parsed.password:
        return None
    return value


class PublicCatalogAPI:
    def __init__(self, path=None, reference_path=DEFAULT_REFERENCE):
        self.path = Path(path) if path is not None else DEFAULT_DATABASE
        self.reference = PublicScheduleReference(reference_path)

    @staticmethod
    def meta():
        return {'request_id': uuid.uuid4().hex, 'generated_at': datetime.now(timezone.utc).isoformat(),
                'contract_version': 'public-course-catalog-1.0', 'data_mode': 'public_samples'}

    @contextmanager
    def connection(self):
        con = None
        try:
            if not self.path.is_file():
                raise OSError('catalog missing')
            con = sqlite3.connect(self.path.resolve().as_uri() + '?mode=ro', uri=True, timeout=5)
            con.row_factory = sqlite3.Row
            con.execute('PRAGMA query_only=ON')
            con.execute('PRAGMA foreign_keys=ON')
            if con.execute('PRAGMA application_id').fetchone()[0] != APPLICATION_ID:
                raise OSError('wrong catalog')
            yield con
        except (OSError, sqlite3.Error):
            raise StoreError(503, 'PUBLIC_CATALOG_UNAVAILABLE', '公開課程樣本暫時無法讀取，請稍後重試。', retryable=True) from None
        finally:
            if con is not None:
                con.close()

    @staticmethod
    def query(target, allowed):
        try:
            values = parse_qs(urlparse(target).query, keep_blank_values=True, strict_parsing=True, max_num_fields=12)
        except ValueError:
            raise StoreError(422, 'INVALID_PUBLIC_CATALOG_QUERY', '查詢條件格式有誤。') from None
        if set(values) - set(allowed) or any(len(items) != 1 for items in values.values()):
            raise StoreError(422, 'INVALID_PUBLIC_CATALOG_QUERY', '請使用已支援且不重複的查詢條件。')
        result = {key: items[0].strip() for key, items in values.items() if items[0].strip()}
        for key, value in result.items():
            limit = 160 if key == 'q' else 128
            if len(value) > limit or any(ord(c) < 32 for c in value):
                raise StoreError(422, 'INVALID_PUBLIC_CATALOG_QUERY', '查詢文字過長或含無效字元。')
        if 'weekday' in result:
            if not re.fullmatch('[1-7]', result['weekday']):
                raise StoreError(422, 'INVALID_PUBLIC_CATALOG_QUERY', '星期需為1至7。')
            result['weekday'] = int(result['weekday'])
        if 'session' in result:
            result['session'] = result['session'].upper()
            if result['session'] not in SESSION_CODES:
                raise StoreError(422, 'INVALID_PUBLIC_CATALOG_QUERY', '請選擇有效的上課節次。')
        return result

    def handle(self, method, target):
        try:
            if method != 'GET':
                raise StoreError(405, 'PUBLIC_CATALOG_READ_ONLY', '公開課程目錄僅提供唯讀查詢。')
            path = unquote(urlparse(target).path)
            if path == PREFIX + '/meta':
                self.query(target, set())
                with self.connection() as con:
                    data = self.metadata(con)
            elif path == PREFIX:
                filters = self.query(target, {'q', 'class_group', 'teacher', 'weekday', 'session', 'term_id'})
                with self.connection() as con:
                    items = self.items(con, filters)
                    total = self.total(con, filters.get('term_id', 'SCU-115-1'))
                    data = {'items': items, 'total_items': total, 'matched_items': len(items), 'filters': filters}
            elif path.startswith(PREFIX + '/') and path.count('/') == PREFIX.count('/') + 1:
                self.query(target, set())
                offering_id = path.rsplit('/', 1)[-1]
                if not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', offering_id):
                    raise StoreError(404, 'PUBLIC_COURSE_NOT_FOUND', '找不到這筆公開課程。')
                with self.connection() as con:
                    data = self.detail(con, offering_id)
            else:
                raise StoreError(404, 'PUBLIC_COURSE_NOT_FOUND', '找不到這筆公開課程。')
            return 200, {'meta': self.meta(), 'data': data}
        except StoreError as exc:
            return exc.status, {'meta': self.meta(), 'error': exc.as_error()}

    @staticmethod
    def total(con, term):
        return con.execute('SELECT count(*) FROM scu_offering_heads h JOIN scu_offerings o USING(offering_id) WHERE o.term_id=?', (term,)).fetchone()[0]

    def metadata(self, con):
        terms = [{'term_id': r['term_id'], 'label': r['display_label']} for r in con.execute('SELECT * FROM scu_academic_terms ORDER BY academic_year_roc DESC,semester_code DESC')]
        classes = [{'class_group_id': r['class_group_id'], 'name': r['name_raw'].strip()} for r in con.execute('SELECT * FROM scu_class_groups ORDER BY raw_class_code,name_raw')]
        teachers = [{'instructor_id': r['instructor_id'], 'name': r['name_zh']} for r in con.execute('SELECT * FROM scu_instructors ORDER BY name_zh,instructor_id')]
        sessions = {r[0] for r in con.execute('SELECT DISTINCT session_code FROM scu_meeting_sessions')}
        order = ['1', '2', '3', '4', 'E', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'F', 'F1', 'F2', 'F3', 'F4']
        latest = con.execute('SELECT observed_at,timezone FROM scu_captures ORDER BY observed_at DESC,capture_id DESC LIMIT 1').fetchone()
        observed = latest['observed_at'] if latest else None
        return {'catalog_id': 'scu-public-samples-' + (observed or '').replace('-', ''), 'scope_label': '東吳公開課程樣本',
                'observed_at': observed, 'observed_timezone': latest['timezone'] if latest else None,
                'notice': NOTICE, 'total_items': self.total(con, terms[0]['term_id']) if terms else 0,
                'statistics': {
                    'current_items': con.execute('SELECT count(*) FROM scu_offering_heads').fetchone()[0],
                    'items_with_syllabus': con.execute('SELECT count(*) FROM scu_offering_heads WHERE syllabus_revision_id IS NOT NULL').fetchone()[0],
                    'offering_versions': con.execute('SELECT count(*) FROM scu_offering_revisions').fetchone()[0],
                    'syllabus_versions': con.execute('SELECT count(*) FROM scu_syllabus_revisions').fetchone()[0],
                    'captures': con.execute('SELECT count(*) FROM scu_captures').fetchone()[0]},
                'reference_context':self.reference.context(), 'terms': terms, 'class_groups': classes, 'teachers': teachers,
                'sessions': [{'value': code, 'label': code + ' 節'} for code in order if code in sessions],
                'weekdays': [{'value': n, 'label': '星期' + DAY_NAMES[n]} for n in range(1, 8)]}

    def items(self, con, filters=None, offering_id=None):
        f = filters or {}
        sql = '''SELECT o.offering_id,o.source_course_code,o.term_id,r.*,h.syllabus_revision_id
                   FROM scu_offerings o JOIN scu_offering_heads h USING(offering_id)
                   JOIN scu_offering_revisions r ON r.offering_revision_id=h.offering_revision_id
                  WHERE o.term_id=?'''
        params = [f.get('term_id', 'SCU-115-1')]
        if offering_id is not None:
            # An ID selects its own term; it cannot accidentally hide an otherwise valid historical-term item.
            sql = sql.replace('WHERE o.term_id=?', 'WHERE o.offering_id=?')
            params = [offering_id]
        if f.get('q'):
            sql += ' AND (instr(r.title_zh,?)>0 OR instr(upper(o.source_course_code),upper(?))>0)'
            params.extend([f['q'], f['q']])
        if f.get('class_group'):
            class_ids = [r[0] for r in con.execute('SELECT class_group_id,name_raw FROM scu_class_groups')
                         if r[0] == f['class_group'] or normalized(r[1]) == normalized(f['class_group'])]
            if not class_ids:
                return []
            sql += ' AND EXISTS (SELECT 1 FROM scu_offering_audiences a WHERE a.offering_revision_id=r.offering_revision_id AND a.class_group_id IN (' + ','.join('?' for _ in class_ids) + '))'
            params.extend(class_ids)
        if f.get('teacher'):
            sql += ' AND EXISTS (SELECT 1 FROM scu_teaching_assignments t WHERE t.offering_revision_id=r.offering_revision_id AND (t.instructor_id=? OR instr(t.display_name_raw,?)>0))'
            params.extend([f['teacher'], f['teacher']])
        if f.get('weekday') is not None or f.get('session'):
            sql += ' AND EXISTS (SELECT 1 FROM scu_meetings m LEFT JOIN scu_meeting_sessions ms USING(meeting_id) WHERE m.offering_revision_id=r.offering_revision_id'
            if f.get('weekday') is not None:
                sql += ' AND m.weekday_iso=?'; params.append(f['weekday'])
            if f.get('session'):
                sql += ' AND ms.session_code=?'; params.append(f['session'])
            sql += ')'
        sql += ' ORDER BY o.source_course_code,o.offering_id'
        return [self.item(con, row) for row in con.execute(sql, params)]

    def source(self, con, capture_id, role=None):
        row = con.execute('''SELECT s.source_id,s.title,s.canonical_url,c.capture_id,c.observed_at,c.query_parameters_json,
                                      c.content_sha256,c.time_precision,c.timezone
                               FROM scu_captures c JOIN scu_sources s USING(source_id) WHERE c.capture_id=?''', (capture_id,)).fetchone()
        if row is None:
            return None
        value = {'source_id': row['source_id'], 'capture_id': row['capture_id'],
                 'title': row['title'], 'url': public_url(row['canonical_url']),
                 'observed_at': row['observed_at'], 'query_parameters': json.loads(row['query_parameters_json'] or '{}')}
        value.update(content_sha256=row['content_sha256'], time_precision=row['time_precision'], timezone=row['timezone'])
        if role is not None:
            value['role'] = role
        return value

    def item(self, con, row):
        rid = row['offering_revision_id']
        classes = [{'class_group_id': r['class_group_id'], 'name': r['name_raw'].strip(), 'requirement_raw': r['requirement_raw']}
                   for r in con.execute('SELECT g.*,a.requirement_raw FROM scu_offering_audiences a JOIN scu_class_groups g USING(class_group_id) WHERE a.offering_revision_id=? ORDER BY g.name_raw', (rid,))]
        teachers = [{'instructor_id': r['instructor_id'], 'name': r['display_name_raw']}
                    for r in con.execute('SELECT * FROM scu_teaching_assignments WHERE offering_revision_id=? ORDER BY display_order', (rid,))]
        meetings = []
        for meeting in con.execute('SELECT * FROM scu_meetings WHERE offering_revision_id=? ORDER BY weekday_iso,meeting_id', (rid,)):
            sessions = list(con.execute('SELECT * FROM scu_meeting_sessions WHERE meeting_id=? ORDER BY sequence_no', (meeting['meeting_id'],)))
            resolved = bool(sessions) and all(s['resolution_state'] == 'resolved' and s['start_minute'] is not None and s['end_minute'] is not None for s in sessions)
            room = con.execute('SELECT * FROM scu_rooms WHERE room_id=?', (meeting['room_id'],)).fetchone()
            campus_name = room['campus_name'] if room and room['resolution_status'] in ('verified', 'document_mapped') else None
            campus_id = {'城中': 'CITY', '城中校區': 'CITY', '雙溪': 'SHUANGXI', '雙溪校區': 'SHUANGXI'}.get(campus_name)
            meetings.append({'weekday': meeting['weekday_iso'], 'weekday_raw': meeting['weekday_raw'], 'session_raw': meeting['session_sequence_raw'],
                             'session_codes': [s['session_code'] for s in sessions], 'week_raw': meeting['week_pattern_raw'], 'room': meeting['room_raw'],
                             'sessions': [{'code': s['session_code'], 'start_minute': s['start_minute'], 'end_minute': s['end_minute'], 'resolution_state': s['resolution_state'], 'rule_id': s['session_rule_id']} for s in sessions],
                             'campus_id': campus_id, 'campus_name': campus_name,
                             'campus_resolution': room['resolution_status'] if room else 'unresolved',
                             'teaching_weeks': json.loads(meeting['teaching_weeks_json']) if meeting['teaching_weeks_json'] is not None else None,
                             'week_pattern_kind': meeting['week_pattern_kind'],
                             'start_minute': min(s['start_minute'] for s in sessions) if resolved else None,
                             'end_minute': max(s['end_minute'] for s in sessions) if resolved else None})
        return self.reference.apply({'offering_id': row['offering_id'], 'term_id': row['term_id'], 'revision_id': rid, 'course_code': row['source_course_code'],
                'selection_number': row['selection_number'], 'title': row['title_zh'],
                'credits': None if row['credits_hundredths'] is None else row['credits_hundredths'] / 100,
                'credits_hundredths': row['credits_hundredths'], 'duration_raw': row['duration_raw'],
                'classes': classes, 'teachers': teachers, 'meetings': meetings, 'capacity_limit': row['capacity_limit'],
                'has_syllabus': row['syllabus_revision_id'] is not None,
                'official_syllabus_url': public_url(row['syllabus_url']),
                'source': self.source(con, row['capture_id']), 'syllabus_revision_id': row['syllabus_revision_id']})

    def syllabus(self, con, revision_id):
        r = con.execute('SELECT * FROM scu_syllabus_revisions WHERE syllabus_revision_id=?', (revision_id,)).fetchone()
        if r is None:
            return None
        result = {'revision_id': revision_id, 'source': self.source(con, r['capture_id']),
                  'source_generated_at': r['source_generated_at'], 'edited_at': r['content_edited_at'], 'edited_precision': r['edited_time_precision']}
        result['sections'] = []
        for section in con.execute('SELECT * FROM scu_syllabus_sections WHERE syllabus_revision_id=? ORDER BY display_order', (revision_id,)):
            # The preserved basic-info block is structured evidence, not a narrative section for the student UI.
            if section['section_kind'] == 'other' and section['heading_raw'].startswith('一、課程基本資料'):
                continue
            result['sections'].append({'kind': section['section_kind'], 'language': section['language_tag'], 'heading': section['heading_raw'], 'content': section['content_raw']})
        result['weeks'] = [{'week_number': w['week_number'], 'date_raw': w['date_raw'], 'content': w['content_raw'], 'note': w['note_raw']}
                           for w in con.execute('SELECT * FROM scu_syllabus_weeks WHERE syllabus_revision_id=? ORDER BY display_order', (revision_id,))]
        result['assessments'] = [{'name': a['item_name'], 'weight_percent': None if a['weight_basis_points'] is None else a['weight_basis_points']/100,
                                  'times': a['occurrence_count'], 'description': a['description_raw']}
                                 for a in con.execute('SELECT * FROM scu_assessment_items WHERE syllabus_revision_id=? ORDER BY display_order', (revision_id,))]
        result['resources'] = [{'kind': a['resource_kind'], 'citation': a['citation_raw'], 'url': public_url(a['url'])}
                               for a in con.execute('SELECT * FROM scu_resources WHERE syllabus_revision_id=? ORDER BY resource_kind,display_order', (revision_id,))]
        result['tags'] = [{'scheme': a['scheme'], 'code': a['code_raw'], 'label_zh': a['label_zh'], 'label_en': a['label_en']}
                          for a in con.execute('SELECT t.* FROM scu_syllabus_tags a JOIN scu_tags t USING(tag_id) WHERE a.syllabus_revision_id=? ORDER BY t.scheme,t.label_zh', (revision_id,))]
        result['abilities'] = [{'code': a['code_raw'], 'label_zh': a['label_zh'], 'alignment_state': a['alignment_state'], 'evaluation_methods': a['evaluation_methods_raw']}
                               for a in con.execute('SELECT t.code_raw,t.label_zh,a.* FROM scu_ability_alignments a JOIN scu_tags t USING(tag_id) WHERE a.syllabus_revision_id=? ORDER BY t.code_raw', (revision_id,))]
        result['prerequisites'] = [{'text': a['raw_text'], 'rule_kind': a['rule_kind'], 'verification_state': a['verification_state']}
                                   for a in con.execute('SELECT * FROM scu_prerequisite_notes WHERE syllabus_revision_id=?', (revision_id,))]
        result['contacts'] = [{'name': a['name_raw'], 'office_hours': a['office_hours_raw'], 'office': a['office_raw'], 'public_contact': a['public_contact_raw']}
                              for a in con.execute('SELECT * FROM scu_contact_blocks WHERE syllabus_revision_id=?', (revision_id,))]
        return result

    def detail(self, con, offering_id):
        rows = self.items(con, offering_id=offering_id)
        if not rows:
            raise StoreError(404, 'PUBLIC_COURSE_NOT_FOUND', '找不到這筆公開課程。')
        item = rows[0]
        sources = []
        history = []
        for r in con.execute('''SELECT r.*,h.offering_revision_id AS current_id FROM scu_offering_revisions r
                                JOIN scu_offering_heads h USING(offering_id) WHERE r.offering_id=? ORDER BY r.capture_id''', (offering_id,)):
            current = r['offering_revision_id'] == r['current_id']
            source = self.source(con, r['capture_id'], '目前課表來源' if current else '其他查詢來源')
            sources.append(source)
            history.append({'revision_id': r['offering_revision_id'], 'source_id': source['source_id'], 'title': r['title_zh'],
                            'selection_number': r['selection_number'], 'credits': None if r['credits_hundredths'] is None else r['credits_hundredths']/100,
                            'is_current': current, 'observed_at': source['observed_at']})
        versions = []
        for sy in con.execute('''SELECT sy.* FROM scu_syllabus_revisions sy JOIN scu_offering_revisions r USING(offering_revision_id)
                                 WHERE r.offering_id=? ORDER BY sy.capture_id''', (offering_id,)):
            full = con.execute('SELECT 1 FROM scu_syllabus_sections WHERE syllabus_revision_id=? LIMIT 1', (sy['syllabus_revision_id'],)).fetchone() is not None
            sources.append(self.source(con, sy['capture_id'], '完整授課計畫' if full else '行動版基本資料'))
            versions.append({'revision_id': sy['syllabus_revision_id'], 'source_id': sources[-1]['source_id'],
                             'is_current': sy['syllabus_revision_id'] == item['syllabus_revision_id'], 'content_edited_at': sy['content_edited_at'],
                             'precision': sy['edited_time_precision'], 'completeness': 'complete' if full else 'basic_only'})
        # Repeated observations can reuse an immutable content revision. Their
        # lineage still records every capture, even when no new version is made.
        observed_ids = {s['capture_id'] for s in sources if s}
        observed_ids.update(r[0] for r in con.execute('''SELECT DISTINCT l.capture_id FROM scu_field_lineage l
            WHERE (l.entity_name='offering_revision' AND l.entity_key IN
                   (SELECT offering_revision_id FROM scu_offering_revisions WHERE offering_id=?))
               OR (l.entity_name='syllabus_revision' AND l.entity_key IN
                   (SELECT sy.syllabus_revision_id FROM scu_syllabus_revisions sy
                    JOIN scu_offering_revisions r USING(offering_revision_id) WHERE r.offering_id=?))''',
            (offering_id, offering_id)))
        observations = [self.source(con, cid, '公開擷取紀錄') for cid in observed_ids]
        observations = sorted((s for s in observations if s), key=lambda s: (s['observed_at'], s['capture_id']), reverse=True)
        unique_sources = list({s['capture_id']: s for s in sources if s}.values())
        if item['reference_context']['state']=='document_mapped':
            unique_sources.append(item['reference_context']['source'])
        return {'item': item, 'syllabus': self.syllabus(con, item['syllabus_revision_id']) if item['syllabus_revision_id'] else None,
                'sources': unique_sources, 'source_history': history, 'syllabus_versions': versions,
                'observations': observations}
