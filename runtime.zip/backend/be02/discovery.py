"""Course browsing metadata and conservative, plan-bound rule checks. No AI calls."""
from copy import deepcopy
import json
from pathlib import Path

from . import evaluation as ev
from .errors import StoreError
from .store import canonical, digest, now
from .validation import semantic_error

MOCK_PATH = Path(__file__).resolve().parents[2] / "contracts" / "course-explorer" / "mock.json"


def seed_discovery(repo):
    if repo.mode != "synthetic":
        return
    value = json.loads(MOCK_PATH.read_text(encoding="utf-8"))
    repo.validation.validate("DiscoveryMetadata", value)
    with repo.atomic(write=True) as con:
        catalog = con.execute("SELECT 1 FROM be02_catalog_versions WHERE version=?", (value["catalog_version"],)).fetchone()
        if not catalog:
            return
        existing = con.execute("SELECT sha256 FROM be02_discovery_versions WHERE version=?", (value["version"],)).fetchone()
        if existing:
            if existing[0] != digest(value):
                raise StoreError(409, "DISCOVERY_VERSION_CONFLICT", "課程介紹已有同名版本，請建立新版本")
            return
        con.execute("INSERT INTO be02_discovery_versions VALUES (?,?,?,?,?)", (value["version"], value["catalog_version"], canonical(value), digest(value), now()))


def metadata(con, catalog_version):
    row = con.execute("SELECT payload FROM be02_discovery_versions WHERE catalog_version=? ORDER BY created_at DESC,version DESC LIMIT 1", (catalog_version,)).fetchone()
    return json.loads(row[0]) if row else {"version": None, "synthetic": False, "notice": "部分課程介紹與教師資料尚未提供。", "units": [], "departments": [], "courses": {}, "offering_overrides": {}, "teachers": []}


def organization(course, offering):
    year = course.get("year_level")
    digits = {0: "", 1: "一", 2: "二", 3: "三", 4: "四", 5: "五", 6: "六", 7: "七", 8: "八"}
    group = course.get("class_prefix", "") + digits.get(year, "") + offering["section_name"]
    return {"unit_id": course.get("unit_id"), "department_id": course.get("department_id"), "year_level": year, "class_group": group}


def build_items(profile, academic, catalog, rules, plan, teaching):
    courses = {c["course_id"]: c for c in catalog["courses"]}
    offerings = {o["offering_id"]: o for o in catalog["offerings"]}
    selected = {s["offering_id"] for s in plan["selections"]}
    scheduled = [offerings[s["offering_id"]] for s in plan["selections"] if s["placement"] == "scheduled"]
    items = []
    for offering in catalog["offerings"]:
        course = courses[offering["course_id"]]
        info = teaching["courses"].get(course["course_id"], {})
        teachers = teaching["offering_overrides"].get(offering["offering_id"], {}).get("teacher_ids", info.get("teacher_ids", []))
        tentative = [o for o in scheduled if o["offering_id"] != offering["offering_id"]] + [offering]
        eligibility = ev.eligibility(course, profile, academic, rules)
        schedule = ev.schedule(tentative, plan["preferences"], rules)
        ids = [o["course_id"] for o in tentative]
        if len(ids) != len(set(ids)):
            schedule = ev.evaluation(schedule["checks"] + [ev.check(rules, "schedule", "fail", "你已選了同一科目的其他班別，請先移除原班別再調整。", "INVALID_VALUE")])
        credits = [courses[o["course_id"]]["credits"] for o in tentative]
        if any(c is None for c in credits):
            credit_load = ev.evaluation([ev.check(rules, "schedule", "needs_review", "部分課程學分尚未提供，需確認學分負擔。", "RECORD_COVERAGE_INCOMPLETE")])
        else:
            total = sum(map(ev.number, credits))
            limits = [n for n in [rules["max_term_credits"], plan["preferences"]["max_credits"]] if n is not None]
            over = bool(limits) and total > min(map(ev.number, limits))
            credit_load = ev.evaluation([ev.check(rules, "schedule", "fail" if over else "pass", "加入後超過本學期學分上限。" if over else "加入後未超過本學期學分上限。", "TERM_CREDIT_LIMIT" if over else None)])
        items.append({"course": deepcopy(course), "offering": deepcopy(offering), "organization": organization(info, offering), "teacher_ids": list(teachers),
                      "syllabus": deepcopy(info.get("syllabus")), "selected": offering["offering_id"] in selected, "eligibility": eligibility, "schedule": schedule, "credit_load": credit_load,
                      "fit": ev.evaluation(eligibility["checks"] + schedule["checks"] + credit_load["checks"]), "soft_mismatches": ev.soft_mismatches(offering, plan["preferences"])})
    return items


def parse_filters(query):
    allowed = {"plan_id", "plan_revision", "q", "kind", "unit", "department", "year_level", "class_group", "campus", "eligibility", "schedule", "fit", "weekday", "start_minute", "end_minute", "direction_only"}
    if set(query) - allowed or any(len(v) != 1 for v in query.values()):
        semantic_error("搜尋條件不正確，請重新選擇")
    result = {k: v[0] for k, v in query.items() if k in allowed}
    if len(result.get("q", "")) > 160:
        semantic_error("搜尋文字請控制在 160 字以內")
    for name in ("eligibility", "schedule", "fit"):
        if result.get(name, "") not in ("", "pass", "fail", "needs_review"):
            semantic_error("請選擇有效的修課條件")
    if result.get("kind", "") not in ("", "department", "general", "language", "physical", "other") or result.get("campus", "") not in ("", "CITY", "SHUANGXI") or result.get("direction_only", "0") not in ("0", "1"):
        semantic_error("請選擇有效的課程類別或校區")
    for name, low, high in (("plan_revision", 1, 10000000), ("year_level", 0, 8), ("weekday", 1, 7), ("start_minute", 0, 1439), ("end_minute", 1, 1440)):
        if name in result:
            try:
                number = int(result[name])
                if str(number) != result[name] or not low <= number <= high:
                    raise ValueError
                result[name] = number
            except (ValueError, TypeError):
                semantic_error("年級、星期或時間格式不正確")
    window = {"weekday", "start_minute", "end_minute"} & result.keys()
    if window and (len(window) != 3 or result["start_minute"] >= result["end_minute"]):
        semantic_error("請填妥星期與起訖時間，結束時間必須晚於開始時間")
    return result


def filter_items(items, teaching, filters, direction_ids=None):
    units = {u["unit_id"]: u for u in teaching["units"]}
    departments = {d["department_id"]: d for d in teaching["departments"]}
    teachers = {t["instructor_id"]: t for t in teaching["teachers"]}
    answer = []
    for item in items:
        group = item["organization"]
        unit = units.get(group["unit_id"], {})
        if any(filters.get(key) and filters[key] != value for key, value in (("kind", unit.get("kind")), ("unit", group["unit_id"]), ("department", group["department_id"]), ("class_group", group["class_group"]))):
            continue
        if "year_level" in filters and filters["year_level"] != group["year_level"]:
            continue
        if any(filters.get(key) and item[key]["status"] != filters[key] for key in ("eligibility", "schedule", "fit")):
            continue
        if filters.get("direction_only") == "1" and item["course"]["course_id"] not in (direction_ids or set()):
            continue
        meetings = item["offering"]["meetings"]
        if filters.get("campus") and (not meetings or any(m["modality"] == "onsite" and m["campus_id"] != filters["campus"] for m in meetings) or not any(m["modality"] == "onsite" for m in meetings)):
            continue
        if "weekday" in filters and not any(m["weekday"] == filters["weekday"] and m["start_minute"] >= filters["start_minute"] and m["end_minute"] <= filters["end_minute"] for m in meetings or []):
            continue
        haystack = " ".join([item["course"]["name"], group["class_group"], unit.get("name", ""), departments.get(group["department_id"], {}).get("name", ""), (item["syllabus"] or {}).get("description", "")] + [text for tid in item["teacher_ids"] for text in [teachers.get(tid, {}).get("name", ""), *teachers.get(tid, {}).get("research_areas", [])]])
        if filters.get("q", "").strip().casefold() not in haystack.casefold():
            continue
        answer.append(item)
    order = {"pass": 0, "needs_review": 1, "fail": 2}
    return sorted(answer, key=lambda i: (order[i["fit"]["status"]], sum(m["minutes"] for m in i["soft_mismatches"]), i["course"]["name"], i["offering"]["section_name"]))


def discover(con, plan, inputs, query, direction_ids=None):
    filters = parse_filters(query)
    if filters.get("plan_revision", plan["revision"]) != plan["revision"]:
        raise StoreError(409, "REVISION_CONFLICT", "課表已更新，請重新查詢", current_revision=plan["revision"])
    profile, academic, catalog, rules = inputs
    teaching = metadata(con, catalog["version"])
    items = build_items(profile, academic, catalog, rules, plan, teaching)
    groups = {canonical(item["organization"]): item["organization"] for item in items}
    results = filter_items(items, teaching, filters, direction_ids)
    return {"metadata_version": teaching["version"], "synthetic": teaching["synthetic"], "notice": teaching["notice"], "plan_id": plan["plan_id"], "plan_revision": plan["revision"],
            "units": teaching["units"], "departments": teaching["departments"], "class_groups": list(groups.values()), "teachers": teaching["teachers"],
            "items": results, "total_offerings": len(items), "matched_offerings": len(results)}
