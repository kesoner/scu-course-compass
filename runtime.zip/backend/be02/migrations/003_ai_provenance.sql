CREATE TABLE be02_ai_generations (
  student_id TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('intent','direction')),
  artifact_id TEXT NOT NULL, revision INTEGER NOT NULL, generation_id TEXT NOT NULL,
  metadata TEXT NOT NULL CHECK(json_valid(metadata)), created_at TEXT NOT NULL,
  PRIMARY KEY(student_id,kind,artifact_id,revision),
  FOREIGN KEY(student_id,kind,artifact_id,revision) REFERENCES be02_artifact_versions(student_id,kind,artifact_id,revision)
);
CREATE INDEX be02_ai_generation_group ON be02_ai_generations(student_id,generation_id);
CREATE TRIGGER be02_ai_generation_no_update BEFORE UPDATE ON be02_ai_generations BEGIN SELECT RAISE(ABORT,'immutable history'); END;
CREATE TRIGGER be02_ai_generation_no_delete BEFORE DELETE ON be02_ai_generations BEGIN SELECT RAISE(ABORT,'immutable history'); END;
