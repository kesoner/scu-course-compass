"""Conservative schedule comparison. Missing public evidence never becomes a pass."""
from copy import deepcopy

ENGINE_VERSION = 'public-schedule-1'


def same_offering(a, b):
    return a['offering_id'] == b['offering_id'] or bool(a.get('selection_number') and
        (a.get('term_id'), a.get('course_code'), a['selection_number']) ==
        (b.get('term_id'), b.get('course_code'), b.get('selection_number')))


def result(checks):
    statuses = {c['status'] for c in checks}
    return {'status': 'fail' if 'fail' in statuses else 'needs_review' if 'needs_review' in statuses else 'pass', 'checks': checks}


def check(code, status, message, peer=None):
    return {'code': code, 'status': status, 'message': message, 'related_offering_id': peer}


def intervals(meeting):
    # A public multi-period class can have a lunch break or other gap. Never
    # stretch its min/max envelope into one continuous meeting.
    sessions = meeting.get('sessions')
    if sessions is None:
        # Only the internal demo uses a single resolved minute interval.
        sessions = [meeting] if meeting.get('_demo') else []
    known, unknown = [], not bool(sessions)
    for session in sessions:
        start, end = session.get('start_minute'), session.get('end_minute')
        if (meeting.get('_demo') or session.get('resolution_state') == 'resolved') and type(start) is int and type(end) is int and 0 <= start < end <= 1440:
            known.append((start, end))
        else:
            unknown = True
    return known, unknown


def weeks(meeting):
    value = meeting.get('teaching_weeks')
    return set(value) if isinstance(value, list) and value and all(type(n) is int and 1 <= n <= 60 for n in value) else None


def week_relation(a, b):
    aw, bw = weeks(a), weeks(b)
    ak, bk = a.get('week_pattern_kind'), b.get('week_pattern_kind')
    if aw is not None and bw is not None:
        return 'overlap' if aw & bw else 'disjoint'
    if aw is not None and bk in ('odd', 'even', 'all'):
        return 'overlap' if any(bk == 'all' or n % 2 == (1 if bk == 'odd' else 0) for n in aw) else 'disjoint'
    if bw is not None and ak in ('odd', 'even', 'all'):
        return week_relation(b, a)
    if ak in ('odd', 'even', 'all') and bk in ('odd', 'even', 'all'):
        return 'disjoint' if {ak, bk} == {'odd', 'even'} else 'overlap'
    return 'unknown'


def known_weeks(meeting):
    return weeks(meeting) is not None or meeting.get('week_pattern_kind') in ('all', 'odd', 'even')


def clock_overlap(a, b):
    return max(a[0], b[0]) < min(a[1], b[1])


def evaluate(item, preferences, peers=(), window=None, campus_filter=None, travel_gap=60, forbid_back_to_back=True):
    meetings = item.get('meetings') or []
    checks, soft = [], []
    if not meetings:
        checks.append(check('MEETINGS_UNKNOWN', 'needs_review', '缺少上課安排，尚無法比對時間。'))
    for peer in peers:
        if not same_offering(item, peer) and (not peer.get('meetings') or any(m.get('weekday') is None for m in peer['meetings'])):
            checks.append(check('PEER_TIME_UNKNOWN', 'needs_review', '部分已選或已存課程缺少上課安排，無法排除衝堂。', peer['offering_id']))
    for index, meeting in enumerate(meetings):
        label = f'第{index+1}段上課安排'
        day = meeting.get('weekday')
        spans, unknown_time = intervals(meeting)
        if type(day) is not int or not 1 <= day <= 7:
            checks.append(check('WEEKDAY_UNKNOWN', 'needs_review', label+'的上課星期待確認。'))
        if unknown_time:
            checks.append(check('MEETINGS_UNKNOWN', 'needs_review', label+'缺少完整節次鐘點，無法確認空堂或時間偏好。'))
        if not known_weeks(meeting):
            checks.append(check('WEEKS_UNKNOWN', 'needs_review', label+'的上課週次待確認。'))
        if meeting.get('campus_id') not in ('CITY', 'SHUANGXI') and meeting.get('modality') != 'online':
            checks.append(check('CAMPUS_UNKNOWN', 'needs_review', label+'的校區待確認，不以教室代碼猜測。'))
        for block in preferences['time_blocks']:
            if day != block['weekday']:
                continue
            minutes = sum(max(0, min(end, block['end_minute']) - max(start, block['start_minute'])) for start, end in merged(spans))
            if minutes and block['kind'] == 'unavailable':
                checks.append(check('UNAVAILABLE_TIME', 'fail', label+'落在你標記的不方便上課時間。'))
            elif minutes and block['kind'] == 'prefer_free':
                soft.append({'code': 'PREFER_FREE', 'minutes': minutes, 'message': '會使用你希望留空的時間。'})
        for block in preferences['campus_blocks']:
            if day != block['weekday']:
                continue
            minutes = sum(max(0, min(end, block['end_minute']) - max(start, block['start_minute'])) for start, end in merged(spans))
            if minutes and meeting.get('campus_id') in ('CITY', 'SHUANGXI') and meeting['campus_id'] != block['campus_id']:
                soft.append({'code': 'CAMPUS_PREFERENCE_MISMATCH', 'minutes': minutes, 'message': '與這段時間希望的校區不同，仍可自行考慮。'})
        for peer in peers:
            if same_offering(item, peer):
                continue
            for other in peer.get('meetings') or []:
                if day is None or day != other.get('weekday'):
                    continue
                relation = week_relation(meeting, other)
                if relation == 'disjoint':
                    continue
                other_spans, other_unknown = intervals(other)
                severity = 'fail' if relation == 'overlap' else 'needs_review'
                name = peer.get('title') or peer['offering_id']
                if other_unknown:
                    checks.append(check('PEER_TIME_UNKNOWN', 'needs_review', f'「{name}」的節次鐘點未完整，尚無法排除衝突。', peer['offering_id']))
                if any(clock_overlap(a, b) for a in spans for b in other_spans):
                    checks.append(check('TIME_OVERLAP', severity, f'與「{name}」有時間重疊'+('，上課週次仍待確認。' if severity == 'needs_review' else '。'), peer['offering_id']))
                elif (unknown_time or other_unknown) and set(meeting.get('session_codes') or []) & set(other.get('session_codes') or []):
                    checks.append(check('RAW_SESSION_OVERLAP', 'needs_review', f'與「{name}」有相同星期及節次代碼，需核對鐘點與週次。', peer['offering_id']))
                if meeting.get('campus_id') in ('CITY', 'SHUANGXI') and other.get('campus_id') in ('CITY', 'SHUANGXI') and meeting['campus_id'] != other['campus_id']:
                    if any(not clock_overlap(a, b) and ((max(a[0], b[0])-min(a[1], b[1]) == 0 and forbid_back_to_back) or max(a[0], b[0])-min(a[1], b[1]) < travel_gap) for a in spans for b in other_spans):
                        checks.append(check('TRAVEL_GAP_TOO_SHORT', severity, f'與「{name}」之間不足你目前規劃採用的{travel_gap}分鐘跨校區緩衝。', peer['offering_id']))
                elif (meeting.get('modality') != 'online' and other.get('modality') != 'online' and
                      (meeting.get('campus_id') not in ('CITY', 'SHUANGXI') or other.get('campus_id') not in ('CITY', 'SHUANGXI')) and
                      any(not clock_overlap(a, b) and max(a[0], b[0])-min(a[1], b[1]) <= travel_gap for a in spans for b in other_spans)):
                    checks.append(check('CAMPUS_UNKNOWN', 'needs_review', f'與「{name}」前後堂的校區未完整，交通緩衝待確認。', peer['offering_id']))
    if not checks:
        checks.append(check('KNOWN_SCHEDULE_CHECKED', 'pass', '已知上課安排與目前時間標記、已選課程沒有發現衝突。'))
    target_checks = []
    if window:
        statuses = []
        for meeting in meetings:
            if meeting.get('weekday') is None:
                statuses.append('needs_review')
            elif meeting['weekday'] == window['weekday']:
                spans, unknown = intervals(meeting)
                outside = any(start < window['start_minute'] or end > window['end_minute'] for start, end in spans)
                statuses.append('fail' if outside else 'needs_review' if unknown else 'pass')
        status = 'pass' if 'pass' in statuses else 'needs_review' if 'needs_review' in statuses or not meetings else 'fail'
        target_checks.append(check('TARGET_WINDOW', status, {'pass':'有一段完整上課安排位於指定空堂內，其他上課安排也會另外比對。', 'fail':'沒有完整上課安排位於指定空堂內。', 'needs_review':'尚缺完整鐘點或星期，無法確認是否能放進這段空堂。'}[status]))
    if campus_filter:
        status = 'pass'
        for meeting in meetings:
            actual = meeting.get('campus_id')
            if actual in ('CITY', 'SHUANGXI') and actual != campus_filter:
                status = 'fail'; break
            if actual not in ('CITY', 'SHUANGXI'):
                status = 'needs_review'
        if not meetings:
            status = 'needs_review'
        target_checks.append(check('STRICT_CAMPUS', status, {'pass':'全部已知上課安排符合指定校區。', 'fail':'至少一段上課安排不在指定校區。', 'needs_review':'校區資料不足，尚無法確認符合指定校區。'}[status]))
    return {'engine_version': ENGINE_VERSION, 'schedule': result(checks), 'target': result(target_checks),
            'fit': result(checks+target_checks), 'soft_mismatches': soft,
            'eligibility': 'needs_review', 'recognition': 'needs_review'}


def merged(spans):
    output = []
    for start, end in sorted(spans):
        if output and start <= output[-1][1]:
            output[-1] = (output[-1][0], max(end, output[-1][1]))
        else:
            output.append((start, end))
    return output


def peers_from_snapshot(snapshot, entries):
    selected = {s['offering_id'] for s in snapshot['plan']['selections'] if s['placement'] == 'scheduled'}
    courses = {c['course_id']: c for c in snapshot['catalog']['courses']}
    peers = []
    for offering in snapshot['catalog']['offerings']:
        if offering['offering_id'] not in selected:
            continue
        peers.append({'offering_id': offering['offering_id'], 'title': courses[offering['course_id']]['name'],
                      'meetings': [{**deepcopy(m), '_demo': True} for m in offering['meetings'] or []]})
    peers.extend(deepcopy(entry['detail']['item']) for entry in entries)
    return peers


def saved_fits(snapshot, entries):
    peers = peers_from_snapshot(snapshot, entries)
    policy = snapshot['rule_set']['cross_campus_policy']
    return {e['detail']['item']['offering_id']: evaluate(e['detail']['item'], snapshot['plan']['preferences'], peers, travel_gap=policy['minimum_gap_minutes'], forbid_back_to_back=policy['forbid_back_to_back']) for e in entries}
