-- Supplemental public teaching information; never changes academic decisions.
CREATE TABLE be02_discovery_versions (
  version TEXT PRIMARY KEY,
  catalog_version TEXT NOT NULL REFERENCES be02_catalog_versions(version),
  payload TEXT NOT NULL CHECK(json_valid(payload)),
  sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX be02_discovery_catalog ON be02_discovery_versions(catalog_version,created_at);
CREATE TRIGGER be02_discovery_no_update BEFORE UPDATE ON be02_discovery_versions BEGIN SELECT RAISE(ABORT,'immutable discovery history'); END;
CREATE TRIGGER be02_discovery_no_delete BEFORE DELETE ON be02_discovery_versions BEGIN SELECT RAISE(ABORT,'immutable discovery history'); END;
