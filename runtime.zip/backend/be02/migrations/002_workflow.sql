CREATE TABLE be02_artifact_contexts (
  student_id TEXT NOT NULL, kind TEXT NOT NULL, artifact_id TEXT NOT NULL, revision INTEGER NOT NULL,
  snapshot_id TEXT NOT NULL, data_versions TEXT NOT NULL CHECK(json_valid(data_versions)),
  PRIMARY KEY(student_id,kind,artifact_id,revision),
  FOREIGN KEY(student_id,kind,artifact_id,revision) REFERENCES be02_artifact_versions(student_id,kind,artifact_id,revision),
  FOREIGN KEY(snapshot_id,student_id) REFERENCES be02_snapshots(snapshot_id,student_id)
);
CREATE TABLE be02_import_previews (
  import_id TEXT PRIMARY KEY, student_id TEXT NOT NULL REFERENCES be02_principals(subject),
  records_revision INTEGER NOT NULL, request_payload TEXT NOT NULL CHECK(json_valid(request_payload)),
  preview_payload TEXT NOT NULL CHECK(json_valid(preview_payload)), created_at TEXT NOT NULL
);
CREATE TABLE be02_export_content (
  export_id TEXT PRIMARY KEY, student_id TEXT NOT NULL, content BLOB NOT NULL, sha256 TEXT NOT NULL,
  mime_type TEXT NOT NULL, file_name TEXT NOT NULL,
  FOREIGN KEY(student_id) REFERENCES be02_principals(subject)
);
CREATE TABLE be02_request_results (
  student_id TEXT NOT NULL REFERENCES be02_principals(subject), request_key TEXT NOT NULL,
  fingerprint TEXT NOT NULL, status INTEGER NOT NULL, response TEXT NOT NULL CHECK(json_valid(response)),
  PRIMARY KEY(student_id,request_key)
);
CREATE TRIGGER be02_context_no_update BEFORE UPDATE ON be02_artifact_contexts BEGIN SELECT RAISE(ABORT,'immutable history'); END;
CREATE TRIGGER be02_context_no_delete BEFORE DELETE ON be02_artifact_contexts BEGIN SELECT RAISE(ABORT,'immutable history'); END;
CREATE TRIGGER be02_preview_no_update BEFORE UPDATE ON be02_import_previews BEGIN SELECT RAISE(ABORT,'immutable history'); END;
CREATE TRIGGER be02_preview_no_delete BEFORE DELETE ON be02_import_previews BEGIN SELECT RAISE(ABORT,'immutable history'); END;
CREATE TRIGGER be02_export_content_no_update BEFORE UPDATE ON be02_export_content BEGIN SELECT RAISE(ABORT,'immutable history'); END;
CREATE TRIGGER be02_export_content_no_delete BEFORE DELETE ON be02_export_content BEGIN SELECT RAISE(ABORT,'immutable history'); END;
CREATE TRIGGER be02_request_result_no_update BEFORE UPDATE ON be02_request_results BEGIN SELECT RAISE(ABORT,'immutable history'); END;
CREATE TRIGGER be02_request_result_no_delete BEFORE DELETE ON be02_request_results BEGIN SELECT RAISE(ABORT,'immutable history'); END;
