"""Loopback four-stage API, backed by BE-02 and isolated from the old demo."""
from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy
import csv
import hashlib
import io
import json
import re
import uuid
from urllib.parse import parse_qs, unquote, urlparse

from .auth import MockAuthenticator
from .errors import StoreError
from .store import Repository, canonical, digest, missing, now
from .validation import semantic_error, validate_intervals
from . import evaluation as ev
from .career_ai import CareerAI
from .discovery import seed_discovery, discover
from . import public_planning
from . import public_options, public_schedule, public_trials
from . import graduation_progress
from .discovery import metadata as discovery_metadata


class WorkflowRepository(Repository):
    """Nested repository calls share the request's transaction, per request thread."""
    def __init__(self, path):
        self._request_connection = ContextVar("be02-connection-" + uuid.uuid4().hex, default=None)
        self._public_selection_override = ContextVar("be02-public-" + uuid.uuid4().hex, default=None)
        super().__init__(path)

    @contextmanager
    def _session(self, **kwargs):
        active = self._request_connection.get()
        if active is not None:
            yield active
        else:
            with super()._session(**kwargs) as con:
                yield con

    @contextmanager
    def atomic(self, write=False):
        with super()._session(write=write) as con:
            token = self._request_connection.set(con)
            try:
                yield con
            finally:
                self._request_connection.reset(token)

    def _snapshot(self, con, plan, extra=None):
        snapshot = super()._snapshot(con, plan, extra)
        provenance = {}
        for kind, value in (extra or {}).items():
            if kind not in ("intent", "direction"):
                continue
            aid = value["intent_id" if kind == "intent" else "direction_id"]
            row = con.execute("SELECT a.* FROM be02_ai_generations a JOIN be02_artifact_heads h ON h.student_id=a.student_id AND h.kind=a.kind AND h.artifact_id=a.artifact_id AND h.revision=a.revision WHERE a.student_id=? AND a.kind=? AND a.artifact_id=?", (plan["student_id"], kind, aid)).fetchone()
            if row:
                provenance[kind] = {"artifact_revision": row["revision"], "generation_id": row["generation_id"], "metadata": json.loads(row["metadata"])}
        snapshot["ai_provenance"] = provenance
        override = self._public_selection_override.get()
        if override is not None:
            snapshot["public_course_selections"] = deepcopy(override)
        elif plan["revision"] > 1:
            previous = con.execute("SELECT s.payload FROM be02_snapshots s WHERE s.student_id=? AND s.plan_id=? AND s.plan_revision=?", (plan["student_id"], plan["plan_id"], plan["revision"]-1)).fetchone()
            if previous:
                snapshot["public_course_selections"] = json.loads(previous[0]).get("public_course_selections", [])
        return snapshot


class FourStageAPI:
    def __init__(self, path, client=None, public_catalog=None):
        self.repo = WorkflowRepository(path)
        self.repo.seed_mock()
        seed_discovery(self.repo)
        if client is None:
            from mvp.gemini_client import GeminiClient
            client = GeminiClient()
        self.ai = CareerAI(client)
        if public_catalog is None:
            from backend.public_catalog import PublicCatalogAPI
            public_catalog = PublicCatalogAPI()
        self.public_catalog = public_catalog

    @staticmethod
    def meta(plan=None):
        return {"request_id": uuid.uuid4().hex, "generated_at": now(), "contract_version": "1.0.0-draft.1",
                "data_mode": "synthetic", "input_snapshot_id": plan["input_snapshot_id"] if plan else None,
                "plan_revision": plan["revision"] if plan else None,
                "data_versions": plan["data_versions"] if plan else {k: "unavailable" for k in ("profile", "records", "rules", "catalog", "preferences")}}

    def error_response(self, error):
        return {"meta": self.meta(), "error": error.as_error()}

    @staticmethod
    def revision(headers):
        match = re.fullmatch(r'"([1-9][0-9]*)"', headers.get("If-Match", ""))
        if not match:
            raise StoreError(428, "PRECONDITION_REQUIRED", '請提供 If-Match: "修訂號"')
        return int(match[1])

    def handle(self, method, target, body, headers):
        principal = MockAuthenticator(self.repo).authenticate(headers.get("Authorization", ""))
        path = unquote(urlparse(target).path.removeprefix("/api/v1"))
        query = parse_qs(urlparse(target).query)
        write = method in ("POST", "PATCH", "PUT")
        key = headers.get("Idempotency-Key")
        if key is not None and (not 1 <= len(key) <= 128):
            semantic_error("Idempotency-Key 長度必須介於1與128")
        if method == "POST" and path in ("/intent-analyses", "/direction-suggestions"):
            return self._ai_request(principal, target, path, body, headers, key)
        with self.repo.atomic(write=write) as con:
            self.repo._authorize(con, principal, None)
            if write:
                permission = "catalog:publish" if path == "/admin/catalog-versions" else "rules:publish" if path == "/admin/rule-set-versions" else "self:write"
                self.repo._authorize(con, principal, permission)
            requires_key = method == "POST" and (path == "/plans" or path.startswith("/admin/") or re.search(r"/(confirmations|exports|registration-reports)$", path) or path.startswith("/me/record-imports/") and path.endswith("/confirm"))
            if requires_key and not key:
                raise StoreError(400, "IDEMPOTENCY_KEY_REQUIRED", "此操作需要 Idempotency-Key 以安全重試")
            fingerprint = digest({"method": method, "target": target, "body": body, "if_match": headers.get("If-Match")})
            if write and key:
                cached = con.execute("SELECT * FROM be02_request_results WHERE student_id=? AND request_key=?", (principal.subject, key)).fetchone()
                if cached:
                    if cached["fingerprint"] != fingerprint:
                        raise StoreError(409, "IDEMPOTENCY_CONFLICT", "此重試識別碼已用於不同要求")
                    return cached["status"], json.loads(cached["response"])
            status, data, schema, plan = self.dispatch(con, principal, method, path, query, body, headers)
            if schema and schema != "__download__":
                self.repo.validation.validate(schema, data)
            if schema == "__download__":
                return status, data
            result = {"meta": self.meta(plan), "data": data}
            if write and key:
                con.execute("INSERT INTO be02_request_results VALUES (?,?,?,?,?)", (principal.subject, key, fingerprint, status, canonical(result)))
            return status, result

    def _cached_ai(self, con, p, key, fingerprint):
        if not key:
            return None
        row = con.execute("SELECT * FROM be02_request_results WHERE student_id=? AND request_key=?", (p.subject, key)).fetchone()
        if row:
            if row["fingerprint"] != fingerprint:
                raise StoreError(409, "IDEMPOTENCY_CONFLICT", "此重試識別碼已用於不同要求")
            return row["status"], json.loads(row["response"])
        return None

    def _save_ai_metadata(self, con, p, kind, aid, generation_id, metadata):
        head = con.execute("SELECT revision FROM be02_artifact_heads WHERE student_id=? AND kind=? AND artifact_id=?", (p.subject, kind, aid)).fetchone()
        con.execute("INSERT INTO be02_ai_generations VALUES (?,?,?,?,?,?,?)", (p.subject, kind, aid, head[0], generation_id, canonical(metadata), now()))

    def _ai_request(self, p, target, path, body, headers, key):
        task = "intent" if path == "/intent-analyses" else "directions"
        fingerprint = digest({"method": "POST", "target": target, "body": body, "if_match": headers.get("If-Match")})
        # A provider call can take two timeouts. Do not hold SQLite's writer
        # lock while waiting; authorize and bind exact inputs again at commit.
        with self.repo.atomic() as con:
            self.repo._authorize(con, p, "self:write")
            cached = self._cached_ai(con, p, key, fingerprint)
            if cached:
                return cached
            self.repo.validation.validate("IntentParse" if task == "intent" else "DirectionRequest", body)
            plan = self._plan(con, p, body["plan_id"], fresh=True)
            profile, academic, catalog, _ = self._inputs(con, p, plan)
            intent = None
            if task == "intent":
                text = body["text"].strip()
                if not text:
                    semantic_error("請輸入職涯目標或興趣")
                prepared = self.ai.prepare(task, profile=profile, academic=academic, catalog=catalog, student_text=text)
            else:
                intent = self._current_artifact(con, p, "intent", body["intent_id"], plan)
                if intent["confirmation"] != "confirmed":
                    raise StoreError(409, "INTENT_NOT_CONFIRMED", "請先確認意圖欄位")
                intent_revision = con.execute("SELECT revision FROM be02_artifact_heads WHERE student_id=? AND kind='intent' AND artifact_id=?", (p.subject, intent["intent_id"])).fetchone()[0]
                prepared = self.ai.prepare(task, profile=profile, academic=academic, catalog=catalog, fields=intent["fields"])
        generated = self.ai.generate(prepared)
        with self.repo.atomic(write=True) as con:
            self.repo._authorize(con, p, "self:write")
            cached = self._cached_ai(con, p, key, fingerprint)
            if cached:
                return cached
            current = self._plan(con, p, plan["plan_id"], fresh=True)
            self.repo._match(current["revision"], plan["revision"])
            if current["input_snapshot_id"] != plan["input_snapshot_id"] or current["data_versions"] != plan["data_versions"]:
                raise StoreError(409, "STALE_INPUTS", "AI 分析期間資料已有更新，請重新分析")
            if intent:
                self._current_artifact(con, p, "intent", intent["intent_id"], current)
                latest = con.execute("SELECT revision FROM be02_artifact_heads WHERE student_id=? AND kind='intent' AND artifact_id=?", (p.subject, intent["intent_id"])).fetchone()[0]
                if latest != intent_revision:
                    raise StoreError(409, "REVISION_CONFLICT", "AI 分析期間確認後的意圖已有更新，請重新產生方向", current_revision=latest)
            generation_id = "generation-" + uuid.uuid4().hex
            output, mode, metadata = generated["output"], generated["generation_mode"], generated["metadata"]
            if task == "intent":
                data = {"intent_id": "intent-"+uuid.uuid4().hex, "plan_id": plan["plan_id"], "text": text,
                        "fields": output["fields"], "confirmation": "unconfirmed", "questions": output["questions"], "generation_mode": mode}
                self._artifact(con, p, "intent", data, plan, "Intent")
                self._save_ai_metadata(con, p, "intent", data["intent_id"], generation_id, metadata)
                status, schema = 201, "Intent"
            else:
                metadata = {**metadata, "intent_id": intent["intent_id"], "intent_revision": intent_revision}
                profile, academic, catalog, rules = self._inputs(con, p, current)
                courses = {c["course_id"]: c for c in catalog["courses"]}
                options = []
                for item in output["options"]:
                    details = [{"course_id": cid, "evaluation": ev.eligibility(courses[cid], profile, academic, rules)} for cid in item["course_ids"]]
                    refs = {canonical(ref): ref for cid in item["course_ids"] for ref in courses[cid]["source_refs"]}
                    value = {**item, "direction_id": "direction-"+uuid.uuid4().hex,
                             "eligibility": ev.evaluation([c for detail in details for c in detail["evaluation"]["checks"]]),
                             "course_eligibility": details, "source_refs": list(refs.values())}
                    self._artifact(con, p, "direction", value, current, "Direction")
                    self._save_ai_metadata(con, p, "direction", value["direction_id"], generation_id, metadata)
                    con.execute("INSERT INTO be02_direction_links VALUES (?,?,?,?)", (p.subject, value["direction_id"], intent["intent_id"], plan["plan_id"]))
                    options.append(value)
                data = {"intent_id": intent["intent_id"], "options": options, "generation_mode": mode,
                        "limitations": output["limitations"] + ["方向是探索建議；資格、學分及衝堂依規則判定。", "非研究所錄取或律師資格保證。"]}
                status, schema = 200, "Directions"
            self.repo.validation.validate(schema, data)
            result = {"meta": self.meta(current), "data": data}
            if key:
                con.execute("INSERT INTO be02_request_results VALUES (?,?,?,?,?)", (p.subject, key, fingerprint, status, canonical(result)))
            return status, result

    def _plan(self, con, principal, plan_id, *, fresh=False):
        owner = self.repo._authorize(con, principal)
        plan = self.repo._plan(con, owner, plan_id)
        if fresh:
            heads = con.execute("SELECT * FROM be02_student_heads WHERE student_id=?", (owner,)).fetchone()
            catalog = con.execute("SELECT version FROM be02_catalog_heads WHERE term_id=?", (plan["term_id"],)).fetchone()
            rules = con.execute("SELECT h.version FROM be02_rule_heads h JOIN be02_rule_versions r ON r.rule_set_id=h.rule_set_id WHERE r.version=?", (plan["data_versions"]["rules"],)).fetchone()
            expected = {"profile": f"profile-v{heads['profile_revision']}", "records": f"records-v{heads['records_revision']}", "catalog": catalog[0] if catalog else None, "rules": rules[0] if rules else None}
            if any(plan["data_versions"][k] != v for k, v in expected.items()):
                raise StoreError(409, "STALE_INPUTS", "身分、修課或課規已有更新；請先儲存方案以採用最新資料", current_revision=plan["revision"])
        return plan

    def _inputs(self, con, principal, plan):
        snapshot = self.repo.get_snapshot(principal, plan["input_snapshot_id"])
        return snapshot["profile"], snapshot["academic"], snapshot["catalog"], snapshot["rule_set"]

    def _artifact(self, con, principal, kind, value, plan, schema, *, artifact_id=None):
        self.repo._authorize(con, principal, "self:write")
        self.repo.validation.validate(schema, value)
        id_key = {"intent": "intent_id", "direction": "direction_id", "validation": "validation_id", "confirmation": "confirmation_id", "export": "export_id", "registration": "report_id"}[kind]
        aid = artifact_id or value[id_key]
        head = con.execute("SELECT revision FROM be02_artifact_heads WHERE student_id=? AND kind=? AND artifact_id=?", (principal.subject, kind, aid)).fetchone()
        revision = head[0]+1 if head else 1
        con.execute("INSERT INTO be02_artifact_versions VALUES (?,?,?,?,?,?,?,?)", (principal.subject, kind, aid, revision, plan["plan_id"], canonical(value), digest(value), now()))
        con.execute("INSERT INTO be02_artifact_heads VALUES (?,?,?,?,1) ON CONFLICT(student_id,kind,artifact_id) DO UPDATE SET revision=excluded.revision,is_current=1", (principal.subject, kind, aid, revision))
        con.execute("INSERT INTO be02_artifact_contexts VALUES (?,?,?,?,?,?)", (principal.subject, kind, aid, revision, plan["input_snapshot_id"], canonical(plan["data_versions"])))
        self.repo._audit(con, principal.subject, kind, aid, revision, principal.subject, "workflow_saved", value)
        return value

    def _current_artifact(self, con, principal, kind, aid, plan):
        value = self.repo._artifact(con, principal.subject, kind, aid)
        row = con.execute("SELECT c.*,h.is_current FROM be02_artifact_contexts c JOIN be02_artifact_heads h ON h.student_id=c.student_id AND h.kind=c.kind AND h.artifact_id=c.artifact_id AND h.revision=c.revision WHERE c.student_id=? AND c.kind=? AND c.artifact_id=?", (principal.subject, kind, aid)).fetchone()
        matches = row and row["is_current"] and row["snapshot_id"] == plan["input_snapshot_id"] and json.loads(row["data_versions"]) == plan["data_versions"]
        if row and kind == "intent":
            versions = json.loads(row["data_versions"])
            matches = all(versions[k] == plan["data_versions"][k] for k in ("profile", "records", "catalog", "rules"))
        if not matches:
            raise StoreError(409, "STALE_ARTIFACT", "此成果屬於舊版輸入，請重新執行此步驟", current_revision=plan["revision"])
        if value.get("plan_id", plan["plan_id"]) != plan["plan_id"]:
            missing()
        return value

    def _context(self, con, p, plan):
        profile = self.repo.get_profile(p)
        academic = self.repo.get_academic_bundle(p)
        catalog = self.repo.get_catalog(p, plan["term_id"])
        rule_id = con.execute("SELECT rule_set_id FROM be02_rule_versions WHERE version=?", (plan["data_versions"]["rules"],)).fetchone()[0]
        rules = self.repo.get_rules(p, rule_id)
        programs = [self.repo._json(r) for r in con.execute("SELECT payload FROM be02_references WHERE kind='program' ORDER BY entity_id")]
        return {"profile": profile, "records": academic["records"], "record_coverage": academic["record_coverage"], "rule_set_id": rule_id,
                "available_programs": programs, "recognition_decisions": academic["recognition_decisions"], "non_credit_evidence": academic["non_credit_evidence"],
                "audit": ev.audit(profile, academic, catalog, rules, plan)}

    def dispatch(self, con, p, method, path, query, body, headers):
        repo = self.repo
        pdf_match = re.fullmatch(r"/plans/([^/]+)/pdf/(timetable|selection-check)", path)
        if method == "GET" and pdf_match:
            # Require an explicit version. Never combine today's catalog with an old plan.
            if set(query) != {'revision'} or len(query['revision']) != 1 or not re.fullmatch(r'[1-9][0-9]{0,8}',query['revision'][0]):
                semantic_error('下載 PDF 需要單一課表版本 revision')
            plan = repo.get_plan(p,pdf_match[1],revision=int(query['revision'][0]))
            snapshot = repo.get_snapshot(p,plan['input_snapshot_id'])
            from .plan_pdf import render as render_pdf
            content = render_pdf(plan,snapshot,pdf_match[2])
            return 200, {'bytes':content,'mime_type':'application/pdf','file_name':f'{pdf_match[2]}-r{plan["revision"]}.pdf'}, '__download__', plan
        options_match = re.fullmatch(r"/plans/([^/]+)/public-course-options", path)
        if options_match and method == "GET":
            return public_options.discover(self, con, p, options_match[1], query)
        public_match = re.fullmatch(r"/plans/([^/]+)/public-course-selections(/export)?", path)
        if public_match:
            return public_planning.dispatch(self, con, p, method, public_match[1], query, body, headers, export=bool(public_match[2]))
        if method == "GET" and path == "/course-explorer":
            if "plan_id" not in query or len(query["plan_id"]) != 1:
                semantic_error("請先選擇要使用的課表")
            plan = self._plan(con, p, query["plan_id"][0], fresh=True)
            direction_ids = None
            if query.get("direction_only") == ["1"]:
                if not plan["direction_id"]:
                    semantic_error("請先在探索方向選擇一個方向")
                # The chosen direction remains useful when only timetable choices change.
                # Course eligibility below is always re-evaluated against current inputs.
                direction = repo.get_artifact(p, "direction", plan["direction_id"])
                direction_ids = set(direction["course_ids"])
            data = discover(con, plan, self._inputs(con, p, plan), query, direction_ids)
            return 200, data, "CourseDiscovery", plan
        if method == "GET" and path in ("/me/workspace", "/me/context"):
            owner = repo._authorize(con, p)
            plans = [repo._plan(con, owner, r[0]) for r in con.execute("SELECT plan_id FROM be02_plan_heads WHERE student_id=? ORDER BY plan_id", (owner,))]
            if not plans:
                missing()
            requested = query.get("plan_id", [plans[0]["plan_id"]])[0]
            plan = self._plan(con, p, requested)
            context = self._context(con, p, plan)
            if path == "/me/context":
                return 200, context, "Context", plan
            catalog = repo.get_catalog(p, plan["term_id"])
            rules = repo.get_rules(p, context["rule_set_id"])
            artifact_rows = con.execute("SELECT v.*,h.is_current FROM be02_artifact_heads h JOIN be02_artifact_versions v ON v.student_id=h.student_id AND v.kind=h.kind AND v.artifact_id=h.artifact_id AND v.revision=h.revision WHERE h.student_id=? AND v.plan_id=? ORDER BY v.created_at,v.artifact_id", (owner, plan["plan_id"])).fetchall()
            artifacts = [{"kind": r["kind"], "revision": r["revision"], "is_current": bool(r["is_current"]), "value": repo._json(r)} for r in artifact_rows]
            for artifact in artifacts:
                provenance = con.execute("SELECT generation_id,metadata FROM be02_ai_generations WHERE student_id=? AND kind=? AND artifact_id=? AND revision=?", (owner, artifact["kind"], artifact["value"].get("intent_id") if artifact["kind"] == "intent" else artifact["value"].get("direction_id"), artifact["revision"])).fetchone()
                if provenance:
                    artifact["generation_id"] = provenance["generation_id"]
                    artifact["ai_metadata"] = json.loads(provenance["metadata"])
                if artifact["kind"] == "direction":
                    link = con.execute("SELECT intent_id FROM be02_direction_links WHERE student_id=? AND direction_id=?", (owner, artifact["value"]["direction_id"])).fetchone()
                    artifact["intent_id"] = link[0] if link else None
            data = {"context": context, "plan": plan, "plans": plans, "catalog": catalog, "rules": rules, "artifacts": artifacts, "ai": self.ai.status(),
                    "profile_history": repo.history(p, "profile"), "records_history": repo.history(p, "records"), "plan_history": repo.history(p, "plan", plan["plan_id"]),
                    "exploring_program_ids": json.loads(con.execute("SELECT exploring_program_ids FROM be02_student_heads WHERE student_id=?", (owner,)).fetchone()[0])}
            academic = repo.get_academic_bundle(p)
            by_course = {c["course_id"]: c for c in catalog["courses"]}
            data["eligibilities"] = {o["offering_id"]: ev.eligibility(by_course[o["course_id"]], context["profile"], academic, rules) for o in catalog["offerings"]}
            data["public_course_selections"] = public_planning.read(repo, p, plan)
            data["public_course_fit"] = public_schedule.saved_fits(repo.get_snapshot(p, plan["input_snapshot_id"]), data["public_course_selections"]["items"])
            data['public_trial_fit'] = public_trials.trial_fits(repo.get_snapshot(p, plan['input_snapshot_id']),data['public_course_selections']['items'])
            data['graduation_progress'] = graduation_progress.build(context,academic,catalog,rules,plan,discovery_metadata(con,catalog['version']),
                data['records_history'][-1]['created_at'] if data['records_history'] else None)
            return 200, data, None, plan
        if method == "PATCH" and path == "/me/profile":
            value = repo.update_profile(p, body, expected_revision=self.revision(headers))
            return 200, value, "Profile", None
        if method == "POST" and path == "/me/record-imports":
            repo._authorize(con, p, "self:write")
            repo.validation.validate("ImportRequest", body)
            academic = repo.get_academic_bundle(p)
            existing = {r["source_record_key"] for r in academic["records"]}
            seen, accepted, duplicates, invalid = set(), [], [], []
            for n, row in enumerate(body["rows"], 1):
                if row["source_record_key"] in existing or row["source_record_key"] in seen:
                    duplicates.append(n)
                elif not con.execute("SELECT 1 FROM be02_courses WHERE course_id=?", (row["course_id"],)).fetchone():
                    invalid.append(n)
                else:
                    accepted.append(n)
                seen.add(row["source_record_key"])
            value = {"import_id": "import-" + uuid.uuid4().hex, "state": "needs_review" if invalid else "ready", "accepted_row_numbers": accepted,
                     "duplicate_row_numbers": duplicates, "invalid_row_numbers": invalid, "trust": "student_report", "records_revision": academic["records_revision"]}
            con.execute("INSERT INTO be02_import_previews VALUES (?,?,?,?,?,?)", (value["import_id"], p.subject, academic["records_revision"], canonical(body), canonical(value), now()))
            return 201, value, "ImportPreview", None
        match = re.fullmatch(r"/me/record-imports/([^/]+)/confirm", path)
        if method == "POST" and match:
            repo._authorize(con, p, "self:write")
            repo.validation.validate("ImportConfirm", body)
            row = con.execute("SELECT * FROM be02_import_previews WHERE student_id=? AND import_id=?", (p.subject, match[1])).fetchone()
            if not row:
                missing()
            repo._match(row["records_revision"], self.revision(headers))
            preview, request = json.loads(row["preview_payload"]), json.loads(row["request_payload"])
            accepted = body["accepted_row_numbers"]
            if not accepted or not set(accepted) <= set(preview["accepted_row_numbers"]):
                semantic_error("只能確認預覽中可接受的列，且至少選擇一列")
            result = repo.append_self_reported_records(p, {"rows": [request["rows"][n-1] for n in accepted]}, expected_revision=row["records_revision"])
            result.update(import_id=match[1], invalidated_plan_ids=[r[0] for r in con.execute("SELECT plan_id FROM be02_plan_heads WHERE student_id=?", (p.subject,))])
            return 200, result, "ImportCommitted", None
        if method == "POST" and path == "/plans":
            repo._authorize(con, p, "self:write")
            repo.validation.validate("CreatePlan", body)
            template = con.execute("SELECT plan_id FROM be02_plan_heads WHERE student_id=? ORDER BY plan_id LIMIT 1", (p.subject,)).fetchone()
            if not template:
                missing()
            plan = self._plan(con, p, template[0])
            plan.update(deepcopy(body))
            heads = con.execute("SELECT * FROM be02_student_heads WHERE student_id=?", (p.subject,)).fetchone()
            cat = repo.get_catalog(p, body["term_id"])
            rule = con.execute("SELECT h.version FROM be02_rule_heads h JOIN be02_rule_versions r ON r.rule_set_id=h.rule_set_id WHERE r.version=?", (plan["data_versions"]["rules"],)).fetchone()
            plan.update(plan_id="plan-" + uuid.uuid4().hex, revision=1, input_snapshot_id="snap-"+uuid.uuid4().hex, confirmed_intent_id=None, direction_id=None, state="draft", validation_state="not_evaluated")
            plan["data_versions"].update(profile=f"profile-v{heads['profile_revision']}", records=f"records-v{heads['records_revision']}", catalog=cat["version"], rules=rule[0], preferences="preferences-"+uuid.uuid4().hex)
            repo._write_plan(con, plan, p.subject, "student_created")
            return 201, plan, "Plan", plan
        match = re.fullmatch(r"/plans/([^/]+)(?:/(history|validations|confirmations|exports|registration-reports))?", path)
        if match:
            plan_id, action = match.groups()
            plan = self._plan(con, p, plan_id, fresh=action in ("validations", "confirmations", "exports", "registration-reports") and method == "POST")
            if method == "GET" and not action:
                rev = query.get("revision", [None])[0]
                if rev is not None and not rev.isdigit():
                    semantic_error("修訂號格式錯誤")
                value = repo.get_plan(p, plan_id, revision=int(rev) if rev else None)
                return 200, value, "Plan", value
            if method == "GET" and action == "history":
                return 200, {"items": repo.history(p, "plan", plan_id)}, None, plan
            if method == "PATCH" and not action:
                direction_id = body.get("direction_id", plan["direction_id"])
                intent_id = body.get("confirmed_intent_id", plan["confirmed_intent_id"])
                if direction_id and intent_id:
                    provenance = con.execute("SELECT a.metadata FROM be02_ai_generations a JOIN be02_artifact_heads h ON h.student_id=a.student_id AND h.kind=a.kind AND h.artifact_id=a.artifact_id AND h.revision=a.revision WHERE a.student_id=? AND a.kind='direction' AND a.artifact_id=?", (p.subject, direction_id)).fetchone()
                    head = con.execute("SELECT revision FROM be02_artifact_heads WHERE student_id=? AND kind='intent' AND artifact_id=?", (p.subject, intent_id)).fetchone()
                    if provenance and head:
                        source = json.loads(provenance[0])
                        if source.get("intent_id") != intent_id or source.get("intent_revision") != head[0]:
                            raise StoreError(409, "STALE_DIRECTION", "意圖欄位已有修改，請重新產生並選擇職涯方向")
                value = repo.update_plan(p, plan_id, body, expected_revision=self.revision(headers))
                return 200, value, "Plan", value
            if method == "POST" and action:
                repo._authorize(con, p, "self:write")
                repo._match(plan["revision"], self.revision(headers))
                schemas = {"validations": "ValidateRequest", "confirmations": "ConfirmRequest", "exports": "ExportRequest", "registration-reports": "RegistrationRequest"}
                repo.validation.validate(schemas[action], body)
                repo._match(plan["revision"], body["plan_revision"])
                if action == "validations":
                    inputs = self._inputs(con, p, plan)
                    selections = public_planning.read(repo, p, plan)
                    fits = public_schedule.saved_fits(repo.get_snapshot(p, plan["input_snapshot_id"]), selections["items"])
                    value = ev.validate_plan(*inputs, plan)
                    public_planning.extend_validation(value, selections, inputs[3], fits, public_trials.trial_fits(repo.get_snapshot(p,plan['input_snapshot_id']),selections['items']))
                    self._artifact(con, p, "validation", value, plan, "Validation")
                    con.execute("UPDATE be02_plan_heads SET validation_state='current' WHERE student_id=? AND plan_id=?", (p.subject, plan_id))
                    return 201, value, "Validation", plan
                if action == "confirmations":
                    validation = self._current_artifact(con, p, "validation", body["validation_id"], plan)
                    if not validation["can_confirm_preselection"]:
                        raise StoreError(409, "PLAN_NOT_CONFIRMABLE", "資格或時間仍未通過，請先調整課表")
                    pending = [c["check_id"] for c in validation["recognition"]["checks"] if c["status"] != "pass"]
                    if not set(pending) <= set(body["acknowledged_check_ids"]):
                        raise StoreError(409, "ACKNOWLEDGEMENT_REQUIRED", "請先確認待核對事項")
                    value = {"confirmation_id": "confirmation-"+uuid.uuid4().hex, "plan_id": plan_id, "plan_revision": plan["revision"], "validation_id": body["validation_id"], "scope": "preselection_only", "pending_check_ids": pending, "official_registration": False}
                    self._artifact(con, p, "confirmation", value, plan, "Confirmation")
                    con.execute("UPDATE be02_plan_heads SET state='confirmed' WHERE student_id=? AND plan_id=?", (p.subject, plan_id))
                    return 201, value, "Confirmation", plan
                if action == "exports":
                    confirmation = self._current_artifact(con, p, "confirmation", body["confirmation_id"], plan)
                    if body["format"] != "csv" or body["content"] != "courses":
                        raise StoreError(422, "UNSUPPORTED_EXPORT", "本機首版提供課程 CSV 匯出")
                    content = self._csv(con, p, plan)
                    eid = "export-"+uuid.uuid4().hex
                    value = {"export_id": eid, "plan_id": plan_id, "plan_revision": plan["revision"], "confirmation_id": confirmation["confirmation_id"], "format": "csv", "content": "courses", "download_url": "/api/v1/exports/"+eid+"/download", "sha256": hashlib.sha256(content).hexdigest(), "state": "ready", "official_registration": False}
                    self._artifact(con, p, "export", value, plan, "Export")
                    con.execute("INSERT INTO be02_export_content VALUES (?,?,?,?,?,?)", (eid, p.subject, content, value["sha256"], "text/csv; charset=utf-8", eid+".csv"))
                    return 201, value, "Export", plan
                if action == "registration-reports":
                    repo._unique(body["items"], "offering_id")
                    selected = {s["offering_id"] for s in plan["selections"]}
                    if not {i["offering_id"] for i in body["items"]} <= selected:
                        semantic_error("只能回填此方案中已選的班別")
                    profile, academic, catalog, rules = self._inputs(con, p, plan)
                    audit = ev.audit(profile, academic, catalog, rules, plan)
                    if audit["earned_credits"] is None:
                        raise StoreError(409, "RECORDS_INCOMPLETE", "修課資料不完整，請先核對後再回填")
                    offerings = {o["offering_id"]: o for o in catalog["offerings"]}
                    courses = {c["course_id"]: c for c in catalog["courses"]}
                    enrolled = {offerings[i["offering_id"]]["course_id"] for i in body["items"] if i["state"] == "enrolled"}
                    credits = [courses[c]["credits"] for c in enrolled]
                    if any(c is None for c in credits):
                        semantic_error("回填課程學分未知，需先核對")
                    value = {"report_id": "report-"+uuid.uuid4().hex, "plan_id": plan_id, "based_on_revision": plan["revision"], "source_kind": "student_report", "official_registration": False,
                             "items": body["items"], "earned_credits": audit["earned_credits"], "projected_enrolled_credits": float(sum(map(ev.number, credits))), "unmet_required_course_ids": sorted(set(plan["required_course_ids"])-enrolled), "original_plan_preserved": True}
                    self._artifact(con, p, "registration", value, plan, "RegistrationResult")
                    return 201, value, "RegistrationResult", plan
        if method == "GET" and path.startswith("/snapshots/"):
            return 200, repo.get_snapshot(p, path.split("/")[-1]), None, None
        if method == "GET" and path.startswith("/rule-sets/"):
            return 200, repo.get_rules(p, path.split("/")[-1], version=query.get("version", [None])[0]), "RuleSet", None
        if method == "GET" and path == "/me/audit-history":
            return 200, {"items": repo.audit_history(p)}, None, None
        if method == "POST" and path in ("/eligibility-evaluations", "/slot-recommendations"):
            schema = {"/eligibility-evaluations": "EligibilityRequest", "/slot-recommendations": "SlotRequest"}[path]
            repo.validation.validate(schema, body)
            plan = self._plan(con, p, body["plan_id"], fresh=True)
            profile, academic, catalog, rules = self._inputs(con, p, plan)
            courses = {c["course_id"]: c for c in catalog["courses"]}
            if path == "/eligibility-evaluations":
                by_id = {o["offering_id"]: o for o in catalog["offerings"]}
                if any(oid not in by_id for oid in body["offering_ids"]):
                    missing()
                return 200, {"items": [{"offering_id": oid, "evaluation": ev.eligibility(courses[by_id[oid]["course_id"]], profile, academic, rules)} for oid in body["offering_ids"]]}, "EligibilityList", plan
            repo._match(plan["revision"], body["plan_revision"])
            validate_intervals(body["window"])
            return 200, self._slot(con, p, plan, body, profile, academic, catalog, rules), "SlotResult", plan
        match = re.fullmatch(r"/intent-analyses/([^/]+)/confirm", path)
        if method == "POST" and match:
            repo.validation.validate("IntentConfirm", body)
            intent = repo.get_artifact(p, "intent", match[1])
            plan = self._plan(con, p, intent["plan_id"], fresh=True)
            repo._match(plan["revision"], self.revision(headers))
            self._current_artifact(con, p, "intent", match[1], plan)
            provenance = con.execute("SELECT a.* FROM be02_ai_generations a JOIN be02_artifact_heads h ON h.student_id=a.student_id AND h.kind=a.kind AND h.artifact_id=a.artifact_id AND h.revision=a.revision WHERE a.student_id=? AND a.kind='intent' AND a.artifact_id=?", (p.subject, match[1])).fetchone()
            edited = intent["fields"] != body["fields"]
            intent.update(fields=body["fields"], confirmation="confirmed", questions=[])
            self._artifact(con, p, "intent", intent, plan, "Intent")
            if provenance:
                metadata = json.loads(provenance["metadata"])
                metadata.update(user_confirmed=True, user_edited_fields=metadata.get("user_edited_fields", False) or edited)
                self._save_ai_metadata(con, p, "intent", intent["intent_id"], provenance["generation_id"], metadata)
            return 200, intent, "Intent", plan
        if method == "GET" and path == "/courses":
            term = query.get("term_id", ["MOCK-115-1"])[0]
            catalog = repo.get_catalog(p, term)
            return 200, {"courses": catalog["courses"], "offerings": catalog["offerings"], "next_cursor": None}, "CourseList", None
        if method == "GET" and path.startswith("/offerings/"):
            catalog = repo.get_catalog(p, query.get("term_id", ["MOCK-115-1"])[0])
            offering = next((o for o in catalog["offerings"] if o["offering_id"] == path.split("/")[-1]), None)
            if not offering:
                missing()
            return 200, offering, "Offering", None
        match = re.fullmatch(r"/exports/([^/]+)(/download)?", path)
        if method == "GET" and match:
            value = repo.get_artifact(p, "export", match[1])
            if not match[2]:
                return 200, value, "Export", None
            row = con.execute("SELECT * FROM be02_export_content WHERE student_id=? AND export_id=?", (p.subject, match[1])).fetchone()
            if not row:
                missing()
            return 200, {"bytes": row["content"], "mime_type": row["mime_type"], "file_name": row["file_name"]}, "__download__", None
        if method == "POST" and path == "/admin/catalog-versions":
            result = repo.publish_catalog(p, body)
            return 201, {"version": result["version"], "resource_kind": "catalog", "state": "published", "source_refs": [{"source_id": s["source_id"], "locator": "版本發布"} for s in body["sources"]], "immutable": True}, "VersionReceipt", None
        if method == "POST" and path == "/admin/rule-set-versions":
            repo.validation.validate("RuleVersionImport", body)
            result = repo.publish_rules(p, body["rule_set"], body["sources"])
            return 201, {"version": result["version"], "resource_kind": "rules", "state": "draft" if body["rule_set"]["review_state"] == "draft" else "published", "source_refs": body["rule_set"]["source_refs"], "immutable": True}, "VersionReceipt", None
        missing()

    def _slot(self, con, p, plan, request, profile, academic, catalog, rules):
        courses = {c["course_id"]: c for c in catalog["courses"]}
        selected = {s["offering_id"] for s in plan["selections"] if s["placement"] == "scheduled"}
        scheduled = [o for o in catalog["offerings"] if o["offering_id"] in selected]
        direction_ids = None
        if request["scope"] == "direction":
            if not plan["direction_id"]:
                semantic_error("請先選擇職涯方向")
            direction_ids = set(self.repo.get_artifact(p, "direction", plan["direction_id"])["course_ids"])
        result = {"window": request["window"], "candidates": [], "review_candidates": [], "excluded": []}
        window = request["window"]
        for offering in catalog["offerings"]:
            if offering["offering_id"] in selected or (direction_ids is not None and offering["course_id"] not in direction_ids):
                continue
            meetings = offering["meetings"]
            indexes = [i for i, m in enumerate(meetings or []) if m["weekday"] == window["weekday"] and m["start_minute"] >= window["start_minute"] and m["end_minute"] <= window["end_minute"]]
            if not indexes:
                result["excluded"].append({"offering_id": offering["offering_id"], "reason_codes": ["MEETINGS_UNKNOWN" if meetings is None else "MEETING_OUTSIDE_WINDOW"]})
                continue
            if request["campus_filter"] and any(m["campus_id"] != request["campus_filter"] for m in meetings):
                result["excluded"].append({"offering_id": offering["offering_id"], "reason_codes": ["STRICT_CAMPUS_MISMATCH"]})
                continue
            eligibility = ev.eligibility(courses[offering["course_id"]], profile, academic, rules)
            schedule = ev.schedule(scheduled+[offering], plan["preferences"], rules)
            reasons = [code for value in (eligibility, schedule) for c in value["checks"] if c["status"] == "fail" for code in c["reason_codes"]]
            if reasons:
                result["excluded"].append({"offering_id": offering["offering_id"], "reason_codes": sorted(set(reasons))})
                continue
            recognition = ev.evaluation([ev.check(rules, "recognition", "pass", "可列入規劃，採計以第四階段核對為準。")])
            candidate = {"offering_id": offering["offering_id"], "matched_meeting_indexes": indexes, "eligibility": eligibility, "schedule": schedule, "recognition": recognition, "soft_mismatches": ev.soft_mismatches(offering, plan["preferences"]), "rationale": "符合指定空堂；已核對此班別的其他所有時段與現有課表。"}
            needs_review = eligibility["status"] == "needs_review" or schedule["status"] == "needs_review"
            if needs_review:
                if request["include_needs_review"]:
                    result["review_candidates"].append(candidate)
            else:
                result["candidates"].append(candidate)
        result["candidates"].sort(key=lambda c: sum(m["minutes"] for m in c["soft_mismatches"]))
        return result

    def _csv(self, con, p, plan):
        _, _, catalog, _ = self._inputs(con, p, plan)
        offerings = {o["offering_id"]: o for o in catalog["offerings"]}
        courses = {c["course_id"]: c for c in catalog["courses"]}
        output = io.StringIO(newline="")
        writer = csv.writer(output)
        writer.writerow(["synthetic", "plan_id", "revision", "offering_id", "course", "credits", "placement", "meetings", "official_registration"])
        def safe(value):
            value = str(value)
            return "'" + value if value.startswith(("=", "+", "-", "@", "\t", "\r")) else value
        for selection in plan["selections"]:
            offering = offerings[selection["offering_id"]]
            course = courses[offering["course_id"]]
            writer.writerow([safe(v) for v in [True, plan["plan_id"], plan["revision"], offering["offering_id"], course["name"], course["credits"], selection["placement"], canonical(offering["meetings"]), False]])
        return ("\ufeff"+output.getvalue()).encode("utf-8")
