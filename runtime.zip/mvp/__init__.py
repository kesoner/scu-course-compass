"""Local synthetic career and course planning MVP."""
