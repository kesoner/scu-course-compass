"""Browser-only transport for the unchanged deterministic MVP and BE-02 engine."""
import base64
import json
import os
from email.message import Message
from urllib.parse import urlparse

from mvp.server import DemoApp, APIError
from mvp.gemini_client import GeminiClient
from backend.be02.errors import StoreError
from backend.be02.runtime import FourStageAPI

os.environ.pop('GEMINI_API_KEY',None)
APP=DemoApp('/user_data',GeminiClient(api_key=''))


def pages_request(raw):
    request=json.loads(raw);method=request.get('method','GET');target=request['target'];path=urlparse(target).path
    headers=Message()
    for key,value in request.get('headers',{}).items():headers[key]=value
    body=json.loads(request['body']) if request.get('body') else {}
    try:
        if path.startswith('/api/personal/'):
            if path!='/api/personal/status':raise APIError(403,'personal_unavailable','公開展示版不提供個人修課資料。')
            return json.dumps({'status':200,'json':{'data':{'connected':False}}})
        if '/admin/' in path:raise APIError(403,'admin_unavailable','公開展示版不提供管理功能。')
        if '/pdf/' in path:raise APIError(503,'pdf_unavailable','PDF 匯出請使用本機完整版。')
        if path.startswith('/api/v1/public-courses'):
            status,value=APP.public_catalog.handle(method,target)
        elif path.startswith('/api/v1/'):
            status,value=APP.four_stage_api().handle(method,target,body,headers)
        else:
            status=200;value=APP.handle(method,path,body,headers.get('Authorization',''))
            if isinstance(value,tuple) and value[0]=='file':
                value={'bytes':value[1].read_bytes(),'mime_type':'text/csv; charset=utf-8','file_name':value[2]}
        if isinstance(value,dict) and 'bytes' in value:
            return json.dumps({'status':status,'binary':base64.b64encode(value['bytes']).decode(),'headers':{'Content-Type':value['mime_type'],'Content-Disposition':'attachment; filename="'+value['file_name']+'"'}})
        return json.dumps({'status':status,'json':value},ensure_ascii=False)
    except StoreError as error:
        return json.dumps({'status':error.status,'json':{'meta':FourStageAPI.meta(),'error':error.as_error()}},ensure_ascii=False)
    except APIError as error:
        return json.dumps({'status':error.status,'json':{'error':{'code':error.code,'message':error.message}}},ensure_ascii=False)

