from decimal import Decimal, InvalidOperation
import json
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker, ValidationError, validators

from .errors import StoreError

PROJECT_ROOT = Path(__file__).resolve().parents[2]
CONTRACT_ROOT = PROJECT_ROOT / "contracts" / "be-01"


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def decimal_multiple(validator, divisor, instance, schema):
    if isinstance(instance, bool) or not isinstance(instance, (int, float, Decimal)):
        return
    try:
        if Decimal(str(instance)) % Decimal(str(divisor)):
            yield ValidationError("數值精度不符合契約")
    except (InvalidOperation, ZeroDivisionError):
        yield ValidationError("數值必須是有限數且精度正確")


ContractValidator = validators.extend(Draft202012Validator, {"multipleOf": decimal_multiple})


class ContractValidation:
    def __init__(self, contract_path=None):
        path = Path(contract_path) if contract_path else CONTRACT_ROOT / "schemas.json"
        self.definitions = json.loads(path.read_text(encoding="utf-8"))["$defs"]
        if contract_path is None:
            extension = CONTRACT_ROOT.parent / "course-explorer" / "schemas.json"
            self.definitions.update(json.loads(extension.read_text(encoding="utf-8"))["$defs"])

    def validate(self, name, payload):
        try:
            canonical(payload)
            schema = {"$defs": self.definitions, "$ref": "#/$defs/" + name}
            validator = ContractValidator(schema, format_checker=FormatChecker())
            error = next(validator.iter_errors(payload), None)
        except (TypeError, ValueError):
            raise StoreError(422, "VALIDATION_ERROR", "資料必須為有效JSON") from None
        if error:
            pointer = "/body" + "".join("/" + str(x).replace("~", "~0").replace("/", "~1") for x in error.absolute_path)
            raise StoreError(422, "VALIDATION_ERROR", "資料不符合BE-01契約", details=[
                {"pointer": pointer, "reason_code": "INVALID_SCHEMA", "message": "請核對欄位型別、必填及允許欄位"}])


def semantic_error(message):
    raise StoreError(422, "VALIDATION_ERROR", message)


def validate_intervals(value):
    if isinstance(value, dict):
        if "start_minute" in value and "end_minute" in value and value["start_minute"] >= value["end_minute"]:
            semantic_error("起始時間必須早於結束時間")
        if "min_credits" in value and "max_credits" in value and value["min_credits"] > value["max_credits"]:
            semantic_error("最低學分不能高於最高學分")
        for child in value.values():
            validate_intervals(child)
    elif isinstance(value, list):
        for child in value:
            validate_intervals(child)
